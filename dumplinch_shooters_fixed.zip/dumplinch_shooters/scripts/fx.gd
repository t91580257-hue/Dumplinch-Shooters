class_name Fx
extends RefCounted
# Эффекты выстрелов, попаданий и взрывов (всё кодом, без ассетов).

static func _root() -> Node:
    return (Engine.get_main_loop() as SceneTree).current_scene

static func _free_after(n: Node, t: float) -> void:
    n.get_tree().create_timer(t).timeout.connect(n.queue_free)

static func tracer(a: Vector3, b: Vector3, col: Color = Color(1.0, 0.9, 0.4)) -> void:
    var fxq: int = int(Settings.data.fx)
    if fxq == 0 and randf() < 0.6:
        return
    var len := a.distance_to(b)
    if len < 0.5:
        return
    var m := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.03, 0.03, len)
    m.mesh = bm
    m.material_override = Mat.glow(col)
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _root().add_child(m)
    var up := Vector3.UP if absf((b - a).normalized().y) < 0.95 else Vector3.RIGHT
    m.look_at_from_position((a + b) * 0.5, b, up)
    _free_after(m, 0.05)

static func spark(p: Vector3, col: Color = Color(1, 0.8, 0.3), sz: float = 1.0) -> void:
    if int(Settings.data.fx) == 0:
        return
    var m := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 0.08 * sz
    sm.height = 0.16 * sz
    m.mesh = sm
    m.material_override = Mat.glow(col)
    _root().add_child(m)
    m.global_position = p
    var tw := m.create_tween()
    tw.tween_property(m, "scale", Vector3.ONE * 2.5, 0.12)
    tw.tween_callback(m.queue_free)

static func explosion(p: Vector3, radius: float = 6.0) -> void:
    var m := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 1.0
    sm.height = 2.0
    m.mesh = sm
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.55, 0.1, 0.85)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.material_override = mat
    _root().add_child(m)
    m.global_position = p + Vector3(0, 0.5, 0)
    var l := OmniLight3D.new()
    l.light_color = Color(1, 0.6, 0.2)
    l.light_energy = 6.0
    l.omni_range = radius * 2.0
    m.add_child(l)
    var tw := m.create_tween()
    tw.set_parallel(true)
    tw.tween_property(m, "scale", Vector3.ONE * radius * 0.6, 0.35)
    tw.tween_property(mat, "albedo_color:a", 0.0, 0.5)
    tw.tween_property(l, "light_energy", 0.0, 0.5)
    tw.chain().tween_callback(m.queue_free)
