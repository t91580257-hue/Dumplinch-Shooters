extends Control
# Редактор HUD: перетаскивание кнопок, размер, прозрачность, отступы, стороны, профили.
var hud: Hud
var panel: PanelContainer
var sel_label: Label
var size_slider: HSlider
var alpha_slider: HSlider

func _ready() -> void:
    theme = UI.make_theme()
    var bg := ColorRect.new()
    bg.color = Color(0.1, 0.16, 0.24)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    hud = Hud.new()
    hud.edit_mode = true
    add_child(hud)
    hud.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud.selection_changed.connect(_on_sel)
    panel = PanelContainer.new()
    panel.position = Vector2(400, 10)
    panel.custom_minimum_size = Vector2(1100, 0)
    add_child(panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 6)
    panel.add_child(vb)
    UI.label(vb, "НАСТРОЙКА УПРАВЛЕНИЯ: перетаскивайте кнопки пальцем", 26)
    var prof := OptionButton.new()
    for n in Settings.PROFILE_NAMES:
        prof.add_item(n)
    prof.select(Settings.PROFILES.find(Settings.data.hud.profile))
    prof.item_selected.connect(func(i: int):
        Settings.set_hud("profile", Settings.PROFILES[i])
        hud.selected = ""
        _on_sel(""))
    vb.add_child(prof)
    sel_label = UI.label(vb, "Выберите кнопку", 24)
    var r1 := HBoxContainer.new()
    vb.add_child(r1)
    UI.label(r1, "Размер", 24).custom_minimum_size.x = 150
    size_slider = HSlider.new()
    size_slider.min_value = 60
    size_slider.max_value = 400
    size_slider.step = 5
    size_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    size_slider.custom_minimum_size = Vector2(300, 50)
    size_slider.value_changed.connect(func(v: float): hud.set_selected_size(v))
    r1.add_child(size_slider)
    var r2 := HBoxContainer.new()
    vb.add_child(r2)
    UI.label(r2, "Прозрачность", 24).custom_minimum_size.x = 150
    alpha_slider = HSlider.new()
    alpha_slider.min_value = 0.1
    alpha_slider.max_value = 1.0
    alpha_slider.step = 0.05
    alpha_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    alpha_slider.custom_minimum_size = Vector2(300, 50)
    alpha_slider.value_changed.connect(func(v: float): hud.set_selected_alpha(v))
    r2.add_child(alpha_slider)
    var r3 := HBoxContainer.new()
    vb.add_child(r3)
    UI.label(r3, "Расстояние", 24).custom_minimum_size.x = 150
    var gs := HSlider.new()
    gs.min_value = 0.6
    gs.max_value = 1.4
    gs.step = 0.02
    gs.value = Settings.data.hud.gap
    gs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    gs.custom_minimum_size = Vector2(300, 50)
    gs.value_changed.connect(func(v: float): Settings.set_hud("gap", v))
    r3.add_child(gs)
    var r4 := HBoxContainer.new()
    vb.add_child(r4)
    var sw := Button.new()
    sw.toggle_mode = true
    sw.button_pressed = Settings.data.hud.swap
    sw.text = "Поменять стороны"
    sw.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sw.toggled.connect(func(on: bool): Settings.set_hud("swap", on))
    r4.add_child(sw)
    UI.btn(r4, "СТАНДАРТ", _reset_profile, 60.0).size_flags_horizontal = Control.SIZE_EXPAND_FILL
    UI.btn(r4, "ГОТОВО", _done, 60.0).size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _on_sel("")

func _done() -> void:
    Game.go(Game.return_scene)

func _reset_profile() -> void:
    Settings.reset_hud_profile()
    hud.selected = ""
    _on_sel("")

func _on_sel(id: String) -> void:
    if id == "" or not hud.elements.has(id):
        sel_label.text = "Выберите кнопку (тап по кнопке)"
        size_slider.editable = false
        alpha_slider.editable = false
        return
    sel_label.text = "Выбрано: " + Settings.t(id)
    size_slider.editable = true
    alpha_slider.editable = true
    size_slider.set_value_no_signal(hud.elements[id].sz)
    alpha_slider.set_value_no_signal(hud.elements[id].alpha)

func _process(_d: float) -> void:
    hud.ignore_rects = [panel.get_global_rect()]

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        Game.go(Game.return_scene)
