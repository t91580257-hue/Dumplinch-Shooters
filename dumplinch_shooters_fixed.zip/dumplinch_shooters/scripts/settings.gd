extends Node
# Все настройки игры. Сохраняются в user://settings.cfg и применяются сразу.
signal changed

const PATH := "user://settings.cfg"
const PROFILES := ["standard", "two", "three", "four", "custom"]
const PROFILE_NAMES := ["Стандартное", "Для двух пальцев", "Для трёх пальцев", "Для четырёх пальцев", "Пользовательский"]
const CH_COLORS := [Color(0.2, 1.0, 0.3), Color(1, 1, 1), Color(1.0, 0.2, 0.2), Color(0.2, 0.9, 1.0), Color(1.0, 0.9, 0.2)]
const CH_COLOR_NAMES := ["Зелёный", "Белый", "Красный", "Голубой", "Жёлтый"]
const CH_SHAPES := ["Крест", "Точка", "Круг"]

# id: [x, y, размер(px при высоте 1080), прозрачность]
const LAYOUTS := {
    "standard": {
        "joystick": [0.13, 0.70, 300, 0.85], "fire": [0.88, 0.62, 200, 0.9],
        "ads": [0.77, 0.44, 140, 0.8], "jump": [0.94, 0.40, 130, 0.8],
        "crouch": [0.80, 0.84, 120, 0.8], "reload": [0.67, 0.84, 120, 0.8],
        "switch": [0.94, 0.16, 100, 0.8], "interact": [0.13, 0.40, 130, 0.9],
        "grenade": [0.82, 0.18, 100, 0.8],
    },
    "two": {
        "joystick": [0.13, 0.72, 300, 0.85], "fire": [0.88, 0.68, 220, 0.9],
        "ads": [0.74, 0.80, 120, 0.8], "jump": [0.94, 0.44, 120, 0.8],
        "crouch": [0.82, 0.50, 110, 0.8], "reload": [0.66, 0.88, 100, 0.8],
        "switch": [0.58, 0.90, 90, 0.8], "interact": [0.20, 0.38, 130, 0.9],
        "grenade": [0.70, 0.55, 100, 0.8],
    },
    "three": {
        "joystick": [0.12, 0.72, 300, 0.85], "fire": [0.27, 0.42, 170, 0.9],
        "ads": [0.72, 0.40, 140, 0.8], "jump": [0.92, 0.36, 130, 0.8],
        "crouch": [0.82, 0.70, 120, 0.8], "reload": [0.66, 0.76, 110, 0.8],
        "switch": [0.94, 0.60, 100, 0.8], "interact": [0.10, 0.38, 120, 0.9],
        "grenade": [0.60, 0.45, 100, 0.8],
    },
    "four": {
        "joystick": [0.12, 0.72, 300, 0.85], "fire": [0.25, 0.40, 170, 0.9],
        "ads": [0.75, 0.40, 150, 0.8], "jump": [0.92, 0.34, 130, 0.8],
        "crouch": [0.92, 0.60, 120, 0.8], "reload": [0.38, 0.60, 110, 0.8],
        "switch": [0.80, 0.72, 100, 0.8], "interact": [0.60, 0.78, 130, 0.9],
        "grenade": [0.50, 0.30, 100, 0.8],
    },
    "custom": {
        "joystick": [0.13, 0.70, 300, 0.85], "fire": [0.88, 0.62, 200, 0.9],
        "ads": [0.77, 0.44, 140, 0.8], "jump": [0.94, 0.40, 130, 0.8],
        "crouch": [0.80, 0.84, 120, 0.8], "reload": [0.67, 0.84, 120, 0.8],
        "switch": [0.94, 0.16, 100, 0.8], "interact": [0.13, 0.40, 130, 0.9],
        "grenade": [0.82, 0.18, 100, 0.8],
    },
}

const TR := {
    "play": {"ru": "ИГРАТЬ", "en": "PLAY"},
    "mode": {"ru": "ВЫБОР РЕЖИМА", "en": "GAME MODE"},
    "map": {"ru": "ВЫБОР КАРТЫ", "en": "MAP"},
    "arsenal": {"ru": "АРСЕНАЛ", "en": "ARSENAL"},
    "agents": {"ru": "АГЕНТЫ", "en": "AGENTS"},
    "shop": {"ru": "МАГАЗИН", "en": "SHOP"},
    "settings": {"ru": "НАСТРОЙКИ", "en": "SETTINGS"},
    "profile": {"ru": "ПРОФИЛЬ", "en": "PROFILE"},
    "stats": {"ru": "СТАТИСТИКА", "en": "STATS"},
    "back": {"ru": "НАЗАД", "en": "BACK"},
    "start": {"ru": "НАЧАТЬ МАТЧ", "en": "START MATCH"},
    "level": {"ru": "Уровень", "en": "Level"},
    "spec": {"ru": "СПЕЦНАЗ", "en": "SPECIAL FORCES"},
    "terror": {"ru": "ТЕРРОРИСТЫ", "en": "TERRORISTS"},
    "fire": {"ru": "ОГОНЬ", "en": "FIRE"},
    "ads": {"ru": "ПРИЦЕЛ", "en": "AIM"},
    "jump": {"ru": "ПРЫЖОК", "en": "JUMP"},
    "crouch": {"ru": "ПРИСЕД", "en": "CROUCH"},
    "reload": {"ru": "ПЕРЕЗ", "en": "RELOAD"},
    "switch": {"ru": "СМЕНА", "en": "SWAP"},
    "interact": {"ru": "БОМБА", "en": "BOMB"},
    "grenade": {"ru": "ГРАНАТА", "en": "NADE"},
}

var data := {
    "sens_general": 1.0, "sens_ads": 0.7, "sens_scope": 0.4, "sens_x": 1.0, "sens_y": 1.0,
    "smooth_on": false, "smooth_amount": 0.5,
    "accel_on": false, "accel_power": 0.5, "accel_ads_on": false, "accel_ads_power": 0.3,
    "team": "spec", "mode": "bomb", "map": "city", "diff": -1,
    "primary": "ak", "agent": 0, "name": "Игрок",
    "gfx": 1, "fx": 2, "master_vol": 1.0, "music_vol": 0.6, "sfx_vol": 1.0, "voice": true,
    "ch_color": 0, "ch_shape": 0, "ch_size": 12.0, "lang": "ru",
    "unlocked": [0],
    "hud": {"profile": "standard", "gap": 1.0, "swap": false, "layouts": {}},
}

func _ready() -> void:
    load_all()
    apply_graphics()
    changed.connect(apply_graphics)

func t(k: String) -> String:
    if TR.has(k):
        return TR[k][data.lang]
    return k

func set_value(k: String, v) -> void:
    data[k] = v
    save_all()
    changed.emit()

func reset_sens() -> void:
    data.sens_general = 1.0
    data.sens_ads = 0.7
    data.sens_scope = 0.4
    data.sens_x = 1.0
    data.sens_y = 1.0
    save_all()
    changed.emit()

func hud_layout(profile: String = "") -> Dictionary:
    if profile == "":
        profile = data.hud.profile
    var out := {}
    var base: Dictionary = LAYOUTS[profile]
    var over: Dictionary = data.hud.layouts.get(profile, {})
    for id in base:
        var a: Array = over.get(id, base[id])
        out[id] = {"pos": Vector2(a[0], a[1]), "sz": float(a[2]), "alpha": float(a[3])}
    return out

func set_hud_element(id: String, pos: Vector2, sz: float, alpha: float, do_save: bool = true) -> void:
    var p: String = data.hud.profile
    if not data.hud.layouts.has(p):
        data.hud.layouts[p] = {}
    data.hud.layouts[p][id] = [pos.x, pos.y, sz, alpha]
    if do_save:
        save_all()

func reset_hud_profile() -> void:
    data.hud.layouts.erase(data.hud.profile)
    save_all()
    changed.emit()

func set_hud(key: String, v) -> void:
    data.hud[key] = v
    save_all()
    changed.emit()

func apply_graphics() -> void:
    var vp := get_viewport()
    if vp == null:
        return
    match int(data.gfx):
        0:
            vp.scaling_3d_scale = 0.6
            vp.msaa_3d = Viewport.MSAA_DISABLED
        1:
            vp.scaling_3d_scale = 0.8
            vp.msaa_3d = Viewport.MSAA_2X
        _:
            vp.scaling_3d_scale = 1.0
            vp.msaa_3d = Viewport.MSAA_4X

func save_all() -> void:
    var c := ConfigFile.new()
    for k in data:
        c.set_value("s", k, data[k])
    c.save(PATH)

func load_all() -> void:
    var c := ConfigFile.new()
    if c.load(PATH) != OK:
        return
    for k in data:
        data[k] = c.get_value("s", k, data[k])
