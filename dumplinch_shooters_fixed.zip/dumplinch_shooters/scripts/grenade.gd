class_name Grenade
extends Node3D
var vel := Vector3.ZERO
var thrower = null
var fuse := 2.2

func _ready() -> void:
    var m := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 0.1
    sm.height = 0.2
    m.mesh = sm
    m.material_override = Mat.col(Color(0.25, 0.45, 0.2))
    add_child(m)

func _physics_process(delta: float) -> void:
    vel.y -= 18.0 * delta
    var from := global_position
    var to := from + vel * delta
    var q := PhysicsRayQueryParameters3D.create(from, to, 1)
    var h := get_world_3d().direct_space_state.intersect_ray(q)
    if not h.is_empty():
        var n: Vector3 = h.normal
        vel = vel.bounce(n) * 0.45
        global_position = h.position + n * 0.1
        if n.y > 0.7 and absf(vel.y) < 1.5:
            vel.y = 0.0
            vel.x *= 0.85
            vel.z *= 0.85
    else:
        global_position = to
    fuse -= delta
    if fuse <= 0.0:
        explode()

func explode() -> void:
    Fx.explosion(global_position)
    Sfx.play("boom", global_position)
    for f in get_tree().get_nodes_in_group("fighters"):
        if not f.alive:
            continue
        var d: float = f.global_position.distance_to(global_position)
        if d > 7.0:
            continue
        var q := PhysicsRayQueryParameters3D.create(global_position + Vector3(0, 0.3, 0), f.global_position + Vector3(0, 1.0, 0), 1)
        if get_world_3d().direct_space_state.intersect_ray(q).is_empty():
            f.take_damage(130.0 * (1.0 - d / 7.0), thrower, false)
    queue_free()
