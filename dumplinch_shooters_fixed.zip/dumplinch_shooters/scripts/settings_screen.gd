extends Control
# Настройки: чувствительность, сглаживание, ускорение, прицел, графика, звук, язык.
func _ready() -> void:
    theme = UI.make_theme()
    var bg := ColorRect.new()
    bg.color = Color(0.08, 0.12, 0.22)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    var sc := ScrollContainer.new()
    sc.set_anchors_preset(Control.PRESET_FULL_RECT)
    sc.offset_left = 120
    sc.offset_right = -120
    sc.offset_top = 20
    sc.offset_bottom = -20
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    add_child(sc)
    var vb := VBoxContainer.new()
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    vb.add_theme_constant_override("separation", 12)
    sc.add_child(vb)
    UI.label(vb, "НАСТРОЙКИ", 54)
    UI.label(vb, "Чувствительность камеры", 38)
    UI.slider(vb, "Общая чувствительность", "sens_general", 0.2, 3.0, 0.05)
    UI.slider(vb, "При прицеливании (ADS)", "sens_ads", 0.1, 3.0, 0.05)
    UI.slider(vb, "Снайперский прицел", "sens_scope", 0.1, 3.0, 0.05)
    UI.slider(vb, "По горизонтали", "sens_x", 0.2, 3.0, 0.05)
    UI.slider(vb, "По вертикали", "sens_y", 0.2, 3.0, 0.05)
    UI.btn(vb, "СБРОСИТЬ ЧУВСТВИТЕЛЬНОСТЬ", func():
        Settings.reset_sens()
        get_tree().reload_current_scene())
    UI.label(vb, "Сглаживание камеры и прицела (0% — мгновенно, 100% — максимально плавно)", 34)
    UI.toggle(vb, "Сглаживание", "smooth_on")
    UI.slider(vb, "Сила сглаживания", "smooth_amount", 0.0, 1.0, 0.01, true)
    UI.label(vb, "Ускорение камеры (медленно — точно, резко — быстрее)", 34)
    UI.toggle(vb, "Ускорение (обычный режим)", "accel_on")
    UI.slider(vb, "Сила ускорения", "accel_power", 0.0, 1.0, 0.01, true)
    UI.toggle(vb, "Ускорение (прицеливание)", "accel_ads_on")
    UI.slider(vb, "Сила ускорения в прицеле", "accel_ads_power", 0.0, 1.0, 0.01, true)
    UI.btn(vb, "ТЕСТ ПРИЦЕЛА", func():
        Game.aim_test = true
        Game.return_scene = "res://scenes/settings.tscn"
        Game.go("res://scenes/training.tscn"))
    UI.btn(vb, "НАСТРОИТЬ УПРАВЛЕНИЕ", func():
        Game.return_scene = "res://scenes/settings.tscn"
        Game.go("res://scenes/hud_editor.tscn"))
    UI.btn(vb, "ТРЕНИРОВОЧНАЯ ПЛОЩАДКА", func():
        Game.aim_test = false
        Game.return_scene = "res://scenes/settings.tscn"
        Game.go("res://scenes/training.tscn"))
    UI.label(vb, "Прицел", 38)
    UI.choice_row(vb, "Цвет прицела", Settings.CH_COLOR_NAMES, int(Settings.data.ch_color), func(i): Settings.set_value("ch_color", i))
    UI.choice_row(vb, "Форма прицела", Settings.CH_SHAPES, int(Settings.data.ch_shape), func(i): Settings.set_value("ch_shape", i))
    UI.slider(vb, "Размер прицела", "ch_size", 4.0, 40.0, 1.0)
    var prev := preload("res://scripts/crosshair_preview.gd").new()
    vb.add_child(prev)
    UI.label(vb, "Графика и звук", 38)
    UI.choice_row(vb, "Качество графики", ["Низкое", "Среднее", "Высокое"], int(Settings.data.gfx), func(i): Settings.set_value("gfx", i))
    UI.choice_row(vb, "Качество эффектов", ["Низкое", "Среднее", "Высокое"], int(Settings.data.fx), func(i): Settings.set_value("fx", i))
    UI.slider(vb, "Общая громкость", "master_vol", 0.0, 1.0, 0.01, true)
    UI.slider(vb, "Музыка", "music_vol", 0.0, 1.0, 0.01, true)
    UI.slider(vb, "Звуки", "sfx_vol", 0.0, 1.0, 0.01, true)
    UI.toggle(vb, "Голосовые уведомления", "voice")
    UI.choice_row(vb, "Язык интерфейса (меню)", ["Русский", "English"], 0 if Settings.data.lang == "ru" else 1, func(i): Settings.set_value("lang", "ru" if i == 0 else "en"))
    UI.btn(vb, "НАЗАД", func(): Game.go(Game.MENU), 80.0)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        Game.go(Game.MENU)
