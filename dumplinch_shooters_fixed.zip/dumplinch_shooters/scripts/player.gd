class_name Player
extends Fighter
# Игрок: камера от первого лица, оружие перед камерой, сенсорное управление через Hud.
var hud: Hud
var head: Node3D
var cam: Camera3D
var view: Node3D
var view_model: Node3D
var flash: MeshInstance3D
var pitch := 0.0
var recoil_pitch := 0.0
var ads := false
var fire_prev := false
var spray := 0.0
var kick := 0.0
var spread_now := 0.0
var cam_y := 1.6

func setup(h: Hud) -> void:
    hud = h
    hud.player = self
    is_player = true

func _ready() -> void:
    super._ready()
    is_player = true
    body_root.visible = false
    label.visible = false
    head = Node3D.new()
    head.position.y = 1.6
    add_child(head)
    cam = Camera3D.new()
    cam.fov = 75.0
    cam.near = 0.05
    cam.far = 300.0
    head.add_child(cam)
    cam.current = true
    view = Node3D.new()
    view.position = Vector3(0.26, -0.25, -0.55)
    cam.add_child(view)
    equip_loadout(Settings.data.primary)

func _refresh_weapon_visual() -> void:
    if view == null:
        return
    if view_model != null:
        view_model.queue_free()
    view_model = Weapons.model(slots[cur])
    view.add_child(view_model)
    var hm := SphereMesh.new()
    hm.radius = 0.05
    hm.height = 0.1
    var hand := MeshInstance3D.new()
    hand.mesh = hm
    hand.material_override = Mat.col(Color(1.0, 0.9, 0.8))
    hand.position = Vector3(0, -0.07, 0.0)
    view_model.add_child(hand)
    flash = MeshInstance3D.new()
    var fm := SphereMesh.new()
    fm.radius = 0.07
    fm.height = 0.14
    flash.mesh = fm
    flash.material_override = Mat.glow(Color(1.0, 0.85, 0.3))
    flash.position = Vector3(0, 0.02, -0.8)
    flash.visible = false
    view_model.add_child(flash)

func scoped() -> bool:
    return ads and wid() == "sniper" and alive

func _process(delta: float) -> void:
    if hud == null or head == null:
        return
    var look := hud.look.consume(delta)
    if alive:
        rotate_y(-look.x)
        pitch = clampf(pitch - look.y, -1.45, 1.45)
    recoil_pitch = move_toward(recoil_pitch, 0.0, (0.25 + recoil_pitch * 5.0) * delta)
    head.rotation.x = clampf(pitch + recoil_pitch, -1.5, 1.5)
    var target_y := 0.35 if not alive else (1.1 if crouching else 1.6)
    cam_y = lerpf(cam_y, target_y, 10.0 * delta)
    head.position.y = cam_y
    var tfov := 75.0
    if ads:
        tfov = 18.0 if wid() == "sniper" else 55.0
    cam.fov = lerpf(cam.fov, tfov, 14.0 * delta)
    kick = move_toward(kick, 0.0, 0.6 * delta)
    var hv := Vector2(velocity.x, velocity.z).length()
    var sway := sin(Time.get_ticks_msec() * 0.008) * 0.01 * minf(hv, 5.0) / 5.0
    var tgt := Vector3(0.26, -0.25, -0.55)
    if ads:
        tgt = Vector3(0.0, -0.17, -0.42)
    view.position = view.position.lerp(tgt + Vector3(sway, sway, kick), 14.0 * delta)
    var rx := -0.7 if reload_t > 0.0 else 0.0
    view.rotation.x = lerpf(view.rotation.x, rx, 10.0 * delta)
    view.visible = alive and not (scoped() and cam.fov < 30.0)
    if flash != null and flash.visible and cooldown < 1.0 / maxf(wd().rate, 0.1) - 0.05:
        flash.visible = false
    hud.look.ads = ads and wid() != "sniper"
    hud.look.scope = ads and wid() == "sniper"

func _physics_process(delta: float) -> void:
    if hud == null:
        return
    tick_weapon(delta)
    spray = move_toward(spray, 0.0, 6.0 * delta)
    if not is_on_floor():
        velocity.y -= GRAV * delta
    if not alive:
        velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)
        move_and_slide()
        return
    if hud.take("crouch"):
        set_crouch(not crouching)
    if hud.take("ads") and not wd().get("melee", false):
        ads = not ads
    if hud.take("switch"):
        switch_weapon((cur + 1) % 3)
        ads = false
    if hud.take("reload"):
        start_reload()
        ads = false
    if hud.take("grenade") and not frozen:
        var f := -cam.global_transform.basis.z
        throw_grenade(cam.global_position + f * 0.6, f * 16.0 + Vector3.UP * 4.0 + velocity * 0.5)
    interacting = hud.pressed("interact") and not frozen
    var m := hud.move if not frozen else Vector2.ZERO
    var spd := 5.8 * float(wd().move) * (0.55 if crouching else 1.0) * (0.7 if ads else 1.0)
    var dir := global_transform.basis * Vector3(m.x, 0.0, -m.y)
    velocity.x = move_toward(velocity.x, dir.x * spd, 45.0 * delta)
    velocity.z = move_toward(velocity.z, dir.z * spd, 45.0 * delta)
    if is_on_floor():
        velocity.y = 0.0
        if hud.take("jump") and not frozen:
            velocity.y = 6.0
    move_and_slide()
    var fire := hud.pressed("fire") and not frozen
    var just_fire := fire and not fire_prev
    fire_prev = fire
    var d := wd()
    if fire and can_fire() and (d.auto or just_fire):
        if d.get("melee", false):
            _melee()
        else:
            _shoot_cam()
    elif just_fire and not d.get("melee", false) and mag() == 0:
        start_reload()
    animate_and_steps(delta)

func _melee() -> void:
    var res := shoot(cam.global_position, -cam.global_transform.basis.z, 0.0)
    kick = 0.1
    if res.hit:
        hud.hit_t = 0.18

func _shoot_cam() -> void:
    var d := wd()
    var base: float = d.spread
    if wid() == "sniper":
        base = 0.08 if ads else 5.0
    elif ads:
        base *= 0.45
    var hv := Vector2(velocity.x, velocity.z).length()
    var sp := base + hv * 0.12 + (3.0 if not is_on_floor() else 0.0) + spray * 0.4
    if crouching:
        sp *= 0.7
    spread_now = sp
    var res := shoot(cam.global_position, -cam.global_transform.basis.z, sp)
    spray = minf(spray + 1.0, 8.0)
    recoil_pitch += deg_to_rad(float(d.recoil) * (0.5 + spray * 0.08)) * (0.6 if ads else 1.0)
    rotate_y(deg_to_rad(randf_range(-0.12, 0.12) * float(d.recoil)))
    kick = 0.05 + 0.01 * float(d.recoil)
    if flash != null:
        flash.visible = true
    if res.hit:
        hud.hit_t = 0.18
        hud.hit_head = res.head
    if mag() == 0:
        start_reload()

func on_hurt(_att, amt: float) -> void:
    if hud != null:
        hud.hurt_t = 0.4

func die(killer, head_hit: bool) -> void:
    super.die(killer, head_hit)
    ads = false
    hud.center_text = "ВЫ УСТРАНЕНЫ"
    hud.center_t = 2.0

func respawn(pos: Vector3, yaw: float) -> void:
    super.respawn(pos, yaw)
    pitch = 0.0
    recoil_pitch = 0.0
    cam_y = 1.6
    ads = false
    body_root.visible = false
    label.visible = false
