class_name Fighter
extends CharacterBody3D
# Общая база для игрока и ботов: модель-пельмень, оружие, урон, смерть, возрождение.
signal died(victim, killer, head)

const GRAV := 20.0
var team := "spec"
var hp := 100.0
var alive := true
var display_name := "Бот"
var skin := 0
var kills := 0
var deaths := 0
var assists := 0
var is_player := false
var frozen := false
var interacting := false
var crouching := false
var infinite := false
var slots: Array = ["ak", "pistol", "knife"]
var cur := 0
var ammo := {}
var reload_t := 0.0
var cooldown := 0.0
var grenades := 2
var damagers := {}
var respawn_t := 0.0
var body_root: Node3D
var legs: Array = []
var weapon_slot: Node3D
var capsule: CapsuleShape3D
var col_node: CollisionShape3D
var label: Label3D
var step_t := 0.0

static func _mi(parent: Node3D, mesh: Mesh, col: Color, pos: Vector3) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    m.mesh = mesh
    m.material_override = Mat.col(col)
    m.position = pos
    parent.add_child(m)
    return m

static func make_visual(t: String, skin_i: int) -> Dictionary:
    var root := Node3D.new()
    var skin_col: Color = Game.AGENTS[skin_i % Game.AGENTS.size()].color
    var tc: Color = Game.TEAM_COLORS[t]
    var sm := SphereMesh.new()
    sm.radius = 0.5
    sm.height = 1.0
    _mi(root, sm, skin_col, Vector3(0, 0.62, 0))
    var vest := CylinderMesh.new()
    vest.top_radius = 0.47
    vest.bottom_radius = 0.52
    vest.height = 0.4
    _mi(root, vest, tc, Vector3(0, 0.72, 0))
    var hm := SphereMesh.new()
    hm.radius = 0.36
    hm.height = 0.72
    _mi(root, hm, skin_col.lightened(0.1), Vector3(0, 1.4, 0))
    var eye := SphereMesh.new()
    eye.radius = 0.055
    eye.height = 0.11
    for ex in [-0.14, 0.14]:
        _mi(root, eye, Color(0.05, 0.05, 0.08), Vector3(ex, 1.45, -0.32))
        _mi(root, eye, Color(1.0, 0.6, 0.7), Vector3(ex * 1.7, 1.33, -0.27))
    var cap := CylinderMesh.new()
    cap.top_radius = 0.28
    cap.bottom_radius = 0.37
    cap.height = 0.2
    _mi(root, cap, tc, Vector3(0, 1.72, 0))
    var brim := BoxMesh.new()
    brim.size = Vector3(0.4, 0.04, 0.25)
    _mi(root, brim, tc.darkened(0.2), Vector3(0, 1.65, -0.32))
    var arm := CapsuleMesh.new()
    arm.radius = 0.09
    arm.height = 0.5
    for ax in [-0.46, 0.46]:
        var a := _mi(root, arm, skin_col, Vector3(ax, 0.8, -0.15))
        a.rotation.x = deg_to_rad(-55)
    var leg := CapsuleMesh.new()
    leg.radius = 0.11
    leg.height = 0.5
    var legs_arr: Array = []
    for lx in [-0.2, 0.2]:
        var pivot := Node3D.new()
        pivot.position = Vector3(lx, 0.4, 0)
        root.add_child(pivot)
        _mi(pivot, leg, tc.darkened(0.3), Vector3(0, -0.2, 0))
        legs_arr.append(pivot)
    var ws := Node3D.new()
    ws.position = Vector3(0.3, 0.8, -0.35)
    root.add_child(ws)
    return {"root": root, "legs": legs_arr, "weapon_slot": ws}

func _ready() -> void:
    add_to_group("fighters")
    collision_layer = 2
    collision_mask = 1
    floor_snap_length = 0.4
    capsule = CapsuleShape3D.new()
    capsule.radius = 0.4
    capsule.height = 1.8
    col_node = CollisionShape3D.new()
    col_node.shape = capsule
    col_node.position.y = 0.9
    add_child(col_node)
    var v := make_visual(team, skin)
    body_root = v.root
    legs = v.legs
    weapon_slot = v.weapon_slot
    add_child(body_root)
    label = Label3D.new()
    label.text = display_name
    label.font_size = 40
    label.pixel_size = 0.006
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.modulate = Game.TEAM_COLORS[team]
    label.position.y = 2.25
    add_child(label)

func wd() -> Dictionary:
    return Weapons.D[slots[cur]]

func wid() -> String:
    return slots[cur]

func equip_loadout(primary: String) -> void:
    slots = [primary, "pistol", "knife"]
    ammo = {}
    for id in slots:
        ammo[id] = [Weapons.D[id].mag, Weapons.D[id].mag * 3]
    cur = 0
    grenades = 2
    reload_t = 0.0
    cooldown = 0.0
    _refresh_weapon_visual()

func switch_weapon(i: int) -> void:
    cur = i
    reload_t = 0.0
    cooldown = 0.4
    _refresh_weapon_visual()

func _refresh_weapon_visual() -> void:
    if weapon_slot == null:
        return
    for c in weapon_slot.get_children():
        c.queue_free()
    var m := Weapons.model(slots[cur])
    m.scale = Vector3.ONE * 1.4
    weapon_slot.add_child(m)

func mag() -> int:
    return ammo[slots[cur]][0]

func can_fire() -> bool:
    return alive and not frozen and cooldown <= 0.0 and reload_t <= 0.0 and (wd().get("melee", false) or mag() > 0)

func start_reload() -> void:
    var d := wd()
    if d.get("melee", false) or reload_t > 0.0:
        return
    var a: Array = ammo[slots[cur]]
    if a[0] >= d.mag or (a[1] <= 0 and not infinite):
        return
    reload_t = d.reload
    Sfx.play("reload", null if is_player else global_position)

func tick_weapon(delta: float) -> void:
    cooldown = maxf(0.0, cooldown - delta)
    if reload_t > 0.0:
        reload_t -= delta
        if reload_t <= 0.0:
            var a: Array = ammo[slots[cur]]
            var d := wd()
            if infinite:
                a[0] = d.mag
            else:
                var need: int = d.mag - a[0]
                var take: int = mini(need, a[1])
                a[0] += take
                a[1] -= take

func head_threshold() -> float:
    return 0.95 if crouching else 1.3

func set_crouch(c: bool) -> void:
    crouching = c
    capsule.height = 1.2 if c else 1.8
    col_node.position.y = capsule.height * 0.5
    body_root.scale.y = 0.7 if c else 1.0

func shoot(origin: Vector3, fwd: Vector3, spread_deg: float) -> Dictionary:
    var d := wd()
    var melee: bool = d.get("melee", false)
    var result := {"hit": false, "head": false}
    cooldown = 1.0 / d.rate
    if not melee:
        ammo[slots[cur]][0] -= 1
    Sfx.play("shot_" + slots[cur], null if is_player else global_position)
    if not melee:
        get_tree().call_group("fighters", "hear", global_position, team)
    var space := get_world_3d().direct_space_state
    var up := Vector3.UP if absf(fwd.y) < 0.99 else Vector3.RIGHT
    var bs := Basis.looking_at(fwd, up)
    var muzzle := origin + fwd * 0.7
    if is_player:
        muzzle = origin + bs * Vector3(0.25, -0.22, -0.8)
    for p in d.pellets:
        var r := deg_to_rad(spread_deg) * sqrt(randf())
        var th := randf() * TAU
        var dir := (bs * Vector3(cos(th) * r, sin(th) * r, -1.0)).normalized()
        var to: Vector3 = origin + dir * float(d.range)
        var q := PhysicsRayQueryParameters3D.create(origin, to, 3, [get_rid()])
        var hit := space.intersect_ray(q)
        var end: Vector3 = to
        if not hit.is_empty():
            end = hit.position
            var c = hit.collider
            if c != null and c.has_method("take_damage"):
                var head := false
                if c.has_method("head_threshold"):
                    head = (end.y - c.global_position.y) > c.head_threshold()
                var dmg: float = d.dmg
                if head:
                    dmg *= d.head
                if d.pellets > 1:
                    dmg *= clampf(1.2 - origin.distance_to(end) / d.range * 1.2, 0.2, 1.0)
                c.take_damage(dmg, self, head)
                result.hit = true
                result.head = result.head or head
                Fx.spark(end, Color(1, 0.3, 0.2))
            elif not melee:
                Fx.spark(end, Color(1, 0.9, 0.5), 0.6)
        if not melee:
            Fx.tracer(muzzle, end)
    return result

func throw_grenade(origin: Vector3, v: Vector3) -> void:
    if grenades <= 0 and not infinite:
        return
    if not infinite:
        grenades -= 1
    var g := Grenade.new()
    g.thrower = self
    g.vel = v
    get_tree().current_scene.add_child(g)
    g.global_position = origin

func take_damage(amount: float, attacker, head: bool = false) -> void:
    if not alive:
        return
    if attacker is Fighter and attacker.team == team and attacker != self:
        return
    hp -= amount
    if attacker is Fighter:
        damagers[attacker] = Time.get_ticks_msec()
        if attacker.is_player and attacker != self:
            Sfx.play("headshot" if head else "hit")
    on_hurt(attacker, amount)
    if hp <= 0.0:
        die(attacker, head)

func on_hurt(_att, _amt: float) -> void:
    pass

func hear(_pos: Vector3, _t: String) -> void:
    pass

func die(killer, head: bool) -> void:
    alive = false
    deaths += 1
    hp = 0.0
    interacting = false
    col_node.set_deferred("disabled", true)
    var tw := create_tween()
    tw.tween_property(body_root, "rotation:x", -1.5, 0.4)
    label.visible = false
    died.emit(self, killer, head)

func respawn(pos: Vector3, yaw: float) -> void:
    global_position = pos
    rotation = Vector3(0, yaw, 0)
    velocity = Vector3.ZERO
    alive = true
    hp = 100.0
    col_node.set_deferred("disabled", false)
    body_root.rotation = Vector3.ZERO
    set_crouch(false)
    label.visible = not is_player
    damagers.clear()
    interacting = false

func animate_and_steps(delta: float) -> void:
    var hv := Vector2(velocity.x, velocity.z).length()
    var tm := Time.get_ticks_msec() * 0.001
    if hv > 0.5 and is_on_floor():
        var sw := sin(tm * 11.0) * 0.8 * minf(1.0, hv / 4.0)
        if legs.size() == 2:
            legs[0].rotation.x = sw
            legs[1].rotation.x = -sw
        body_root.position.y = absf(sin(tm * 11.0)) * 0.05
        step_t -= delta * hv / 5.0
        if step_t <= 0.0:
            step_t = 0.45
            Sfx.play("step_" + _surface(), null if is_player else global_position, -8.0 if is_player else 0.0)
    elif legs.size() == 2:
        legs[0].rotation.x = lerpf(legs[0].rotation.x, 0.0, 10.0 * delta)
        legs[1].rotation.x = lerpf(legs[1].rotation.x, 0.0, 10.0 * delta)

func _surface() -> String:
    for i in get_slide_collision_count():
        var c := get_slide_collision(i)
        if c.get_normal().y > 0.7:
            var col = c.get_collider()
            if col != null and col.has_meta("surf"):
                return col.get_meta("surf")
    return "concrete"
