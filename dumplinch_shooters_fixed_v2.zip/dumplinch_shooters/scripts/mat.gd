class_name Mat
extends RefCounted
static var cache := {}
static var out_cache := {}

static func _toon(m: StandardMaterial3D) -> void:
    m.diffuse_mode = BaseMaterial3D.DIFFUSE_TOON
    m.specular_mode = BaseMaterial3D.SPECULAR_TOON
    m.roughness = 0.7

static func col(c: Color) -> StandardMaterial3D:
    var k := c.to_html()
    if cache.has(k):
        return cache[k]
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    _toon(m)
    cache[k] = m
    return m

# Материал с мультяшным контуром (инвертированная оболочка).
static func outlined(c: Color) -> StandardMaterial3D:
    var k := c.to_html()
    if out_cache.has(k):
        return out_cache[k]
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    _toon(m)
    var o := StandardMaterial3D.new()
    o.albedo_color = Color(0.04, 0.06, 0.18)
    o.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    o.cull_mode = BaseMaterial3D.CULL_FRONT
    o.grow = true
    o.grow_amount = 0.03
    m.next_pass = o
    out_cache[k] = m
    return m

static func glow(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    return m
