extends Node3D
# Матч: режимы "Закладка бомбы" и "Командный бой", раунды, таймеры, боты, XP.
const ROUND_TIME := 105.0
const BOMB_TIME := 40.0
const FREEZE := 4.0
const WIN_ROUNDS := 4
const TDM_TARGET := 20
const TDM_TIME := 300.0
const PLANT_T := 3.0
const DEFUSE_T := 5.0
const SITE_R := 5.0
const NAMES := ["Бублик", "Манты", "Вареник", "Хинкали", "Гёдза", "Пирожок", "Колобок", "Чебурек", "Равиоли"]

var info := {}
var nav: Nav
var fighters: Array = []
var player: Player
var hud: Hud
var layer: CanvasLayer
var mode: String = Game.mode
var my_team: String = Game.team()
var state := "init"
var state_t := 0.0
var time_left := 0.0
var round_no := 0
var score := {"spec": 0, "terror": 0}
var tdm_kills := {"spec": 0, "terror": 0}
var bomb := {"planted": false, "pos": Vector3.ZERO, "t": 0.0}
var bomb_node: Node3D
var plant_prog := 0.0
var defuse_prog := 0.0
var beep_t := 0.0
var obj_pts := 0
var skill := 0.5
var pause_layer: CanvasLayer
var end_layer: CanvasLayer
var spawn_i := {}

func _ready() -> void:
    randomize()
    Sfx.stop_music()
    skill = Game.skill()
    var mb := MapBuilder.new()
    info = mb.build(Game.map, self)
    await get_tree().physics_frame
    await get_tree().physics_frame
    nav = Nav.new()
    nav.build(get_world_3d(), 40.0)
    layer = CanvasLayer.new()
    add_child(layer)
    hud = Hud.new()
    layer.add_child(hud)
    hud.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud.pause_pressed.connect(show_pause)
    _spawn_fighters()
    _build_pause_ui()
    if mode == "tdm":
        _start_tdm()
    else:
        _start_round()

func _spawn_fighters() -> void:
    var other := "terror" if my_team == "spec" else "spec"
    player = Player.new()
    player.team = my_team
    player.display_name = Settings.data.name
    player.skin = Settings.data.agent
    player.setup(hud)
    add_child(player)
    fighters.append(player)
    player.died.connect(on_died)
    for i in 4:
        _add_bot(my_team)
    for i in 5:
        _add_bot(other)

func _add_bot(t: String) -> void:
    var b := Bot.new()
    b.team = t
    b.skin = randi() % Game.AGENTS.size()
    b.display_name = NAMES[randi() % NAMES.size()]
    b.match_ref = self
    b.set_skill(clampf(skill + randf_range(-0.08, 0.08), 0.05, 1.0))
    add_child(b)
    fighters.append(b)
    b.died.connect(on_died)

func _spawn_point(f: Fighter) -> Vector3:
    var pts: Array = info.spawn_spec if f.team == "spec" else info.spawn_terror
    var i: int = spawn_i.get(f, spawn_i.size() % 5)
    spawn_i[f] = i
    return pts[i % pts.size()] + Vector3(randf_range(-1, 1), 0, randf_range(-1, 1))

func _respawn(f: Fighter) -> void:
    var pos := _spawn_point(f)
    f.respawn(pos, PI if f.team == "spec" else 0.0)
    if f is Bot:
        f.equip_loadout(Weapons.BOT_POOL.pick_random())
        f.has_goal = false
        f.enemy = null
        f.vis = false
        f.hold_t = 0.0
    else:
        f.equip_loadout(Settings.data.primary)
    f.frozen = (state == "freeze")

func _start_tdm() -> void:
    state = "live"
    time_left = TDM_TIME
    for f in fighters:
        _respawn(f)
        if f is Bot:
            f.role = "roam"
    _announce("КОМАНДНЫЙ БОЙ: до %d устранений" % TDM_TARGET, "Бой начался")

func _start_round() -> void:
    round_no += 1
    state = "freeze"
    state_t = FREEZE
    time_left = ROUND_TIME
    bomb = {"planted": false, "pos": Vector3.ZERO, "t": BOMB_TIME}
    plant_prog = 0.0
    defuse_prog = 0.0
    if bomb_node != null:
        bomb_node.queue_free()
        bomb_node = null
    for f in fighters:
        _respawn(f)
    _assign_roles()
    _announce("РАУНД %d" % round_no, "")

func _assign_roles() -> void:
    var atk := randi() % 2
    var terr: Array = fighters.filter(func(f): return f is Bot and f.team == "terror")
    terr.shuffle()
    for i in terr.size():
        var b: Bot = terr[i]
        b.has_goal = false
        if i == 0:
            b.role = "plant"
            b.site_idx = atk
        else:
            b.role = "attack"
            b.site_idx = atk if randf() < 0.65 else 1 - atk
    for f in fighters:
        if f is Bot and f.team == "spec":
            f.role = "defend"
            f.site_idx = randi() % 2
            f.has_goal = false

func _announce(text: String, voice: String) -> void:
    hud.center_text = text
    hud.center_t = 2.5
    if voice != "":
        Sfx.speak(voice)

func _ring(a: float, b: float) -> Vector3:
    var ang := randf() * TAU
    var r := randf_range(a, b)
    return Vector3(cos(ang) * r, 0, sin(ang) * r)

func _hot_point() -> Vector3:
    var h: Vector3 = info.hot[randi() % info.hot.size()]
    return h + _ring(0.0, 7.0)

func bot_goal(b: Bot) -> Vector3:
    if mode == "tdm":
        return _hot_point()
    var sp: Vector3 = info.sites[b.site_idx].pos
    if bomb.planted:
        if b.team == "spec":
            if b.role == "defuse":
                return bomb.pos
            return bomb.pos + _ring(7.0, 14.0)
        return bomb.pos + _ring(5.0, 12.0)
    if b.team == "terror":
        if b.role == "plant":
            return sp + _ring(0.0, 2.5)
        return sp + _ring(2.0, 9.0)
    if randf() < 0.3:
        return _hot_point()
    return sp + _ring(3.0, 11.0)

func _site_at(p: Vector3) -> int:
    for i in info.sites.size():
        var s: Vector3 = info.sites[i].pos
        if Vector2(p.x - s.x, p.z - s.z).length() < SITE_R:
            return i
    return -1

func can_interact(f: Fighter) -> bool:
    if mode != "bomb" or not f.alive or state != "live":
        return false
    if not bomb.planted:
        return f.team == "terror" and _site_at(f.global_position) >= 0
    return f.team == "spec" and f.global_position.distance_to(bomb.pos) < 2.8

func _physics_process(delta: float) -> void:
    if state == "init" or state == "end":
        return
    match state:
        "freeze":
            state_t -= delta
            if state_t <= 0.0:
                state = "live"
                for f in fighters:
                    f.frozen = false
                _announce("В БОЙ!", "Раунд начался")
        "live":
            _live(delta)
        "post":
            state_t -= delta
            if state_t <= 0.0:
                if score.spec >= WIN_ROUNDS or score.terror >= WIN_ROUNDS:
                    _end_match()
                else:
                    _start_round()
    _update_hud()

func _alive(t: String) -> int:
    var n := 0
    for f in fighters:
        if f.team == t and f.alive:
            n += 1
    return n

func _live(delta: float) -> void:
    if mode == "tdm":
        time_left -= delta
        for f in fighters:
            if not f.alive:
                f.respawn_t -= delta
                if f.respawn_t <= 0.0:
                    _respawn(f)
        if time_left <= 0.0:
            _end_match()
        return
    if not bomb.planted:
        time_left -= delta
    _bomb_update(delta)
    if state != "live":
        return
    if not bomb.planted:
        if _alive("terror") == 0:
            _end_round("spec", "Все террористы устранены")
        elif _alive("spec") == 0:
            _end_round("terror", "Спецназ устранён")
        elif time_left <= 0.0:
            _end_round("spec", "Время вышло")
    elif _alive("spec") == 0:
        _end_round("terror", "Спецназ устранён")

func _bomb_update(delta: float) -> void:
    if not bomb.planted:
        var planter: Fighter = null
        for f in fighters:
            if f.team == "terror" and f.alive and f.interacting and can_interact(f):
                planter = f
        if planter != null:
            plant_prog += delta / PLANT_T
            if plant_prog >= 1.0:
                _plant(planter)
        else:
            plant_prog = 0.0
    else:
        bomb.t -= delta
        beep_t -= delta
        if beep_t <= 0.0:
            beep_t = maxf(0.25, bomb.t / 40.0)
            Sfx.play("beep", bomb.pos)
        var defuser: Fighter = null
        for f in fighters:
            if f.team == "spec" and f.alive and f.interacting and can_interact(f):
                defuser = f
        if defuser != null:
            defuse_prog += delta / DEFUSE_T
            if defuse_prog >= 1.0:
                if defuser.is_player:
                    obj_pts += 1
                _end_round("spec", "Бомба обезврежена")
                return
        else:
            defuse_prog = 0.0
        if bomb.t <= 0.0:
            _explode_bomb()

func _plant(by: Fighter) -> void:
    bomb.planted = true
    bomb.pos = Vector3(by.global_position.x, 0, by.global_position.z)
    bomb.t = BOMB_TIME
    plant_prog = 0.0
    if by.is_player:
        obj_pts += 1
    bomb_node = Node3D.new()
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.6, 0.3, 0.4)
    mi.mesh = bm
    mi.material_override = Mat.col(Color(0.15, 0.15, 0.18))
    mi.position.y = 0.15
    bomb_node.add_child(mi)
    var l := OmniLight3D.new()
    l.light_color = Color(1, 0.1, 0.1)
    l.omni_range = 4.0
    l.position.y = 0.5
    bomb_node.add_child(l)
    add_child(bomb_node)
    bomb_node.global_position = bomb.pos
    _announce("БОМБА УСТАНОВЛЕНА", "Бомба установлена")
    var specs: Array = fighters.filter(func(f): return f is Bot and f.team == "spec" and f.alive)
    specs.sort_custom(func(a, b): return a.global_position.distance_to(bomb.pos) < b.global_position.distance_to(bomb.pos))
    for i in specs.size():
        specs[i].role = "defuse" if i < 2 else "retake"
        specs[i].has_goal = false
        specs[i].hold_t = 0.0
    for f in fighters:
        if f is Bot and f.team == "terror":
            f.role = "guard"
            f.has_goal = false

func _explode_bomb() -> void:
    Fx.explosion(bomb.pos, 12.0)
    Sfx.play("boom", bomb.pos)
    for f in fighters:
        if f.alive:
            var d: float = f.global_position.distance_to(bomb.pos)
            if d < 14.0:
                f.take_damage(300.0 * (1.0 - d / 14.0), null, false)
    _end_round("terror", "Бомба взорвалась")

func _end_round(winner: String, msg: String) -> void:
    if state != "live":
        return
    state = "post"
    state_t = 5.0
    score[winner] += 1
    for f in fighters:
        f.frozen = true
    var won := winner == my_team
    _announce(("ПОБЕДА В РАУНДЕ: " if won else "РАУНД ПРОИГРАН: ") + msg, "Раунд выигран" if won else "Раунд проигран")
    Sfx.play("win" if won else "lose")

func on_died(victim, killer, head: bool) -> void:
    var kn := "Взрыв"
    var col := Color(1, 1, 1)
    if killer is Fighter:
        kn = killer.display_name
        col = Game.TEAM_COLORS[killer.team]
        if killer != victim:
            killer.kills += 1
            if mode == "tdm" and killer.team != victim.team:
                tdm_kills[killer.team] += 1
    var now := Time.get_ticks_msec()
    for a in victim.damagers:
        if a != killer and a is Fighter and a.team != victim.team and now - victim.damagers[a] < 10000:
            a.assists += 1
    hud.feed.push_front(["%s %s %s" % [kn, "[голова]" if head else ">", victim.display_name], 4.0, col])
    if hud.feed.size() > 5:
        hud.feed.resize(5)
    if mode == "tdm":
        victim.respawn_t = 3.0
        if tdm_kills[killer.team if killer is Fighter else "spec"] >= TDM_TARGET and killer is Fighter:
            _end_match()

func _fmt(t: float) -> String:
    var s := maxi(0, int(ceil(t)))
    return "%d:%02d" % [s / 60, s % 60]

func _update_hud() -> void:
    if mode == "tdm":
        hud.top.l = str(tdm_kills.spec)
        hud.top.r = str(tdm_kills.terror)
        hud.top.t = _fmt(time_left)
        hud.top.sub = "Командный бой до %d" % TDM_TARGET
        if not player.alive:
            hud.top.sub = "Возрождение через %d" % ceili(player.respawn_t)
    else:
        hud.top.l = str(score.spec)
        hud.top.r = str(score.terror)
        hud.top.t = _fmt(time_left) if not bomb.planted else "%d" % ceili(bomb.t)
        hud.top.sub = "Раунд %d  |  живых: %d vs %d" % [round_no, _alive("spec"), _alive("terror")]
        if bomb.planted:
            hud.top.sub = "БОМБА УСТАНОВЛЕНА!"
    hud.progress = -1.0
    if plant_prog > 0.0 and player.interacting:
        hud.progress = plant_prog
        hud.progress_label = "Установка бомбы"
    elif defuse_prog > 0.0 and player.interacting:
        hud.progress = defuse_prog
        hud.progress_label = "Обезвреживание"
    hud.interact_label = ""
    if can_interact(player):
        hud.interact_label = "ЗАЛОЖИТЬ" if not bomb.planted else "РАЗМИН."

func _end_match() -> void:
    if state == "end":
        return
    state = "end"
    var my_score := 0
    var op_score := 0
    if mode == "tdm":
        my_score = tdm_kills[my_team]
        op_score = tdm_kills["terror" if my_team == "spec" else "spec"]
    else:
        my_score = score[my_team]
        op_score = score["terror" if my_team == "spec" else "spec"]
    var won := my_score > op_score
    var draw := my_score == op_score
    var lvl_before := Progress.level()
    var res := Progress.record(mode, Game.map, won, draw, player.kills, player.deaths, player.assists, obj_pts, Game.rated(), Game.diff_name())
    var lvl_after := Progress.level()
    Sfx.play("win" if won else "lose")
    Sfx.speak("Победа" if won else ("Ничья" if draw else "Поражение"))
    end_layer = CanvasLayer.new()
    end_layer.layer = 20
    add_child(end_layer)
    var root := Control.new()
    root.theme = UI.make_theme()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    end_layer.add_child(root)
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.05, 0.15, 0.7)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.add_child(dim)
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.add_child(cc)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 18)
    vb.custom_minimum_size = Vector2(1000, 0)
    cc.add_child(vb)
    var title := "ПОБЕДА!" if won else ("НИЧЬЯ" if draw else "ПОРАЖЕНИЕ")
    var tcol := Color(1.0, 0.78, 0.1) if won else (Color(0.85, 0.9, 1.0) if draw else Color(1.0, 0.35, 0.3))
    var cr := UIIcon.new("crown" if won else "skull", tcol, 130)
    cr.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    vb.add_child(cr)
    UI.outlined(vb, title, 130, tcol, Color(0.35, 0.18, 0.0) if won else UI.OUTLINE, 22)
    var sc := HBoxContainer.new()
    sc.alignment = BoxContainer.ALIGNMENT_CENTER
    sc.add_theme_constant_override("separation", 24)
    vb.add_child(sc)
    _score_pill(sc, my_score, Game.TEAM_COLORS[my_team], UI.KINDS["blue"][0] if my_team == "spec" else UI.KINDS["yellow"][0])
    UI.outlined(sc, "VS", 56, Color(1, 0.85, 0.2), Color(0.35, 0.18, 0.0), 10)
    _score_pill(sc, op_score, Color(0.9, 0.2, 0.2), UI.KINDS["red"][0])
    UI.outlined(vb, "Устранения: %d   Смерти: %d   Помощь: %d" % [player.kills, player.deaths, player.assists], 32, Color.WHITE, UI.OUTLINE, 6)
    if not Game.rated():
        UI.outlined(vb, "Развлекательный матч: опыт и рейтинг не начисляются", 26, Color(0.85, 0.9, 1.0), UI.OUTLINE, 4)
    elif lvl_after > lvl_before:
        UI.outlined(vb, "НОВЫЙ УРОВЕНЬ: %d" % lvl_after, 44, Color(1, 0.85, 0.3), UI.OUTLINE, 8)
    var hb := HBoxContainer.new()
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    hb.add_theme_constant_override("separation", 30)
    vb.add_child(hb)
    var reward_coins: int = res.coins if Game.rated() else 0
    var b1 := UI.btn_icon(hb, "home", "Главное меню", _finish.bind(root, reward_coins, "menu"), 96.0, "blue")
    b1.custom_minimum_size.x = 420
    var b2 := UI.btn_icon(hb, "play", "Играть снова", _finish.bind(root, reward_coins, "again"), 96.0, "yellow")
    b2.custom_minimum_size.x = 420

func _score_pill(parent: Node, n: int, col: Color, bg: Color) -> void:
    var pn := PanelContainer.new()
    pn.add_theme_stylebox_override("panel", UI.box(bg, col.darkened(0.5), 24, 4, 6))
    parent.add_child(pn)
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 16)
    pn.add_child(hb)
    hb.add_child(UIIcon.new("skull", Color.WHITE, 70))
    var l := UI.outlined(hb, str(n), 90, Color.WHITE, UI.OUTLINE, 10)
    l.custom_minimum_size.x = 130

func _finish(root: Control, coins: int, action: String) -> void:
    if coins > 0:
        UI.reward_popup(root, "+%d" % coins, "Монеты за матч", Color.WHITE, _do_action.bind(action))
    else:
        _do_action(action)

func _do_action(action: String) -> void:
    if action == "again":
        get_tree().reload_current_scene()
    else:
        Game.go(Game.MENU)

var pause_main: VBoxContainer
var pause_set: VBoxContainer

func _build_pause_ui() -> void:
    pause_layer = CanvasLayer.new()
    pause_layer.layer = 10
    pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
    pause_layer.visible = false
    add_child(pause_layer)
    var root := Control.new()
    root.theme = UI.make_theme()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    pause_layer.add_child(root)
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.05, 0.15, 0.7)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.add_child(dim)
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.add_child(cc)
    var pn := PanelContainer.new()
    pn.custom_minimum_size = Vector2(900, 0)
    cc.add_child(pn)
    var outer := VBoxContainer.new()
    outer.add_theme_constant_override("separation", 12)
    pn.add_child(outer)
    var hd := HBoxContainer.new()
    outer.add_child(hd)
    var t := UI.outlined(hd, "ПАУЗА", 64, Color.WHITE, UI.OUTLINE, 10)
    t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    UI.icon_square(hd, "close", hide_pause, 76.0, "blue")
    pause_main = VBoxContainer.new()
    pause_main.add_theme_constant_override("separation", 14)
    outer.add_child(pause_main)
    UI.btn_icon(pause_main, "play", "Продолжить", hide_pause, 92.0, "yellow")
    UI.btn_icon(pause_main, "gear", "Настройки", _pause_settings, 92.0, "blue")
    UI.btn_icon(pause_main, "home", "Главное меню", func(): Game.go(Game.MENU), 92.0, "blue")
    UI.btn_icon(pause_main, "door", "Выйти из игры", func(): get_tree().quit(), 92.0, "red")
    pause_set = VBoxContainer.new()
    pause_set.add_theme_constant_override("separation", 10)
    pause_set.visible = false
    outer.add_child(pause_set)
    UI.slider(pause_set, "Чувствительность", "sens_general", 0.2, 3.0, 0.05)
    UI.slider(pause_set, "Чувствительность в прицеле", "sens_ads", 0.1, 3.0, 0.05)
    UI.toggle(pause_set, "Сглаживание прицела", "smooth_on")
    UI.slider(pause_set, "Сила сглаживания", "smooth_amount", 0.0, 1.0, 0.01, true)
    UI.toggle(pause_set, "Ускорение прицела", "accel_on")
    UI.slider(pause_set, "Сила ускорения", "accel_power", 0.0, 1.0, 0.01, true)
    UI.btn_icon(pause_set, "back", "Назад", _pause_back, 80.0, "blue")

func _pause_settings() -> void:
    pause_main.visible = false
    pause_set.visible = true

func _pause_back() -> void:
    pause_main.visible = true
    pause_set.visible = false

func show_pause() -> void:
    if state == "end" or state == "init" or pause_layer == null:
        return
    get_tree().paused = true
    _pause_back()
    pause_layer.visible = true

func hide_pause() -> void:
    get_tree().paused = false
    pause_layer.visible = false

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_GO_BACK_REQUEST:
        show_pause()
