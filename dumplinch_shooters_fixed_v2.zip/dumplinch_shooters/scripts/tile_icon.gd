class_name TileIcon
extends Control
# Картинки для плиток: силуэт оружия, голова агента, кейс.
var kind := "weapon"
var id := "ak"
var tint := Color.WHITE

func _init(k: String = "weapon", i: String = "ak", c: Color = Color.WHITE) -> void:
    kind = k
    id = i
    tint = c
    custom_minimum_size = Vector2(0, 150)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    size_flags_vertical = Control.SIZE_EXPAND_FILL

func _draw() -> void:
    match kind:
        "weapon":
            _draw_weapon()
        "agent":
            _draw_agent()
        "case":
            _draw_case()

func _draw_weapon() -> void:
    var parts: Array = Weapons.PARTS[id]
    var minz := 1e9
    var maxz := -1e9
    var miny := 1e9
    var maxy := -1e9
    for p in parts:
        var sz: Vector3 = p[0]
        var o: Vector3 = p[1]
        minz = minf(minz, o.z - sz.z * 0.5)
        maxz = maxf(maxz, o.z + sz.z * 0.5)
        miny = minf(miny, o.y - sz.y * 0.5)
        maxy = maxf(maxy, o.y + sz.y * 0.5)
    var sc := minf(size.x * 0.8 / maxf(maxz - minz, 0.01), size.y * 0.6 / maxf(maxy - miny, 0.01))
    var cx := size.x * 0.5
    var cy := size.y * 0.5
    var mz := (minz + maxz) * 0.5
    var my := (miny + maxy) * 0.5
    for p in parts:
        var sz: Vector3 = p[0]
        var o: Vector3 = p[1]
        var r := Rect2(cx + (mz - (o.z + sz.z * 0.5)) * sc, cy - (o.y + sz.y * 0.5 - my) * sc, sz.z * sc, sz.y * sc)
        draw_rect(r.grow(2.0), Color(0.03, 0.05, 0.15))
        draw_rect(r, (p[2] as Color).lightened(0.1))

func _draw_agent() -> void:
    var c := size * 0.5
    var r := minf(size.x, size.y) * 0.36
    draw_circle(c + Vector2(0, r * 0.2), r + 4.0, Color(0.03, 0.05, 0.15))
    draw_circle(c + Vector2(0, r * 0.2), r, tint)
    for ex in [-1.0, 1.0]:
        draw_circle(c + Vector2(ex * r * 0.38, r * 0.2), r * 0.1, Color(0.05, 0.05, 0.1))
        draw_line(c + Vector2(ex * r * 0.6, -r * 0.1), c + Vector2(ex * r * 0.15, r * 0.0), Color(0.05, 0.05, 0.1), 5.0)

func _draw_case() -> void:
    var c := size * 0.5
    for i in 12:
        var a := i * TAU / 12.0
        draw_line(c, c + Vector2(cos(a), sin(a)) * size.y * 0.55, Color(1, 0.85, 0.3, 0.35), 8.0)
    var w := minf(size.x * 0.6, size.y * 0.9)
    var body := Rect2(c + Vector2(-w * 0.5, -w * 0.05), Vector2(w, w * 0.42))
    var lid := Rect2(c + Vector2(-w * 0.52, -w * 0.38), Vector2(w * 1.04, w * 0.34))
    draw_rect(body.grow(3.0), Color(0.05, 0.07, 0.2))
    draw_rect(lid.grow(3.0), Color(0.05, 0.07, 0.2))
    draw_rect(body, Color(0.12, 0.3, 0.75))
    draw_rect(lid, Color(0.2, 0.5, 0.95))
    for bx in [-0.32, 0.22]:
        draw_rect(Rect2(c + Vector2(w * bx, -w * 0.38), Vector2(w * 0.1, w * 0.75)), Color(1, 0.78, 0.15))
    draw_circle(c + Vector2(0, -w * 0.05), w * 0.09, Color(1, 0.85, 0.2))
    Icons.draw_icon(self, "crown", c + Vector2(0, w * 0.15), w * 0.22, Color(1, 0.85, 0.2))
