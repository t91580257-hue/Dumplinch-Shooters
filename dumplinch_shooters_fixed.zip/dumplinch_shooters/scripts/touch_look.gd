class_name TouchLook
extends RefCounted
# Поворот камеры пальцем: чувствительность, ускорение, сглаживание. Настройки читаются на лету.
var pending := Vector2.ZERO
var buf := Vector2.ZERO
var ads := false
var scope := false

func add_drag(rel: Vector2) -> void:
    var s: Dictionary = Settings.data
    var base: float = s.sens_general
    if scope:
        base *= s.sens_scope
    elif ads:
        base *= s.sens_ads
    var v := Vector2(rel.x * s.sens_x, rel.y * s.sens_y) * base * 0.0030
    var aim := ads or scope
    var on: bool = s.accel_ads_on if aim else s.accel_on
    var pw: float = s.accel_ads_power if aim else s.accel_power
    if on:
        var k := clampf(rel.length() / 35.0, 0.0, 1.0)
        v *= lerpf(1.0 - 0.3 * pw, 1.0 + 1.5 * pw, k)
    pending += v

# Возвращает (поворот по горизонтали, по вертикали) в радианах за кадр.
func consume(delta: float) -> Vector2:
    var s: Dictionary = Settings.data
    if not s.smooth_on:
        buf = Vector2.ZERO
        var out := pending
        pending = Vector2.ZERO
        return out
    buf += pending
    pending = Vector2.ZERO
    var tau := maxf(float(s.smooth_amount) * 0.12, 0.0001)
    var a := 1.0 - exp(-delta / tau)
    var res := buf * a
    buf -= res
    return res
