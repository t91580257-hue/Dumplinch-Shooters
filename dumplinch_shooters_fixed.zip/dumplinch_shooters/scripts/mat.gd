class_name Mat
extends RefCounted
static var cache := {}

static func col(c: Color) -> StandardMaterial3D:
    var k := c.to_html()
    if cache.has(k):
        return cache[k]
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.85
    cache[k] = m
    return m

static func glow(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    return m
