class_name Weapons
extends RefCounted

const D := {
    "ak": {"name": "АК-Дамп", "type": "Автомат", "dmg": 27.0, "head": 3.4, "rate": 9.0, "mag": 30, "reload": 2.4, "spread": 1.1, "recoil": 0.95, "pellets": 1, "range": 150.0, "auto": true, "move": 1.0},
    "smg": {"name": "Пельмень-ПП", "type": "Пистолет-пулемёт", "dmg": 18.0, "head": 2.8, "rate": 13.0, "mag": 25, "reload": 2.0, "spread": 1.5, "recoil": 0.6, "pellets": 1, "range": 110.0, "auto": true, "move": 1.1},
    "shotgun": {"name": "Бам-Дробовик", "type": "Дробовик", "dmg": 13.0, "head": 2.0, "rate": 1.3, "mag": 6, "reload": 2.8, "spread": 6.0, "recoil": 2.6, "pellets": 8, "range": 40.0, "auto": false, "move": 1.0},
    "sniper": {"name": "Дальнобой", "type": "Снайперская винтовка", "dmg": 95.0, "head": 2.2, "rate": 0.85, "mag": 5, "reload": 3.2, "spread": 4.5, "recoil": 3.0, "pellets": 1, "range": 300.0, "auto": false, "move": 0.85},
    "pistol": {"name": "Дампи-пистолет", "type": "Пистолет", "dmg": 24.0, "head": 3.2, "rate": 5.5, "mag": 12, "reload": 1.6, "spread": 1.0, "recoil": 0.8, "pellets": 1, "range": 90.0, "auto": false, "move": 1.0},
    "knife": {"name": "Нож", "type": "Нож", "dmg": 45.0, "head": 1.0, "rate": 2.0, "mag": 1, "reload": 0.0, "spread": 0.0, "recoil": 0.0, "pellets": 1, "range": 2.6, "auto": false, "melee": true, "move": 1.15},
}
const PRIMARY := ["ak", "smg", "shotgun", "sniper"]
const BOT_POOL := ["ak", "ak", "smg", "shotgun", "sniper", "smg"]

const DARK := Color(0.18, 0.18, 0.22)
const GRAY := Color(0.45, 0.47, 0.52)
const WOOD := Color(0.6, 0.38, 0.2)
const ORANGE := Color(1.0, 0.55, 0.1)
# [размер, смещение, цвет]; ствол смотрит в -Z
const PARTS := {
    "ak": [[Vector3(0.06, 0.09, 0.5), Vector3(0, 0, -0.1), DARK], [Vector3(0.04, 0.04, 0.35), Vector3(0, 0.02, -0.55), GRAY], [Vector3(0.05, 0.08, 0.2), Vector3(0, -0.01, 0.28), WOOD], [Vector3(0.04, 0.16, 0.08), Vector3(0, -0.12, -0.05), ORANGE], [Vector3(0.05, 0.1, 0.05), Vector3(0, -0.09, 0.12), DARK]],
    "smg": [[Vector3(0.06, 0.09, 0.32), Vector3(0, 0, -0.05), DARK], [Vector3(0.035, 0.035, 0.2), Vector3(0, 0.01, -0.34), GRAY], [Vector3(0.04, 0.16, 0.06), Vector3(0, -0.12, -0.02), ORANGE], [Vector3(0.05, 0.1, 0.05), Vector3(0, -0.09, 0.08), DARK]],
    "shotgun": [[Vector3(0.06, 0.08, 0.35), Vector3(0, 0, 0), DARK], [Vector3(0.045, 0.045, 0.6), Vector3(0, 0.02, -0.45), GRAY], [Vector3(0.07, 0.06, 0.2), Vector3(0, -0.04, -0.3), WOOD], [Vector3(0.05, 0.08, 0.22), Vector3(0, -0.01, 0.28), WOOD]],
    "sniper": [[Vector3(0.06, 0.09, 0.55), Vector3(0, 0, 0), DARK], [Vector3(0.035, 0.035, 0.6), Vector3(0, 0.02, -0.6), GRAY], [Vector3(0.05, 0.05, 0.22), Vector3(0, 0.1, -0.05), Color(0.1, 0.1, 0.12)], [Vector3(0.05, 0.08, 0.22), Vector3(0, -0.01, 0.38), WOOD]],
    "pistol": [[Vector3(0.05, 0.07, 0.22), Vector3(0, 0, -0.05), DARK], [Vector3(0.045, 0.1, 0.06), Vector3(0, -0.08, 0.04), GRAY]],
    "knife": [[Vector3(0.03, 0.03, 0.12), Vector3(0, 0, 0.05), DARK], [Vector3(0.01, 0.05, 0.28), Vector3(0, 0, -0.18), Color(0.85, 0.88, 0.95)]],
}

static func model(id: String) -> Node3D:
    var root := Node3D.new()
    for p in PARTS[id]:
        var mi := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = p[0]
        mi.mesh = bm
        mi.position = p[1]
        mi.material_override = Mat.col(p[2])
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        root.add_child(mi)
    return root
