class_name UI
extends RefCounted
# Помощники для построения интерфейса кодом.

static func _circle_tex(r: int, c: Color) -> ImageTexture:
    var img := Image.create(r * 2, r * 2, false, Image.FORMAT_RGBA8)
    for x in range(r * 2):
        for y in range(r * 2):
            if Vector2(x + 0.5 - r, y + 0.5 - r).length() <= r:
                img.set_pixel(x, y, c)
    return ImageTexture.create_from_image(img)

static func make_theme() -> Theme:
    var t := Theme.new()
    t.default_font_size = 30
    var cols := {"normal": Color(0.17, 0.3, 0.52), "hover": Color(0.22, 0.38, 0.62), "pressed": Color(0.95, 0.6, 0.1), "disabled": Color(0.2, 0.2, 0.25), "focus": Color(0.17, 0.3, 0.52)}
    for st in cols:
        for cls in ["Button", "OptionButton"]:
            var sb := StyleBoxFlat.new()
            sb.bg_color = cols[st]
            sb.set_corner_radius_all(16)
            sb.content_margin_left = 22
            sb.content_margin_right = 22
            sb.content_margin_top = 10
            sb.content_margin_bottom = 10
            t.set_stylebox(st, cls, sb)
    var pn := StyleBoxFlat.new()
    pn.bg_color = Color(0.07, 0.1, 0.18, 0.96)
    pn.set_corner_radius_all(24)
    pn.set_content_margin_all(24)
    t.set_stylebox("panel", "PanelContainer", pn)
    var tr := StyleBoxFlat.new()
    tr.bg_color = Color(0.3, 0.35, 0.5)
    tr.set_corner_radius_all(6)
    tr.content_margin_top = 6
    tr.content_margin_bottom = 6
    t.set_stylebox("slider", "HSlider", tr)
    var fl := StyleBoxFlat.new()
    fl.bg_color = Color(0.95, 0.6, 0.1)
    fl.set_corner_radius_all(6)
    fl.content_margin_top = 6
    fl.content_margin_bottom = 6
    t.set_stylebox("grabber_area", "HSlider", fl)
    t.set_stylebox("grabber_area_highlight", "HSlider", fl)
    var g := _circle_tex(22, Color(1, 1, 1))
    t.set_icon("grabber", "HSlider", g)
    t.set_icon("grabber_highlight", "HSlider", g)
    t.set_icon("grabber_disabled", "HSlider", g)
    return t

static func label(parent: Node, text: String, size: int = 30) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    parent.add_child(l)
    return l

static func btn(parent: Node, text: String, cb: Callable, h: float = 72.0) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, h)
    b.pressed.connect(cb)
    parent.add_child(b)
    return b

static func choice_row(parent: Node, text: String, items: Array, cur: int, cb: Callable) -> void:
    var box := VBoxContainer.new()
    parent.add_child(box)
    label(box, text, 28)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 10)
    box.add_child(row)
    var group := ButtonGroup.new()
    for i in items.size():
        var b := Button.new()
        b.text = str(items[i])
        b.toggle_mode = true
        b.button_group = group
        b.button_pressed = (i == cur)
        b.custom_minimum_size = Vector2(0, 66)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(cb.bind(i))
        row.add_child(b)

static func slider(parent: Node, text: String, key: String, mn: float, mx: float, step: float, as_pct: bool = false) -> HSlider:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    parent.add_child(row)
    var l := Label.new()
    l.text = text
    l.custom_minimum_size.x = 520
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    row.add_child(l)
    var s := HSlider.new()
    s.min_value = mn
    s.max_value = mx
    s.step = step
    s.value = float(Settings.data[key])
    s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    s.custom_minimum_size = Vector2(300, 56)
    row.add_child(s)
    var v := Label.new()
    v.custom_minimum_size.x = 110
    row.add_child(v)
    var fmt := func(x: float) -> String:
        return ("%d%%" % int(x * 100.0)) if as_pct else ("%.2f" % x)
    v.text = fmt.call(s.value)
    s.value_changed.connect(func(x: float):
        Settings.set_value(key, x)
        v.text = fmt.call(x))
    return s

static func toggle(parent: Node, text: String, key: String) -> Button:
    var b := Button.new()
    b.toggle_mode = true
    b.custom_minimum_size = Vector2(0, 66)
    b.button_pressed = bool(Settings.data[key])
    var upd := func():
        b.text = "%s: %s" % [text, "ВКЛ" if b.button_pressed else "ВЫКЛ"]
    upd.call()
    b.toggled.connect(func(on: bool):
        Settings.set_value(key, on)
        upd.call())
    parent.add_child(b)
    return b
