extends Node3D
# Тренировочная площадка: манекены, движущиеся мишени, бесконечные патроны,
# живая проверка чувствительности/сглаживания/ускорения, переход в тест кнопок.
var hud: Hud
var player: Player
var panel_root: Control
var panel: PanelContainer
var toggle_btn: Button
var hits := 0
var heads := 0
var stat_label: Label

func _ready() -> void:
    Sfx.stop_music()
    var mb := MapBuilder.new()
    mb.build("range", self)
    var layer := CanvasLayer.new()
    add_child(layer)
    hud = Hud.new()
    layer.add_child(hud)
    hud.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud.pause_pressed.connect(_toggle_panel)
    player = Player.new()
    player.team = "spec"
    player.display_name = "Тренировка"
    player.infinite = true
    player.setup(hud)
    add_child(player)
    player.global_position = Vector3(0, 0.1, 28)
    for i in 5:
        var t := Target.new()
        t.position = Vector3(-12 + i * 6, 0, 8 - (i % 2) * 8)
        add_child(t)
        t.got_hit.connect(_on_hit)
    for i in 2:
        var t := Target.new()
        t.position = Vector3(0, 0, 14 - i * 12)
        t.moving = true
        t.range_x = 10.0
        t.speed = 1.2 + i * 0.8
        add_child(t)
        t.got_hit.connect(_on_hit)
    _build_panel(layer)
    hud.top.sub = "ТРЕНИРОВКА"
    if Game.aim_test:
        panel.visible = true
    _update_rects()

func _on_hit(head: bool) -> void:
    hits += 1
    if head:
        heads += 1
    hud.top.sub = "Попаданий: %d   В голову: %d" % [hits, heads]
    hud.hit_t = 0.18
    hud.hit_head = head

func _build_panel(layer: CanvasLayer) -> void:
    panel_root = Control.new()
    panel_root.theme = UI.make_theme()
    panel_root.set_anchors_preset(Control.PRESET_FULL_RECT)
    panel_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(panel_root)
    panel = PanelContainer.new()
    panel.position = Vector2(150, 20)
    panel.custom_minimum_size = Vector2(1100, 0)
    panel.visible = false
    panel_root.add_child(panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 8)
    panel.add_child(vb)
    UI.label(vb, "Тренировка: двигайте пальцем по правой части экрана и меняйте настройки на лету", 26)
    UI.slider(vb, "Общая чувствительность", "sens_general", 0.2, 3.0, 0.05)
    UI.slider(vb, "Чувствительность ADS", "sens_ads", 0.1, 3.0, 0.05)
    UI.slider(vb, "Снайперский прицел", "sens_scope", 0.1, 3.0, 0.05)
    UI.slider(vb, "По горизонтали", "sens_x", 0.2, 3.0, 0.05)
    UI.slider(vb, "По вертикали", "sens_y", 0.2, 3.0, 0.05)
    UI.toggle(vb, "Сглаживание", "smooth_on")
    UI.slider(vb, "Сила сглаживания", "smooth_amount", 0.0, 1.0, 0.01, true)
    UI.toggle(vb, "Ускорение", "accel_on")
    UI.slider(vb, "Сила ускорения", "accel_power", 0.0, 1.0, 0.01, true)
    var row := HBoxContainer.new()
    vb.add_child(row)
    for id in Weapons.PRIMARY:
        var b := Button.new()
        b.text = Weapons.D[id].name
        b.custom_minimum_size = Vector2(0, 60)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(func(): player.equip_loadout(id))
        row.add_child(b)
    var row2 := HBoxContainer.new()
    vb.add_child(row2)
    UI.btn(row2, "ТЕСТ КНОПОК", _open_buttons_test, 64.0).size_flags_horizontal = Control.SIZE_EXPAND_FILL
    UI.btn(row2, "ВЫЙТИ (настройки сохранены)", _exit, 64.0).size_flags_horizontal = Control.SIZE_EXPAND_FILL
    UI.btn(row2, "СКРЫТЬ", _toggle_panel, 64.0).size_flags_horizontal = Control.SIZE_EXPAND_FILL

func _open_buttons_test() -> void:
    Game.return_scene = "res://scenes/training.tscn"
    Game.go("res://scenes/hud_editor.tscn")

func _exit() -> void:
    Game.go(Game.return_scene)

func _toggle_panel() -> void:
    panel.visible = not panel.visible
    _update_rects()

func _update_rects() -> void:
    hud.ignore_rects = []
    if panel.visible:
        hud.ignore_rects.append(Rect2(panel.position, Vector2(1100, 700)))

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        Game.go(Game.return_scene)
