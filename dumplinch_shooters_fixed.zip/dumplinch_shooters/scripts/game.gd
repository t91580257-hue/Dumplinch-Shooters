extends Node
# Глобальные данные: агенты, команды, выбор режима/карты/сложности.
const MENU := "res://scenes/main_menu.tscn"
const AGENTS := [
    {"name": "Классик", "color": Color(0.98, 0.95, 0.88), "price": 0},
    {"name": "Розовый", "color": Color(1.0, 0.72, 0.8), "price": 300},
    {"name": "Мятный", "color": Color(0.7, 1.0, 0.85), "price": 500},
    {"name": "Лимонный", "color": Color(1.0, 0.95, 0.5), "price": 800},
    {"name": "Лиловый", "color": Color(0.8, 0.7, 1.0), "price": 1200},
    {"name": "Золотой", "color": Color(1.0, 0.82, 0.3), "price": 2500},
]
const TEAM_COLORS := {"spec": Color(0.2, 0.45, 1.0), "terror": Color(1.0, 0.55, 0.1)}
const TEAM_NAMES := {"spec": "СПЕЦНАЗ", "terror": "ТЕРРОРИСТЫ"}
const MAPS := {"city": "Город", "desert": "Пустынная база", "snow": "Снежная лаборатория"}
const MODES := {"bomb": "Закладка бомбы", "tdm": "Командный бой"}
const DIFFS := ["Лёгкая", "Средняя", "Сложная", "Эксперт", "Киберспортсмен"]
const SKILLS := [0.12, 0.35, 0.6, 0.82, 1.0]

var return_scene := MENU
var aim_test := false

var mode: String:
    get:
        return Settings.data.mode
var map: String:
    get:
        return Settings.data.map
var difficulty: int:
    get:
        return int(Settings.data.diff)

func team() -> String:
    return Settings.data.team

func rated() -> bool:
    return difficulty == -1

func diff_name() -> String:
    if difficulty >= 0:
        return DIFFS[difficulty]
    return "Авто"

# Сила ботов 0..1. Авто-режим зависит от уровня игрока.
func skill() -> float:
    if difficulty >= 0:
        return SKILLS[difficulty]
    var l := Progress.level()
    if l <= 10:
        return 0.12
    if l <= 50:
        return 0.3
    if l <= 100:
        return 0.5
    if l <= 250:
        return 0.68
    if l < 500:
        return 0.85
    return 1.0

func go(path: String) -> void:
    get_tree().paused = false
    get_tree().change_scene_to_file(path)
