class_name Hud
extends Control
# Сенсорный HUD: джойстик, кнопки, поворот камеры, прицел, счёт, лента, режим редактирования.
signal pause_pressed
signal selection_changed(id: String)

const IDS := ["joystick", "fire", "ads", "jump", "crouch", "reload", "switch", "interact", "grenade"]
var edit_mode := false
var elements := {}
var move := Vector2.ZERO
var held := {}
var just := {}
var look := TouchLook.new()
var touches := {}
var player = null
var top := {"l": "", "r": "", "t": "", "sub": ""}
var center_text := ""
var center_t := 0.0
var feed: Array = []
var progress := -1.0
var progress_label := ""
var interact_label := ""
var show_pause := true
var hit_t := 0.0
var hit_head := false
var hurt_t := 0.0
var selected := ""
var ignore_rects: Array = []
var joy_center := Vector2.ZERO

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    reload_layout()
    Settings.changed.connect(reload_layout)

func reload_layout() -> void:
    elements = Settings.hud_layout()

func pressed(id: String) -> bool:
    return held.get(id, false)

func take(id: String) -> bool:
    if just.has(id) and Time.get_ticks_msec() - just[id] < 200:
        just.erase(id)
        return true
    return false

func screen_pos(id: String) -> Vector2:
    var p: Vector2 = elements[id].pos
    var h: Dictionary = Settings.data.hud
    if h.swap:
        p.x = 1.0 - p.x
    var anchor := Vector2(0.0 if p.x < 0.5 else 1.0, 1.0)
    p = anchor + (p - anchor) * float(h.gap)
    return p * size

func radius(id: String) -> float:
    return float(elements[id].sz) * 0.5 * (size.y / 1080.0)

func _hit(pos: Vector2) -> String:
    for i in range(IDS.size() - 1, -1, -1):
        var id: String = IDS[i]
        var r := radius(id) * (1.5 if id == "joystick" else 1.15)
        if pos.distance_to(screen_pos(id)) <= r:
            return id
    return ""

func _input(e: InputEvent) -> void:
    if e is InputEventScreenTouch:
        if e.pressed:
            _down(e.index, e.position)
        else:
            _up(e.index)
    elif e is InputEventScreenDrag:
        _drag(e.index, e.position, e.relative)

func _down(i: int, pos: Vector2) -> void:
    for r in ignore_rects:
        if r.has_point(pos):
            return
    var id := _hit(pos)
    if edit_mode:
        selected = id
        touches[i] = {"kind": "edit", "id": id}
        selection_changed.emit(id)
        return
    if show_pause and pos.distance_to(Vector2(62, 62) * (size.y / 1080.0)) < 56.0:
        pause_pressed.emit()
        return
    if id == "joystick":
        touches[i] = {"kind": "joy"}
        joy_center = screen_pos("joystick")
        _update_joy(pos)
    elif id != "":
        held[id] = true
        just[id] = Time.get_ticks_msec()
        touches[i] = {"kind": "btn", "id": id}
    else:
        touches[i] = {"kind": "look"}

func _up(i: int) -> void:
    if not touches.has(i):
        return
    var t: Dictionary = touches[i]
    if t.kind == "btn":
        held[t.id] = false
    elif t.kind == "joy":
        move = Vector2.ZERO
    elif t.kind == "edit":
        Settings.save_all()
    touches.erase(i)

func _drag(i: int, pos: Vector2, rel: Vector2) -> void:
    if not touches.has(i):
        return
    var t: Dictionary = touches[i]
    match t.kind:
        "joy":
            _update_joy(pos)
        "look":
            look.add_drag(rel)
        "btn":
            if t.id == "fire":
                look.add_drag(rel)
        "edit":
            if t.id != "":
                _move_element(t.id, rel)

func _update_joy(pos: Vector2) -> void:
    var r := radius("joystick")
    var v := (pos - joy_center) / r
    if v.length() > 1.0:
        v = v.normalized()
    if v.length() < 0.12:
        v = Vector2.ZERO
    move = Vector2(v.x, -v.y)

func _move_element(id: String, rel: Vector2) -> void:
    var e: Dictionary = elements[id]
    var old: Vector2 = e.pos
    var d := rel / size
    if Settings.data.hud.swap:
        d.x = -d.x
    d /= maxf(float(Settings.data.hud.gap), 0.2)
    e.pos = old + d
    var sp := screen_pos(id)
    var m := 0.04 * size.y
    if sp.x < m or sp.y < m or sp.x > size.x - m or sp.y > size.y - m:
        e.pos = old
    else:
        Settings.set_hud_element(id, e.pos, e.sz, e.alpha, false)

func set_selected_size(v: float) -> void:
    if selected != "" and elements.has(selected):
        elements[selected].sz = v
        Settings.set_hud_element(selected, elements[selected].pos, v, elements[selected].alpha)

func set_selected_alpha(v: float) -> void:
    if selected != "" and elements.has(selected):
        elements[selected].alpha = v
        Settings.set_hud_element(selected, elements[selected].pos, elements[selected].sz, v)

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_PAUSED:
        touches.clear()
        held.clear()
        move = Vector2.ZERO

func _process(delta: float) -> void:
    hit_t = maxf(0.0, hit_t - delta)
    hurt_t = maxf(0.0, hurt_t - delta)
    center_t = maxf(0.0, center_t - delta)
    for f in feed:
        f[1] -= delta
    feed = feed.filter(func(x): return x[1] > 0.0)
    queue_redraw()

static func draw_crosshair(ci: CanvasItem, c: Vector2, extra: float = 0.0) -> void:
    var col: Color = Settings.CH_COLORS[int(Settings.data.ch_color)]
    var sz: float = Settings.data.ch_size
    var gap := 5.0 + extra
    match int(Settings.data.ch_shape):
        0:
            ci.draw_line(c + Vector2(gap, 0), c + Vector2(gap + sz, 0), col, 3.0)
            ci.draw_line(c - Vector2(gap, 0), c - Vector2(gap + sz, 0), col, 3.0)
            ci.draw_line(c + Vector2(0, gap), c + Vector2(0, gap + sz), col, 3.0)
            ci.draw_line(c - Vector2(0, gap), c - Vector2(0, gap + sz), col, 3.0)
        1:
            ci.draw_circle(c, maxf(sz * 0.25, 2.0), col)
        _:
            ci.draw_arc(c, sz * 0.8 + extra, 0.0, TAU, 40, col, 3.0)

func _draw() -> void:
    var f := ThemeDB.fallback_font
    var S := size
    var sc := S.y / 1080.0
    if edit_mode:
        _draw_edit_bg(S)
    elif player != null:
        _draw_game(S, sc, f)
    for id in IDS:
        _draw_button(id, f, sc)

func _draw_edit_bg(S: Vector2) -> void:
    for i in range(1, 20):
        draw_line(Vector2(S.x * i / 20.0, 0), Vector2(S.x * i / 20.0, S.y), Color(1, 1, 1, 0.08), 1.0)
    for i in range(1, 12):
        draw_line(Vector2(0, S.y * i / 12.0), Vector2(S.x, S.y * i / 12.0), Color(1, 1, 1, 0.08), 1.0)
    var m := 0.04 * S.y
    draw_rect(Rect2(m, m, S.x - 2 * m, S.y - 2 * m), Color(1, 0.9, 0.2, 0.6), false, 3.0)

var st_blue: StyleBoxFlat
var st_red: StyleBoxFlat
var st_dark: StyleBoxFlat

func _styles() -> void:
    if st_blue != null:
        return
    st_blue = UI.box(Color(0.15, 0.4, 0.95), Color(0.05, 0.12, 0.4), 14, 3, 3)
    st_red = UI.box(Color(0.9, 0.2, 0.2), Color(0.4, 0.05, 0.05), 14, 3, 3)
    st_dark = UI.box(Color(0.05, 0.1, 0.28, 0.85), Color(0.2, 0.3, 0.6), 14, 3, 3)
    for st in [st_blue, st_red, st_dark]:
        st.shadow_size = 0
        st.content_margin_left = 0
        st.content_margin_right = 0
        st.content_margin_top = 0
        st.content_margin_bottom = 0

func _draw_game(S: Vector2, sc: float, f: Font) -> void:
    _styles()
    var c := S * 0.5
    if player.scoped():
        draw_arc(c, S.y * 0.5 + S.x * 0.5, 0.0, TAU, 96, Color.BLACK, S.x)
        draw_line(Vector2(0, c.y), Vector2(S.x, c.y), Color(0, 0, 0, 0.8), 2.0)
        draw_line(Vector2(c.x, 0), Vector2(c.x, S.y), Color(0, 0, 0, 0.8), 2.0)
    elif player.alive:
        draw_crosshair(self, c, clampf(player.spread_now * 3.0, 0.0, 24.0))
    if hit_t > 0.0:
        var hc := Color(1, 0.2, 0.2) if hit_head else Color.WHITE
        for dv in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
            draw_line(c + dv * 10.0, c + dv * 22.0, hc, 3.0)
    if hurt_t > 0.0:
        draw_rect(Rect2(Vector2.ZERO, S), Color(1, 0, 0, 0.3 * hurt_t / 0.4))
    # счёт: синий | таймер | красный
    var cx := S.x * 0.5
    draw_style_box(st_blue, Rect2(cx - 250, 12, 170, 62))
    Icons.draw_icon(self, "skull", Vector2(cx - 222, 43), 36, Color.WHITE)
    draw_string(f, Vector2(cx - 200, 59), top.l, HORIZONTAL_ALIGNMENT_CENTER, 110, 40, Color.WHITE)
    draw_style_box(st_red, Rect2(cx + 80, 12, 170, 62))
    Icons.draw_icon(self, "skull", Vector2(cx + 222, 43), 36, Color.WHITE)
    draw_string(f, Vector2(cx + 90, 59), top.r, HORIZONTAL_ALIGNMENT_CENTER, 110, 40, Color.WHITE)
    draw_style_box(st_dark, Rect2(cx - 80, 6, 160, 74))
    draw_string(f, Vector2(cx - 80, 56), top.t, HORIZONTAL_ALIGNMENT_CENTER, 160, 40, Color.WHITE)
    draw_string(f, Vector2(cx - 330, 112), top.sub, HORIZONTAL_ALIGNMENT_CENTER, 660, 26, Color(1, 0.85, 0.4))
    if show_pause:
        draw_style_box(st_blue, Rect2(Vector2(24, 24) * sc, Vector2(76, 76) * sc))
        Icons.draw_icon(self, "pause", Vector2(62, 62) * sc, 46 * sc, Color.WHITE)
        _draw_minimap(Vector2(130, 240) * sc, 105.0 * sc)
    # патроны справа вверху
    if player.alive:
        var d: Dictionary = player.wd()
        draw_style_box(st_dark, Rect2(S.x - 330, 14, 310, 62))
        if d.get("melee", false):
            draw_string(f, Vector2(S.x - 330, 58), d.name, HORIZONTAL_ALIGNMENT_CENTER, 310, 32, Color.WHITE)
        else:
            var a: Array = player.ammo[player.wid()]
            draw_string(f, Vector2(S.x - 320, 58), "%d/%s" % [a[0], "inf" if player.infinite else str(a[1])], HORIZONTAL_ALIGNMENT_LEFT, 200, 40, Color.WHITE)
            for k in mini(4, int(a[0] / 8.0) + 1):
                Icons.draw_icon(self, "bullet", Vector2(S.x - 120 + k * 22, 46), 36, Color(1, 0.85, 0.3))
        draw_string(f, Vector2(S.x - 330, 100), "%s   Гранат: %d" % [d.name, player.grenades], HORIZONTAL_ALIGNMENT_RIGHT, 310, 22, Color(0.9, 0.95, 1.0))
        if player.reload_t > 0.0:
            draw_string(f, Vector2(0, S.y * 0.58), "ПЕРЕЗАРЯДКА", HORIZONTAL_ALIGNMENT_CENTER, S.x, 30, Color(1, 0.9, 0.4))
        # здоровье
        var hp := clampf(player.hp / 100.0, 0.0, 1.0)
        draw_style_box(st_dark, Rect2(24, S.y - 80, 380, 52))
        draw_rect(Rect2(60, S.y - 70, 334 * hp, 32), Color(0.3, 0.85, 0.2).lerp(Color(0.9, 0.2, 0.2), 1.0 - hp))
        Icons.draw_icon(self, "plus", Vector2(40, S.y - 54), 30, Color(0.4, 1, 0.4))
        draw_string(f, Vector2(60, S.y - 44), "%d" % int(player.hp), HORIZONTAL_ALIGNMENT_LEFT, 120, 30, Color.WHITE)
    var y := 140.0
    for e in feed:
        draw_string(f, Vector2(S.x - 620, y), e[0], HORIZONTAL_ALIGNMENT_RIGHT, 600, 24, e[2])
        y += 32.0
    if center_t > 0.0:
        draw_string(f, Vector2(0, S.y * 0.3), center_text, HORIZONTAL_ALIGNMENT_CENTER, S.x, 56, Color(1, 1, 1, minf(1.0, center_t)))
    if progress >= 0.0:
        var r := Rect2(S.x * 0.5 - 200, S.y * 0.62, 400, 26)
        draw_rect(r, Color(0, 0, 0, 0.6))
        draw_rect(Rect2(r.position, Vector2(r.size.x * progress, r.size.y)), Color(1, 0.8, 0.2))
        draw_string(f, Vector2(r.position.x, r.position.y - 8), progress_label, HORIZONTAL_ALIGNMENT_CENTER, 400, 26, Color.WHITE)

func _draw_minimap(c: Vector2, r: float) -> void:
    draw_circle(c, r, Color(0.05, 0.12, 0.3, 0.6))
    draw_arc(c, r, 0.0, TAU, 48, Color(0.5, 0.7, 1.0, 0.9), 4.0)
    var yaw: float = player.rotation.y
    var sn := sin(yaw)
    var cs := cos(yaw)
    var scale_px := r / 45.0
    for f in player.get_tree().get_nodes_in_group("fighters"):
        if f == player or not f.alive:
            continue
        var seen_ok: bool = f.team == player.team
        if not seen_ok:
            for a in player.get_tree().get_nodes_in_group("fighters"):
                if a is Bot and a.team == player.team and a.alive and a.vis and a.enemy == f:
                    seen_ok = true
                    break
        if not seen_ok:
            continue
        var rel: Vector3 = f.global_position - player.global_position
        var px := (rel.x * cs - rel.z * sn) * scale_px
        var py := (rel.x * sn + rel.z * cs) * scale_px
        var p := Vector2(px, py)
        if p.length() > r - 6.0:
            p = p.normalized() * (r - 6.0)
        draw_circle(c + p, 6.0, Game.TEAM_COLORS[f.team])
    draw_colored_polygon(PackedVector2Array([c + Vector2(0, -12), c + Vector2(-8, 8), c + Vector2(8, 8)]), Color.WHITE)

func _draw_button(id: String, f: Font, sc: float) -> void:
    var e: Dictionary = elements[id]
    var p := screen_pos(id)
    var r := radius(id)
    var a: float = e.alpha
    var on: bool = bool(held.get(id, false))
    if id == "joystick":
        draw_circle(p, r, Color(0.7, 0.8, 1.0, 0.16 * a))
        draw_arc(p, r, 0.0, TAU, 48, Color(1, 1, 1, 0.55 * a), 4.0)
        draw_circle(p + Vector2(move.x, -move.y) * r * 0.55, r * 0.38, Color(1, 1, 1, 0.5 * a))
        for d in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
            Icons.draw_icon(self, "up", p + d * r * 0.8, r * 0.14, Color(1, 1, 1, 0.5 * a))
    else:
        var dim := 1.0
        var icon = {"fire": "bullet", "ads": "crosshair", "jump": "up", "crouch": "person", "reload": "reload", "switch": "swap", "interact": "bomb", "grenade": "grenade"}[id]
        if id == "interact" and not edit_mode and interact_label == "":
            dim = 0.35
        draw_circle(p, r, Color(1, 0.6, 0.1, 0.6 * a * dim) if on else Color(0.55, 0.62, 0.75, 0.42 * a * dim))
        draw_arc(p, r, 0.0, TAU, 40, Color(1, 1, 1, 0.8 * a * dim), 4.0)
        Icons.draw_icon(self, icon, p, r * 1.0, Color(1, 1, 1, minf(1.0, a + 0.1) * dim))
        if edit_mode or (id == "interact" and interact_label != ""):
            var txt: String = Settings.t(id) if (edit_mode or interact_label == "") else interact_label
            var fs := int(clampf(r * 0.26, 14, 26))
            draw_string(f, p + Vector2(-r, r + fs + 4), txt, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color(1, 1, 1, 0.95))
    if edit_mode and selected == id:
        draw_arc(p, r + 10, 0.0, TAU, 48, Color(1, 0.9, 0.2), 5.0)
    elif edit_mode:
        draw_arc(p, r + 6, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 2.0)