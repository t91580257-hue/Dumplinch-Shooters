class_name Bot
extends Fighter
# ИИ бота: зрение с конусом и лучом (без wallhack), слух выстрелов, укрытия, отступление,
# гранаты, случайные маршруты, реакция/точность зависят от skill (0..1).
var match_ref = null
var skill := 0.5
var role := "roam"
var site_idx := 0
var path := PackedVector3Array()
var path_i := 0
var has_goal := false
var hold_t := 0.0
var enemy: Fighter = null
var vis := false
var last_seen_pos := Vector3.ZERO
var last_seen_t := -99.0
var investigate := false
var react_t := 0.0
var think_t := 0.0
var strafe_dir := 1.0
var strafe_t := 0.0
var grenade_t := 6.0
var spray := 0.0
var stuck_t := 0.0
var last_pos := Vector3.ZERO
var scan_yaw := 0.0
var scan_t := 0.0
var hear_cd := 0.0
var speed := 5.0
var react_base := 0.5
var aim_err := 5.0
var turn_speed := 6.0
var view_dist := 60.0
var strafe_amt := 0.5

func set_skill(s: float) -> void:
    skill = clampf(s, 0.05, 1.0)
    speed = lerpf(4.3, 5.8, skill)
    react_base = lerpf(0.9, 0.16, skill)
    aim_err = lerpf(7.0, 0.9, skill)
    turn_speed = lerpf(3.0, 13.0, skill)
    view_dist = lerpf(45.0, 90.0, skill)
    strafe_amt = lerpf(0.1, 1.0, skill)

func hear(pos: Vector3, t: String) -> void:
    if not alive or t == team or vis or hear_cd > 0.0:
        return
    var d := pos.distance_to(global_position)
    if d < 45.0 and randf() < 0.5 + 0.4 * skill:
        last_seen_pos = pos + Vector3(randf_range(-1, 1), 0, randf_range(-1, 1)) * (8.0 * (1.0 - skill) + 2.0)
        investigate = true
        has_goal = false
        hold_t = 0.0
        hear_cd = 3.0

func on_hurt(att, _amt: float) -> void:
    if att is Fighter and not vis:
        last_seen_pos = att.global_position + Vector3(randf_range(-2, 2), 0, randf_range(-2, 2)) * (1.5 - skill)
        investigate = true
        has_goal = false
        hold_t = 0.0
        react_t = react_base * 0.6

func _physics_process(delta: float) -> void:
    tick_weapon(delta)
    if not is_on_floor():
        velocity.y -= GRAV * delta
    else:
        velocity.y = 0.0
    if not alive or frozen:
        velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)
        move_and_slide()
        return
    think_t -= delta
    react_t -= delta
    grenade_t -= delta
    strafe_t -= delta
    hear_cd -= delta
    spray = move_toward(spray, 0.0, 3.0 * delta)
    if think_t <= 0.0:
        think_t = randf_range(0.12, 0.22)
        _sense()
    var dir := Vector3.ZERO
    var spd := speed
    if enemy != null and vis:
        interacting = false
        dir = _combat(delta)
        spd = speed * 0.7
        if hp < 30.0 and skill > 0.3 and randf() < 0.01:
            _retreat()
    else:
        dir = _navigate(delta)
    if mag() == 0 or (enemy == null and mag() < wd().mag * 0.4):
        start_reload()
    var tv := dir * spd
    velocity.x = move_toward(velocity.x, tv.x, 30.0 * delta)
    velocity.z = move_toward(velocity.z, tv.z, 30.0 * delta)
    move_and_slide()
    animate_and_steps(delta)

func _face(d: Vector3, rate: float, delta: float) -> float:
    var want := atan2(-d.x, -d.z)
    var diff := wrapf(want - rotation.y, -PI, PI)
    rotation.y += clampf(diff, -rate * delta, rate * delta)
    return absf(diff)

func _sense() -> void:
    var now := Time.get_ticks_msec() / 1000.0
    var best: Fighter = null
    var best_d := 1.0e9
    var eye := global_position + Vector3(0, 1.5, 0)
    var fwd := -global_transform.basis.z
    for f in match_ref.fighters:
        if f.team == team or not f.alive:
            continue
        var to: Vector3 = f.global_position - global_position
        var d := to.length()
        if d > view_dist:
            continue
        var flat := Vector3(to.x, 0, to.z).normalized()
        if d > 3.0 and fwd.dot(flat) < 0.45:
            continue
        var seen: bool = match_ref.nav.can_see(eye, f.global_position + Vector3(0, 1.1, 0)) or match_ref.nav.can_see(eye, f.global_position + Vector3(0, 1.55, 0))
        if not seen:
            continue
        if d < best_d:
            best_d = d
            best = f
    var was := vis
    vis = best != null
    if vis:
        if enemy != best or not was:
            react_t = react_base * randf_range(0.8, 1.5)
        enemy = best
        last_seen_pos = best.global_position
        last_seen_t = now
    elif was:
        investigate = true
        has_goal = false
    if enemy != null and not vis and now - last_seen_t > 7.0:
        enemy = null
    if enemy != null and not vis and grenades > 0 and grenade_t <= 0.0 and now - last_seen_t < 4.0:
        var dist := global_position.distance_to(last_seen_pos)
        if dist > 9.0 and dist < 28.0 and randf() < skill * 0.5:
            var h := Vector3(last_seen_pos.x - global_position.x, 0, last_seen_pos.z - global_position.z).normalized()
            throw_grenade(eye + h * 0.5, h * clampf(dist * 0.75 + 4.0, 8.0, 22.0) + Vector3.UP * 5.0)
            grenade_t = 12.0

func _combat(delta: float) -> Vector3:
    var to := enemy.global_position - global_position
    var dist := Vector3(to.x, 0, to.z).length()
    var err := _face(to, turn_speed, delta)
    if react_t <= 0.0 and can_fire() and err < deg_to_rad(5.0 + (1.0 - skill) * 6.0):
        _fire_at(dist)
    if strafe_t <= 0.0:
        strafe_dir = [-1.0, 1.0, 0.0].pick_random() if skill > 0.3 else [0.0, 0.0, 1.0].pick_random()
        strafe_t = randf_range(0.5, 1.6)
    var right := global_transform.basis.x
    var fwd := -global_transform.basis.z
    var dir := right * strafe_dir * strafe_amt
    var pref := {"shotgun": 8.0, "smg": 15.0, "ak": 22.0, "pistol": 14.0, "sniper": 45.0, "knife": 2.0}[wid()]
    if dist > pref * 1.3:
        dir += fwd * 0.8
    elif dist < pref * 0.6:
        dir -= fwd * 0.6
    return dir

func _fire_at(dist: float) -> void:
    var d := wd()
    var eye := global_position + Vector3(0, 1.5, 0)
    var hlo := 0.85 if skill > 0.4 else 0.7
    var hhi := 1.35 if skill > 0.4 else 1.15
    var tgt := enemy.global_position + Vector3(0, randf_range(hlo, hhi), 0)
    var fwd := (tgt - eye).normalized()
    var mv := Vector2(velocity.x, velocity.z).length()
    var sp: float = d.spread + aim_err + spray + mv * 0.15
    if wid() == "sniper":
        sp = 0.3 + aim_err * 0.5
    spray = minf(spray + 0.6 * (1.0 - skill * 0.7), 4.0)
    shoot(eye, fwd, sp)

func _retreat() -> void:
    var best := Vector3.ZERO
    var found := false
    for i in 12:
        var p: Vector3 = match_ref.nav.random_point()
        if p.distance_to(global_position) < 25.0 and not match_ref.nav.can_see(p + Vector3(0, 0.6, 0), enemy.global_position + Vector3(0, 1.4, 0)):
            best = p
            found = true
            break
    if found:
        _set_path(best)
        vis = false
        hold_t = 0.0

func _set_path(goal: Vector3) -> void:
    var nav = match_ref.nav
    path = PackedVector3Array()
    if randf() < 0.35 and skill > 0.2:
        path.append_array(nav.path(global_position, nav.random_point()))
        path.append_array(nav.path(path[path.size() - 1] if path.size() > 0 else global_position, goal))
    else:
        path = nav.path(global_position, goal)
    path_i = 0
    has_goal = path.size() > 0

func _navigate(delta: float) -> Vector3:
    if role == "plant" or role == "defuse":
        interacting = match_ref.can_interact(self)
        if interacting:
            return Vector3.ZERO
    else:
        interacting = false
    if hold_t > 0.0:
        hold_t -= delta
        scan_t -= delta
        if scan_t <= 0.0:
            scan_t = randf_range(0.8, 2.0)
            scan_yaw = rotation.y + randf_range(-1.1, 1.1)
        rotation.y += clampf(wrapf(scan_yaw - rotation.y, -PI, PI), -2.0 * delta, 2.0 * delta)
        return Vector3.ZERO
    if not has_goal or path_i >= path.size():
        if has_goal:
            has_goal = false
            hold_t = randf_range(0.5, 2.5) * (1.5 - skill)
            return Vector3.ZERO
        var g: Vector3
        if investigate and enemy != null or investigate:
            g = last_seen_pos
            investigate = false
        else:
            g = match_ref.bot_goal(self)
        _set_path(g)
        return Vector3.ZERO
    var target := path[path_i]
    var to := target - global_position
    to.y = 0.0
    if to.length() < 1.2:
        path_i += 1
        return Vector3.ZERO
    _face(to, turn_speed * 0.8, delta)
    stuck_t += delta
    if stuck_t > 0.8:
        if global_position.distance_to(last_pos) < 0.25:
            has_goal = false
        last_pos = global_position
        stuck_t = 0.0
    return to.normalized()
