class_name Nav
extends RefCounted
# Граф путевых точек по сетке (без запечённого navmesh): A* + проверка видимости.
var astar := AStar3D.new()
var ids: Array = []
var space: PhysicsDirectSpaceState3D

func build(world: World3D, half: float, step: float = 5.0) -> void:
    space = world.direct_space_state
    var shape := SphereShape3D.new()
    shape.radius = 0.7
    var q := PhysicsShapeQueryParameters3D.new()
    q.shape = shape
    q.collision_mask = 1
    var grid := {}
    var n := int(half * 2.0 / step)
    var idc := 0
    for ix in range(n + 1):
        for iz in range(n + 1):
            var p := Vector3(-half + ix * step, 0.9, -half + iz * step)
            q.transform = Transform3D(Basis(), p)
            if space.intersect_shape(q, 1).is_empty():
                astar.add_point(idc, p)
                grid[Vector2i(ix, iz)] = idc
                idc += 1
    var mshape := SphereShape3D.new()
    mshape.radius = 0.45
    var mq := PhysicsShapeQueryParameters3D.new()
    mq.shape = mshape
    mq.collision_mask = 1
    for key in grid:
        for d in [Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(1, -1)]:
            var k2: Vector2i = key + d
            if grid.has(k2):
                var a: Vector3 = astar.get_point_position(grid[key])
                var b: Vector3 = astar.get_point_position(grid[k2])
                mq.transform = Transform3D(Basis(), a)
                mq.motion = b - a
                var r := space.cast_motion(mq)
                if r.size() > 0 and r[0] >= 0.99:
                    astar.connect_points(grid[key], grid[k2])
    ids = astar.get_point_ids()

func path(a: Vector3, b: Vector3) -> PackedVector3Array:
    if ids.is_empty():
        return PackedVector3Array()
    var ia := astar.get_closest_point(a)
    var ib := astar.get_closest_point(b)
    if ia < 0 or ib < 0:
        return PackedVector3Array()
    return astar.get_point_path(ia, ib)

func random_point() -> Vector3:
    return astar.get_point_position(ids[randi() % ids.size()])

func can_see(a: Vector3, b: Vector3) -> bool:
    var r := PhysicsRayQueryParameters3D.create(a, b, 1)
    return space.intersect_ray(r).is_empty()
