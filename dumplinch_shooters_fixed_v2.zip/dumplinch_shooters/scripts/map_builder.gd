class_name MapBuilder
extends RefCounted
# Строит карты кодом: здания, ящики, контейнеры, машины, укрытия, точки бомбы.
# Карта 80x80 (x,z от -40 до 40). Спецназ спавнится на севере (z<0), террористы на юге.
var root: Node3D
var info := {"spawn_spec": [], "spawn_terror": [], "sites": [], "hot": []}

func build(map_id: String, parent: Node3D) -> Dictionary:
    root = parent
    info = {"spawn_spec": [], "spawn_terror": [], "sites": [], "hot": []}
    for i in 5:
        info.spawn_spec.append(Vector3(-8 + i * 4, 0.1, -36))
        info.spawn_terror.append(Vector3(-8 + i * 4, 0.1, 36))
    match map_id:
        "city":
            _city()
        "desert":
            _desert()
        "snow":
            _snow()
        _:
            _range()
    return info

func _env(top: Color, hor: Color, amb: float, sun: Color) -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    var sky := Sky.new()
    var psm := ProceduralSkyMaterial.new()
    psm.sky_top_color = top
    psm.sky_horizon_color = hor
    psm.ground_horizon_color = hor
    psm.ground_bottom_color = hor.darkened(0.3)
    sky.sky_material = psm
    env.sky = sky
    env.background_mode = Environment.BG_SKY
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = amb
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.adjustment_enabled = true
    env.adjustment_saturation = 1.3
    env.adjustment_contrast = 1.08
    env.glow_enabled = int(Settings.data.gfx) >= 1
    env.glow_intensity = 0.5
    we.environment = env
    root.add_child(we)
    var l := DirectionalLight3D.new()
    l.light_color = sun
    l.rotation_degrees = Vector3(-55, 35, 0)
    l.shadow_enabled = int(Settings.data.gfx) >= 1
    l.directional_shadow_max_distance = 90.0
    root.add_child(l)

func box(pos: Vector3, sz: Vector3, col: Color, collide: bool = true, rot_y: float = 0.0, surf: String = "") -> Node3D:
    var body: Node3D
    if collide:
        var sb := StaticBody3D.new()
        sb.collision_layer = 1
        sb.collision_mask = 0
        body = sb
    else:
        body = Node3D.new()
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = sz
    mi.mesh = bm
    mi.material_override = Mat.col(col)
    body.add_child(mi)
    if collide:
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = sz
        cs.shape = bs
        body.add_child(cs)
    body.position = pos
    body.rotation.y = rot_y
    if surf != "":
        body.set_meta("surf", surf)
    root.add_child(body)
    return body

func _ground(col: Color, surf: String) -> void:
    box(Vector3(0, -0.5, 0), Vector3(100, 1, 100), col, true, 0.0, surf)
    var wc := col.darkened(0.35)
    box(Vector3(0, 6, -41), Vector3(84, 12, 2), wc)
    box(Vector3(0, 6, 41), Vector3(84, 12, 2), wc)
    box(Vector3(-41, 6, 0), Vector3(2, 12, 84), wc)
    box(Vector3(41, 6, 0), Vector3(2, 12, 84), wc)

func _deco(pos: Vector3, sz: Vector3, col: Color) -> void:
    box(pos, sz, col, false)

func bld(x: float, z: float, w: float, d: float, h: float, col: Color) -> void:
    var b := box(Vector3(x, h * 0.5, z), Vector3(w, h, d), col, true, 0.0, "concrete")
    box_child(b, Vector3(0, h * 0.5 + 0.2, 0), Vector3(w + 0.5, 0.4, d + 0.5), col.darkened(0.25))
    if h > 5.0:
        for fy in [0.3, 0.68]:
            box_child(b, Vector3(0, h * (fy - 0.5), 0), Vector3(w + 0.08, 1.1, d + 0.08), Color(0.25, 0.4, 0.6))

func box_child(parent: Node3D, pos: Vector3, sz: Vector3, col: Color) -> void:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = sz
    mi.mesh = bm
    mi.material_override = Mat.col(col)
    mi.position = pos
    parent.add_child(mi)

func crate(x: float, z: float, s: float = 2.0, col: Color = Color(0.72, 0.5, 0.25), rot: float = 0.0) -> void:
    var b := box(Vector3(x, s * 0.5, z), Vector3(s, s, s), col, true, rot, "metal")
    box_child(b, Vector3(0, 0, 0), Vector3(s + 0.04, s * 0.12, s + 0.04), col.darkened(0.3))

func container(x: float, z: float, rot: float, col: Color) -> void:
    var b := box(Vector3(x, 1.3, z), Vector3(6, 2.6, 2.4), col, true, rot, "metal")
    for i in 5:
        box_child(b, Vector3(-2.4 + i * 1.2, 0, 0), Vector3(0.12, 2.64, 2.44), col.darkened(0.25))

func car(x: float, z: float, rot: float, col: Color) -> void:
    var b := box(Vector3(x, 0.8, z), Vector3(4.2, 1.6, 1.9), col, true, rot, "metal")
    box_child(b, Vector3(-0.2, 0.55, 0), Vector3(2.2, 0.7, 1.7), Color(0.6, 0.85, 1.0))
    for wx in [-1.3, 1.3]:
        for wz in [-0.95, 0.95]:
            var w := MeshInstance3D.new()
            var cm := CylinderMesh.new()
            cm.top_radius = 0.38
            cm.bottom_radius = 0.38
            cm.height = 0.25
            w.mesh = cm
            w.material_override = Mat.col(Color(0.08, 0.08, 0.1))
            w.rotation.x = PI / 2
            w.position = Vector3(wx, -0.45, wz)
            b.add_child(w)

func barricade(x: float, z: float, len: float, rot: float, col: Color = Color(0.7, 0.7, 0.72)) -> void:
    box(Vector3(x, 0.6, z), Vector3(len, 1.2, 0.7), col, true, rot, "concrete")

func wall(x: float, z: float, len: float, thick: float, h: float, col: Color, rot: float = 0.0) -> void:
    box(Vector3(x, h * 0.5, z), Vector3(len, h, thick), col, true, rot, "concrete")

func mound(x: float, z: float, r: float) -> void:
    var sb := StaticBody3D.new()
    sb.collision_layer = 1
    sb.collision_mask = 0
    var mi := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = r
    sm.height = r * 1.6
    mi.mesh = sm
    mi.material_override = Mat.col(Color(0.95, 0.97, 1.0))
    sb.add_child(mi)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(r * 1.6, r * 1.3, r * 1.6)
    cs.shape = bs
    cs.position.y = r * 0.15
    sb.add_child(cs)
    sb.position = Vector3(x, r * 0.35, z)
    sb.set_meta("surf", "snow")
    root.add_child(sb)

func lamp(x: float, z: float) -> void:
    box(Vector3(x, 2.5, z), Vector3(0.2, 5, 0.2), Color(0.3, 0.3, 0.35), false)
    box(Vector3(x, 5.1, z), Vector3(0.6, 0.3, 0.6), Color(1, 0.95, 0.6), false)

func site_marker(pos: Vector3, nm: String) -> void:
    var m := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 5.0
    cm.bottom_radius = 5.0
    cm.height = 0.06
    m.mesh = cm
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1, 0.9, 0.2, 0.35)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.material_override = mat
    m.position = Vector3(pos.x, 0.05, pos.z)
    root.add_child(m)
    var l := Label3D.new()
    l.text = nm
    l.font_size = 220
    l.pixel_size = 0.01
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.modulate = Color(1, 0.9, 0.2)
    l.position = Vector3(pos.x, 4.0, pos.z)
    root.add_child(l)
    info.sites.append({"name": nm, "pos": Vector3(pos.x, 0, pos.z)})

func _city() -> void:
    _env(Color(0.35, 0.6, 0.95), Color(0.85, 0.92, 1.0), 0.9, Color(1, 0.96, 0.85))
    _ground(Color(0.55, 0.57, 0.6), "concrete")
    var road := Color(0.22, 0.23, 0.27)
    _deco(Vector3(-11.5, 0.02, 0), Vector3(8, 0.04, 76), road)
    _deco(Vector3(11.5, 0.02, 0), Vector3(8, 0.04, 76), road)
    _deco(Vector3(0, 0.02, -20), Vector3(36, 0.04, 8), road)
    _deco(Vector3(0, 0.02, 20), Vector3(36, 0.04, 8), road)
    for i in range(-17, 18, 4):
        _deco(Vector3(-11.5, 0.05, i * 2.0), Vector3(0.3, 0.02, 2), Color(1, 1, 1))
        _deco(Vector3(11.5, 0.05, i * 2.0), Vector3(0.3, 0.02, 2), Color(1, 1, 1))
    var cols := [Color(0.95, 0.55, 0.45), Color(0.96, 0.8, 0.45), Color(0.55, 0.75, 0.92), Color(0.7, 0.86, 0.6), Color(0.86, 0.7, 0.92), Color(0.9, 0.9, 0.85), Color(0.6, 0.85, 0.85)]
    var B := [[-26, -20, 16, 12, 9], [26, -20, 16, 12, 10], [-26, 20, 16, 12, 8], [26, 20, 16, 12, 9], [0, 0, 10, 8, 6], [-37, 0, 5, 18, 8], [37, 0, 5, 18, 8]]
    for i in B.size():
        bld(B[i][0], B[i][1], B[i][2], B[i][3], B[i][4], cols[i % cols.size()])
    for p in [[-20, -5], [-20, -3], [-27, 5], [-27, 6.5], [-22, 6], [-30, -6], [20, 5], [20, 3], [27, -5], [27, -6.5], [22, -6], [30, 6]]:
        crate(p[0], p[1])
    barricade(-24, -6, 6, 0.0)
    barricade(24, 6, 6, 0.0)
    barricade(-16, 8, 5, 1.57)
    barricade(16, -8, 5, 1.57)
    car(-9, -7, 0.3, Color(0.9, 0.2, 0.2))
    car(9, 7, -0.2, Color(0.2, 0.4, 0.9))
    car(-8, 10, 1.4, Color(0.95, 0.8, 0.2))
    car(8, -10, 1.2, Color(0.3, 0.75, 0.4))
    car(0, -22, 0.0, Color(0.95, 0.95, 0.95))
    car(-14, 24, 1.57, Color(0.6, 0.3, 0.8))
    car(14, -24, 1.57, Color(0.9, 0.5, 0.2))
    for p in [[0, -8], [0, 8], [-3, -11], [3, 11], [-14, -33], [14, -33], [-14, 33], [14, 33]]:
        crate(p[0], p[1], 2.2, Color(0.5, 0.6, 0.7))
    container(0, -30, 0.0, Color(0.7, 0.3, 0.25))
    container(0, 30, 0.0, Color(0.25, 0.4, 0.7))
    barricade(-6, -18, 5, 0.0)
    barricade(6, 18, 5, 0.0)
    barricade(6, -16, 4, 1.57)
    barricade(-6, 16, 4, 1.57)
    for p in [[-16, -30], [16, -30], [-16, 30], [16, 30], [-8, 0], [8, 0]]:
        lamp(p[0], p[1])
    site_marker(Vector3(-24, 0, 0), "A")
    site_marker(Vector3(24, 0, 0), "B")
    info.hot = [Vector3(-24, 0, 0), Vector3(24, 0, 0), Vector3(0, 0, -20), Vector3(0, 0, 20), Vector3(-11, 0, 0), Vector3(11, 0, 0), Vector3(0, 0, -10), Vector3(0, 0, 10)]

func _desert() -> void:
    _env(Color(0.45, 0.7, 0.95), Color(1.0, 0.9, 0.7), 1.0, Color(1.0, 0.92, 0.75))
    _ground(Color(0.9, 0.78, 0.52), "sand")
    var tan := Color(0.85, 0.7, 0.5)
    bld(-26, -16, 18, 12, 8, tan)
    bld(26, 16, 18, 12, 8, tan)
    bld(0, 0, 8, 8, 5, Color(0.6, 0.62, 0.66))
    bld(-36, 20, 6, 14, 5, Color(0.8, 0.65, 0.45))
    bld(36, -20, 6, 14, 5, Color(0.8, 0.65, 0.45))
    var cc := [Color(0.8, 0.25, 0.2), Color(0.2, 0.4, 0.8), Color(0.25, 0.65, 0.35), Color(0.95, 0.6, 0.15)]
    var C := [[-12, -6, 1.57], [-12, 6, 1.57], [12, -6, 1.57], [12, 6, 1.57], [0, -14, 0.0], [0, 14, 0.0], [-33, 6, 0.0], [-28, 14, 1.57], [33, -6, 0.0], [28, -14, 1.57], [-20, -30, 0.0], [20, 30, 0.0], [-18, 4, 0.5], [18, -4, 0.5]]
    for i in C.size():
        container(C[i][0], C[i][1], C[i][2], cc[i % cc.size()])
    for p in [[-24, 8], [-28, 10], [-22, 14], [-26, 6], [24, -8], [28, -10], [22, -14], [26, -6], [-6, -22], [6, 22], [-4, 8], [4, -8]]:
        crate(p[0], p[1], 2.0, Color(0.6, 0.42, 0.22))
    for p in [[-24, 4, 0.0], [24, -4, 0.0], [-20, 12, 1.57], [20, -12, 1.57], [-8, -26, 0.0], [8, 26, 0.0], [-5, 0, 1.57], [5, 0, 1.57], [-16, -22, 0.4], [16, 22, 0.4]]:
        barricade(p[0], p[1], 6, p[2], Color(0.75, 0.65, 0.45))
    for p in [[-14, -34], [14, -34], [-14, 34], [14, 34]]:
        crate(p[0], p[1], 2.4, Color(0.4, 0.5, 0.35))
    site_marker(Vector3(-26, 0, 11), "A")
    site_marker(Vector3(26, 0, -11), "B")
    info.hot = [Vector3(-26, 0, 11), Vector3(26, 0, -11), Vector3(0, 0, -8), Vector3(0, 0, 8), Vector3(-14, 0, 0), Vector3(14, 0, 0), Vector3(0, 0, -20), Vector3(0, 0, 20)]

func _snow() -> void:
    _env(Color(0.6, 0.75, 0.95), Color(0.9, 0.95, 1.0), 1.1, Color(0.95, 0.97, 1.0))
    _ground(Color(0.93, 0.96, 1.0), "snow")
    var teal := Color(0.45, 0.75, 0.8)
    bld(0, 0, 14, 10, 7, teal)
    bld(-27, -18, 12, 10, 6, Color(0.7, 0.8, 0.9))
    bld(27, 18, 12, 10, 6, Color(0.7, 0.8, 0.9))
    bld(-27, 22, 10, 8, 5, teal)
    bld(27, -22, 10, 8, 5, teal)
    var wc := Color(0.75, 0.85, 0.92)
    for w in [[-14, -9, 12, 3.5], [14, 9, 12, 3.5], [-14, 9, 12, 3.5], [14, -9, 12, 3.5], [-22, 0, 1.0, 3.5], [22, 0, 1.0, 3.5]]:
        if w[2] > 1.5:
            wall(w[0], w[1], w[2], 1.2, w[3], wc)
        else:
            wall(w[0], w[1], 1.2, 8, w[3], wc)
    for m in [[-10, 14, 2.2], [10, -14, 2.2], [-18, -6, 1.9], [18, 6, 1.9], [0, -18, 2.5], [0, 18, 2.5], [-32, 0, 2.2], [32, 0, 2.2], [-6, 4, 1.9], [6, -4, 1.9]]:
        mound(m[0], m[1], m[2])
    for p in [[-26, 8], [-29, 10], [-23, 12], [26, -8], [29, -10], [23, -12], [-8, -24], [8, 24], [-14, 2], [14, -2]]:
        crate(p[0], p[1], 2.0, Color(0.55, 0.75, 0.9))
    for p in [[-26, 4, 0.0], [26, -4, 0.0], [-4, -14, 0.0], [4, 14, 0.0], [-18, 18, 1.57], [18, -18, 1.57]]:
        barricade(p[0], p[1], 5, p[2], Color(0.8, 0.9, 0.95))
    container(0, -30, 0.0, Color(0.3, 0.5, 0.75))
    container(0, 30, 0.0, Color(0.3, 0.5, 0.75))
    site_marker(Vector3(-26, 0, 9), "A")
    site_marker(Vector3(26, 0, -9), "B")
    info.hot = [Vector3(-26, 0, 9), Vector3(26, 0, -9), Vector3(0, 0, -14), Vector3(0, 0, 14), Vector3(-14, 0, 0), Vector3(14, 0, 0), Vector3(-14, 0, -20), Vector3(14, 0, 20)]

func _range() -> void:
    _env(Color(0.4, 0.65, 0.95), Color(0.9, 0.95, 1.0), 1.0, Color(1, 0.97, 0.9))
    _ground(Color(0.5, 0.6, 0.5), "concrete")
    for i in 8:
        _deco(Vector3(0, 0.03, 20 - i * 6), Vector3(60, 0.02, 0.2), Color(1, 1, 1))
    box(Vector3(0, 4, -34), Vector3(60, 8, 1), Color(0.3, 0.35, 0.4))
    crate(-6, 18, 1.2, Color(0.6, 0.45, 0.25))
    crate(6, 18, 1.2, Color(0.6, 0.45, 0.25))
    info.spawn_spec = [Vector3(0, 0.1, 28)]
    info.spawn_terror = [Vector3(0, 0.1, 28)]
