extends Control
# Главное меню: 3D-Дамплинч с idle-анимацией, кнопки, выбор команды, панели режима/карты/арсенала/агентов/магазина/профиля/статистики.
var overlay: Control
var preview_root: Node3D
var viewport: SubViewport
var char_node: Node3D
var legs: Array = []
var platform: MeshInstance3D
var tt := 0.0
var lvl_label: Label
var xp_bar: ProgressBar
var coin_label: Label

func _ready() -> void:
    theme = UI.make_theme()
    Sfx.play_music()
    var bg := ColorRect.new()
    bg.color = Color(0.08, 0.12, 0.25)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    _build_preview()
    _build_buttons()
    _build_top()
    _rebuild_character()

func _build_preview() -> void:
    var svc := SubViewportContainer.new()
    svc.stretch = true
    svc.set_anchors_preset(Control.PRESET_FULL_RECT)
    svc.anchor_right = 0.58
    add_child(svc)
    viewport = SubViewport.new()
    viewport.own_world_3d = true
    viewport.transparent_bg = true
    svc.add_child(viewport)
    preview_root = Node3D.new()
    viewport.add_child(preview_root)
    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_CLEAR_COLOR
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.8, 0.85, 1.0)
    env.ambient_light_energy = 0.7
    we.environment = env
    preview_root.add_child(we)
    var l := DirectionalLight3D.new()
    l.rotation_degrees = Vector3(-35, 30, 0)
    preview_root.add_child(l)
    var cam := Camera3D.new()
    cam.fov = 40.0
    preview_root.add_child(cam)
    cam.look_at_from_position(Vector3(0, 1.3, 4.2), Vector3(0, 0.95, 0))
    platform = MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 1.5
    cm.bottom_radius = 1.6
    cm.height = 0.15
    platform.mesh = cm
    platform.position.y = -0.08
    preview_root.add_child(platform)
    var tb := HBoxContainer.new()
    tb.anchor_top = 1.0
    tb.anchor_bottom = 1.0
    tb.anchor_right = 0.55
    tb.offset_left = 40
    tb.offset_top = -100
    tb.offset_bottom = -30
    tb.add_theme_constant_override("separation", 14)
    add_child(tb)
    for t in ["spec", "terror"]:
        var b := Button.new()
        b.text = Settings.t(t)
        b.toggle_mode = true
        b.button_pressed = (Settings.data.team == t)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(_on_team.bind(t))
        tb.add_child(b)
    var grp := ButtonGroup.new()
    for b in tb.get_children():
        b.button_group = grp

func _on_team(t: String) -> void:
    Settings.set_value("team", t)
    _rebuild_character()

func _rebuild_character() -> void:
    if char_node != null:
        char_node.queue_free()
    var t: String = Settings.data.team
    var v := Fighter.make_visual(t, int(Settings.data.agent))
    char_node = v.root
    legs = v.legs
    var gun := Weapons.model(Settings.data.primary)
    gun.scale = Vector3.ONE * 1.4
    v.weapon_slot.add_child(gun)
    char_node.scale = Vector3.ONE * 1.25
    preview_root.add_child(char_node)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Game.TEAM_COLORS[t]
    mat.emission_enabled = true
    mat.emission = Game.TEAM_COLORS[t]
    mat.emission_energy_multiplier = 0.8
    platform.material_override = mat

func _process(delta: float) -> void:
    tt += delta
    if char_node != null:
        char_node.rotation.y = sin(tt * 0.6) * 0.5
        char_node.position.y = absf(sin(tt * 2.0)) * 0.03
        if legs.size() == 2:
            legs[0].rotation.x = sin(tt * 2.0) * 0.05
            legs[1].rotation.x = -sin(tt * 2.0) * 0.05

func _build_top() -> void:
    var hb := HBoxContainer.new()
    hb.position = Vector2(40, 24)
    hb.add_theme_constant_override("separation", 20)
    add_child(hb)
    lvl_label = UI.label(hb, "", 36)
    xp_bar = ProgressBar.new()
    xp_bar.custom_minimum_size = Vector2(420, 36)
    xp_bar.show_percentage = false
    hb.add_child(xp_bar)
    coin_label = UI.label(hb, "", 32)
    _refresh_top()

func _refresh_top() -> void:
    var pr := Progress.level_progress()
    lvl_label.text = "%s %d" % [Settings.t("level"), Progress.level()]
    xp_bar.max_value = pr.y
    xp_bar.value = pr.x
    coin_label.text = "Монеты: %d" % Progress.coins

func _build_buttons() -> void:
    var box := VBoxContainer.new()
    box.anchor_left = 0.62
    box.anchor_right = 0.97
    box.anchor_top = 0.1
    box.anchor_bottom = 0.97
    box.add_theme_constant_override("separation", 10)
    add_child(box)
    UI.label(box, "DUMPLINCH SHOOTERS", 42)
    UI.btn(box, Settings.t("play"), _show_play, 84.0)
    UI.btn(box, Settings.t("mode"), _show_mode)
    UI.btn(box, Settings.t("map"), _show_map)
    UI.btn(box, Settings.t("arsenal"), _show_arsenal)
    UI.btn(box, Settings.t("agents"), _show_agents)
    UI.btn(box, Settings.t("shop"), _show_shop)
    UI.btn(box, Settings.t("settings"), _to_settings)
    UI.btn(box, Settings.t("profile"), _show_profile)
    UI.btn(box, Settings.t("stats"), _show_stats)

func _to_settings() -> void:
    Game.go("res://scenes/settings.tscn")

func _close_panel() -> void:
    if overlay != null:
        overlay.queue_free()
        overlay = null
    _refresh_top()

func _open_panel(title: String) -> VBoxContainer:
    _close_panel()
    overlay = Control.new()
    overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(overlay)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.65)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    overlay.add_child(dim)
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    overlay.add_child(cc)
    var pn := PanelContainer.new()
    pn.custom_minimum_size = Vector2(1300, 0)
    cc.add_child(pn)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 12)
    pn.add_child(vb)
    UI.label(vb, title, 46)
    var sc := ScrollContainer.new()
    sc.custom_minimum_size = Vector2(0, 560)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    vb.add_child(sc)
    var content := VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 12)
    sc.add_child(content)
    UI.btn(vb, Settings.t("back"), _close_panel)
    return content

func _mode_row(c: Node) -> void:
    UI.choice_row(c, "Режим", Game.MODES.values(), Game.MODES.keys().find(Game.mode), func(i): Settings.set_value("mode", Game.MODES.keys()[i]))

func _map_row(c: Node) -> void:
    UI.choice_row(c, "Карта", Game.MAPS.values(), Game.MAPS.keys().find(Game.map), func(i): Settings.set_value("map", Game.MAPS.keys()[i]))

func _show_play() -> void:
    var c := _open_panel("ПОДГОТОВКА МАТЧА")
    _mode_row(c)
    _map_row(c)
    UI.choice_row(c, "Команда", [Settings.t("spec"), Settings.t("terror")], 0 if Settings.data.team == "spec" else 1, func(i):
        Settings.set_value("team", "spec" if i == 0 else "terror")
        _rebuild_character())
    var items := ["Авто (по уровню)"]
    items.append_array(Game.DIFFS)
    UI.choice_row(c, "Сложность ботов", items, Game.difficulty + 1, func(i): Settings.set_value("diff", i - 1))
    UI.label(c, "Авто-сложность даёт опыт и рейтинг. Ручной выбор — развлекательный матч без опыта и рейтинга.", 26)
    UI.btn(c, Settings.t("start"), _start_match, 88.0)

func _start_match() -> void:
    Game.go("res://scenes/match.tscn")

func _show_mode() -> void:
    var c := _open_panel("ВЫБОР РЕЖИМА")
    _mode_row(c)
    UI.label(c, "Закладка бомбы: террористы ставят бомбу на точке A или B, спецназ мешает или обезвреживает. Раунды до 4 побед.", 28)
    UI.label(c, "Командный бой: до 20 устранений, возрождение через 3 секунды, матч 5 минут.", 28)

func _show_map() -> void:
    var c := _open_panel("ВЫБОР КАРТЫ")
    _map_row(c)
    UI.label(c, "Город: улицы, здания, машины. Пустынная база: контейнеры и ангары. Снежная лаборатория: сугробы и стены.", 28)

func _show_arsenal() -> void:
    var c := _open_panel("АРСЕНАЛ")
    UI.label(c, "Основное оружие выбирается здесь. Пистолет и нож всегда с вами, гранаты — 2 шт.", 26)
    for id in Weapons.PRIMARY:
        var d: Dictionary = Weapons.D[id]
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 14)
        c.add_child(row)
        var l := UI.label(row, "%s (%s)\nУрон %d  Скорострельность %.1f/с  Магазин %d  Перезарядка %.1f с  Отдача %.1f  Разброс %.1f" % [d.name, d.type, d.dmg, d.rate, d.mag, d.reload, d.recoil, d.spread], 24)
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        var b := Button.new()
        b.text = "ВЫБРАНО" if Settings.data.primary == id else "ВЫБРАТЬ"
        b.disabled = Settings.data.primary == id
        b.custom_minimum_size = Vector2(220, 80)
        b.pressed.connect(_pick_weapon.bind(id))
        row.add_child(b)

func _pick_weapon(id: String) -> void:
    Settings.set_value("primary", id)
    _rebuild_character()
    _show_arsenal()

func _show_agents() -> void:
    var c := _open_panel("АГЕНТЫ (внешний вид Дамплинча)")
    for i in Game.AGENTS.size():
        var a: Dictionary = Game.AGENTS[i]
        var owned: bool = Settings.data.unlocked.has(i)
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 14)
        c.add_child(row)
        var sw := ColorRect.new()
        sw.color = a.color
        sw.custom_minimum_size = Vector2(70, 70)
        row.add_child(sw)
        var l := UI.label(row, a.name + ("" if owned else "  (в магазине)"), 32)
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        var b := Button.new()
        b.custom_minimum_size = Vector2(240, 70)
        if not owned:
            b.text = "ЗАБЛОКИРОВАН"
            b.disabled = true
        elif Settings.data.agent == i:
            b.text = "ВЫБРАН"
            b.disabled = true
        else:
            b.text = "ВЫБРАТЬ"
            b.pressed.connect(_pick_agent.bind(i))
        row.add_child(b)

func _pick_agent(i: int) -> void:
    Settings.set_value("agent", i)
    _rebuild_character()
    _show_agents()

func _show_shop() -> void:
    var c := _open_panel("МАГАЗИН   Монеты: %d" % Progress.coins)
    UI.label(c, "Монеты начисляются за матчи с автоматической сложностью.", 26)
    for i in range(1, Game.AGENTS.size()):
        var a: Dictionary = Game.AGENTS[i]
        var owned: bool = Settings.data.unlocked.has(i)
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 14)
        c.add_child(row)
        var sw := ColorRect.new()
        sw.color = a.color
        sw.custom_minimum_size = Vector2(70, 70)
        row.add_child(sw)
        var l := UI.label(row, "Агент «%s»  —  %d монет" % [a.name, a.price], 32)
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        var b := Button.new()
        b.custom_minimum_size = Vector2(240, 70)
        if owned:
            b.text = "КУПЛЕНО"
            b.disabled = true
        else:
            b.text = "КУПИТЬ"
            b.disabled = Progress.coins < int(a.price)
            b.pressed.connect(_buy_agent.bind(i))
        row.add_child(b)

func _buy_agent(i: int) -> void:
    var price: int = Game.AGENTS[i].price
    if Progress.coins >= price:
        Progress.coins -= price
        Progress.save_all()
        var u: Array = Settings.data.unlocked.duplicate()
        u.append(i)
        Settings.set_value("unlocked", u)
    _show_shop()

func _show_profile() -> void:
    var c := _open_panel("ПРОФИЛЬ")
    var pr := Progress.level_progress()
    UI.label(c, "Уровень %d  (опыт %d / %d)" % [Progress.level(), pr.x, pr.y], 36)
    UI.label(c, "Монеты: %d" % Progress.coins, 32)
    UI.label(c, "Имя игрока:", 30)
    var le := LineEdit.new()
    le.text = Settings.data.name
    le.custom_minimum_size = Vector2(0, 70)
    le.text_changed.connect(func(t: String): Settings.set_value("name", t.substr(0, 16)))
    c.add_child(le)

func _show_stats() -> void:
    var c := _open_panel("СТАТИСТИКА")
    var total := Progress.wins + Progress.losses
    var wr := 0.0 if total == 0 else 100.0 * Progress.wins / total
    var kd := float(Progress.kills) / maxf(1.0, float(Progress.deaths))
    UI.label(c, "Победы: %d   Поражения: %d   Процент побед: %.0f%%" % [Progress.wins, Progress.losses, wr], 32)
    UI.label(c, "Устранения: %d   Смерти: %d   У/С: %.2f   Лучший матч (устранения): %d" % [Progress.kills, Progress.deaths, kd, Progress.best_kills], 32)
    UI.label(c, "История матчей:", 34)
    if Progress.history.is_empty():
        UI.label(c, "Пока пусто — сыграйте матч.", 28)
    for h in Progress.history:
        var res := "Ничья" if h.draw else ("Победа" if h.won else "Поражение")
        var tag := ("+%d XP" % h.xp) if h.rated else "развлекательный"
        UI.label(c, "%s | %s | %s | У/С/П: %d/%d/%d | %s" % [res, Game.MODES[h.mode], Game.MAPS[h.map], h.k, h.d, h.a, tag], 26)
