extends Node
# Звуки генерируются кодом (без аудиофайлов). Голос — через системный TTS.
var streams := {}
var music_player: AudioStreamPlayer

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    for n in ["Music", "SFX"]:
        if AudioServer.get_bus_index(n) == -1:
            AudioServer.add_bus()
            var i := AudioServer.get_bus_count() - 1
            AudioServer.set_bus_name(i, n)
            AudioServer.set_bus_send(i, "Master")
    _make_streams()
    Settings.changed.connect(apply_volumes)
    apply_volumes()

func apply_volumes() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(float(Settings.data.master_vol), 0.001)))
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Music"), linear_to_db(maxf(float(Settings.data.music_vol), 0.001)))
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("SFX"), linear_to_db(maxf(float(Settings.data.sfx_vol), 0.001)))

func _synth(freq: float, dur: float, vol: float, noise: float, decay: float, sweep: float = 0.0) -> AudioStreamWAV:
    var rate := 22050
    var n := int(rate * dur)
    var bytes := PackedByteArray()
    bytes.resize(n * 2)
    var ph := 0.0
    var lp := 0.0
    for i in n:
        var k := float(i) / n
        ph += TAU * freq * (1.0 + sweep * k) / rate
        var s := sin(ph) * (1.0 - noise)
        lp = lerpf(lp, randf() * 2.0 - 1.0, 0.35)
        s += lp * noise
        s *= exp(-decay * k) * vol
        bytes.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = bytes
    return w

func _concat(a: AudioStreamWAV, b: AudioStreamWAV) -> AudioStreamWAV:
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = a.mix_rate
    w.stereo = false
    w.data = a.data + b.data
    return w

func _make_streams() -> void:
    streams["shot_ak"] = _synth(180, 0.22, 0.7, 0.8, 7, -0.5)
    streams["shot_smg"] = _synth(240, 0.15, 0.6, 0.8, 9, -0.4)
    streams["shot_pistol"] = _synth(300, 0.18, 0.6, 0.75, 8, -0.5)
    streams["shot_shotgun"] = _synth(110, 0.4, 0.9, 0.9, 5, -0.4)
    streams["shot_sniper"] = _synth(90, 0.6, 1.0, 0.85, 4, -0.6)
    streams["shot_knife"] = _synth(900, 0.1, 0.3, 0.9, 10)
    streams["reload"] = _concat(_synth(700, 0.08, 0.4, 0.5, 8), _concat(_synth(0, 0.35, 0.0, 0.0, 1), _synth(1100, 0.08, 0.5, 0.5, 8)))
    streams["step_concrete"] = _synth(120, 0.08, 0.35, 0.9, 9)
    streams["step_sand"] = _synth(90, 0.12, 0.25, 1.0, 6)
    streams["step_snow"] = _synth(140, 0.15, 0.3, 1.0, 4)
    streams["step_metal"] = _synth(420, 0.1, 0.3, 0.5, 8)
    streams["hit"] = _synth(1500, 0.05, 0.4, 0.1, 6)
    streams["headshot"] = _synth(2200, 0.09, 0.5, 0.1, 5)
    streams["boom"] = _synth(60, 1.0, 1.0, 0.9, 3, -0.5)
    streams["beep"] = _synth(1000, 0.1, 0.4, 0.0, 3)
    streams["win"] = _concat(_synth(523, 0.15, 0.4, 0, 2), _concat(_synth(659, 0.15, 0.4, 0, 2), _synth(784, 0.35, 0.4, 0, 2)))
    streams["lose"] = _concat(_synth(392, 0.2, 0.4, 0, 2), _concat(_synth(330, 0.2, 0.4, 0, 2), _synth(262, 0.4, 0.4, 0, 2)))

func play(snd: String, pos = null, vol_db: float = 0.0) -> void:
    if not streams.has(snd) or get_child_count() > 40:
        return
    if pos == null:
        var p := AudioStreamPlayer.new()
        p.stream = streams[snd]
        p.bus = "SFX"
        p.volume_db = vol_db
        add_child(p)
        p.finished.connect(p.queue_free)
        p.play()
    else:
        var p3 := AudioStreamPlayer3D.new()
        p3.stream = streams[snd]
        p3.bus = "SFX"
        p3.volume_db = vol_db
        p3.max_distance = 90.0
        p3.unit_size = 10.0
        add_child(p3)
        p3.global_position = pos
        p3.finished.connect(p3.queue_free)
        p3.play()

func speak(text: String) -> void:
    if not bool(Settings.data.voice):
        return
    if DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
        var v := DisplayServer.tts_get_voices_for_language(Settings.data.lang)
        if v.is_empty():
            v = DisplayServer.tts_get_voices()
        if not v.is_empty():
            DisplayServer.tts_speak(text, v[0])

func _make_music() -> AudioStreamWAV:
    var rate := 22050
    var step := 0.25
    var notes := [261.6, 311.1, 392.0, 311.1, 349.2, 392.0, 466.2, 392.0, 261.6, 311.1, 392.0, 523.3, 466.2, 392.0, 349.2, 311.1]
    var bass := [65.4, 65.4, 65.4, 65.4, 87.3, 87.3, 87.3, 87.3, 98.0, 98.0, 98.0, 98.0, 77.8, 77.8, 77.8, 77.8]
    var sp := int(rate * step)
    var n := sp * 16
    var bytes := PackedByteArray()
    bytes.resize(n * 2)
    for i in n:
        var si := i / sp
        var local := float(i % sp) / rate
        var tt := float(i) / rate
        var env := exp(-5.0 * local) * minf(1.0, local * 300.0)
        var s := sin(TAU * notes[si] * tt) * 0.35 * env
        s += sin(TAU * bass[si] * tt) * 0.3
        bytes.encode_s16(i * 2, int(clampf(s * 0.6, -1.0, 1.0) * 32767.0))
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = bytes
    w.loop_mode = AudioStreamWAV.LOOP_FORWARD
    w.loop_begin = 0
    w.loop_end = n
    return w

func play_music() -> void:
    if music_player == null:
        music_player = AudioStreamPlayer.new()
        music_player.stream = _make_music()
        music_player.bus = "Music"
        add_child(music_player)
    if not music_player.playing:
        music_player.play()

func stop_music() -> void:
    if music_player != null:
        music_player.stop()
