class_name UI
extends RefCounted
# Стиль интерфейса (синий/жёлтый мультяшный) и помощники, всё кодом.
const KINDS := {
    "blue": [Color(0.2, 0.4, 0.85), Color(0.45, 0.7, 1.0)],
    "yellow": [Color(1.0, 0.76, 0.12), Color(0.85, 0.5, 0.05)],
    "green": [Color(0.32, 0.78, 0.2), Color(0.15, 0.5, 0.1)],
    "red": [Color(0.85, 0.22, 0.22), Color(0.5, 0.1, 0.1)],
    "dark": [Color(0.12, 0.2, 0.42), Color(0.3, 0.45, 0.8)],
}
const TEXT_DARK := Color(0.25, 0.12, 0.0)
const OUTLINE := Color(0.04, 0.08, 0.25)

static func box(bg: Color, border: Color, rad: int = 16, bw: int = 4, bb: int = 7) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.border_width_left = bw
    s.border_width_right = bw
    s.border_width_top = bw
    s.border_width_bottom = bb
    s.set_corner_radius_all(rad)
    s.content_margin_left = 20
    s.content_margin_right = 20
    s.content_margin_top = 10
    s.content_margin_bottom = 10
    s.shadow_color = Color(0, 0, 0, 0.3)
    s.shadow_size = 5
    s.shadow_offset = Vector2(0, 3)
    return s

static func _circle_tex(r: int, c: Color) -> ImageTexture:
    var img := Image.create(r * 2, r * 2, false, Image.FORMAT_RGBA8)
    for x in range(r * 2):
        for y in range(r * 2):
            var d := Vector2(x + 0.5 - r, y + 0.5 - r).length()
            if d <= r:
                img.set_pixel(x, y, c if d > r - 4 else Color(1, 1, 1))
    return ImageTexture.create_from_image(img)

static func style_btn(b: Button, kind: String) -> void:
    var k: Array = KINDS[kind]
    var bg: Color = k[0]
    var bd: Color = k[1]
    b.add_theme_stylebox_override("normal", box(bg, bd))
    b.add_theme_stylebox_override("hover", box(bg.lightened(0.12), bd))
    b.add_theme_stylebox_override("pressed", box(bg.darkened(0.15), bd, 16, 4, 3))
    b.add_theme_stylebox_override("disabled", box(Color(0.3, 0.33, 0.4), Color(0.2, 0.22, 0.3)))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    if kind == "yellow":
        for n in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
            b.add_theme_color_override(n, TEXT_DARK)
        b.add_theme_constant_override("outline_size", 0)

static func style_choice(b: Button) -> void:
    var k: Array = KINDS["dark"]
    var y: Array = KINDS["yellow"]
    b.add_theme_stylebox_override("normal", box(k[0], k[1]))
    b.add_theme_stylebox_override("hover", box((k[0] as Color).lightened(0.1), k[1]))
    b.add_theme_stylebox_override("pressed", box(y[0], y[1]))
    b.add_theme_stylebox_override("hover_pressed", box(y[0], y[1]))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.add_theme_color_override("font_pressed_color", TEXT_DARK)
    b.add_theme_color_override("font_hover_pressed_color", TEXT_DARK)

static func make_theme() -> Theme:
    var t := Theme.new()
    t.default_font_size = 30
    var k: Array = KINDS["blue"]
    t.set_stylebox("normal", "Button", box(k[0], k[1]))
    t.set_stylebox("hover", "Button", box((k[0] as Color).lightened(0.12), k[1]))
    t.set_stylebox("pressed", "Button", box((k[0] as Color).darkened(0.15), k[1], 16, 4, 3))
    t.set_stylebox("disabled", "Button", box(Color(0.3, 0.33, 0.4), Color(0.2, 0.22, 0.3)))
    t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
    t.set_color("font_outline_color", "Button", OUTLINE)
    t.set_constant("outline_size", "Button", 5)
    for st in ["normal", "hover", "pressed", "disabled", "focus"]:
        t.set_stylebox(st, "OptionButton", t.get_stylebox(st, "Button"))
    t.set_color("font_outline_color", "OptionButton", OUTLINE)
    t.set_constant("outline_size", "OptionButton", 5)
    var pn := box(Color(0.08, 0.15, 0.38, 0.96), Color(0.3, 0.5, 0.95), 22, 4, 4)
    pn.set_content_margin_all(22)
    t.set_stylebox("panel", "PanelContainer", pn)
    t.set_stylebox("normal", "LineEdit", box(Color(0.05, 0.1, 0.25), Color(0.3, 0.45, 0.8), 12, 3, 3))
    var tr := StyleBoxFlat.new()
    tr.bg_color = Color(0.05, 0.1, 0.25)
    tr.set_corner_radius_all(8)
    tr.content_margin_top = 7
    tr.content_margin_bottom = 7
    t.set_stylebox("slider", "HSlider", tr)
    var fl := StyleBoxFlat.new()
    fl.bg_color = Color(0.3, 0.7, 1.0)
    fl.set_corner_radius_all(8)
    fl.content_margin_top = 7
    fl.content_margin_bottom = 7
    t.set_stylebox("grabber_area", "HSlider", fl)
    t.set_stylebox("grabber_area_highlight", "HSlider", fl)
    var g := _circle_tex(22, Color(0.55, 0.75, 1.0))
    t.set_icon("grabber", "HSlider", g)
    t.set_icon("grabber_highlight", "HSlider", g)
    t.set_icon("grabber_disabled", "HSlider", g)
    var pb_bg := box(Color(0.04, 0.08, 0.2), Color(0.2, 0.3, 0.6), 10, 3, 3)
    var pb_fill := StyleBoxFlat.new()
    pb_fill.bg_color = Color(0.25, 0.65, 1.0)
    pb_fill.set_corner_radius_all(8)
    t.set_stylebox("background", "ProgressBar", pb_bg)
    t.set_stylebox("fill", "ProgressBar", pb_fill)
    return t

static func label(parent: Node, text: String, size: int = 30) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    parent.add_child(l)
    return l

static func para(parent: Node, text: String, size: int, width: float) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.custom_minimum_size.x = width
    parent.add_child(l)
    return l

static func outlined(parent: Node, text: String, size: int, col: Color, outline: Color = OUTLINE, osize: int = 12) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", col)
    l.add_theme_color_override("font_outline_color", outline)
    l.add_theme_constant_override("outline_size", osize)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    parent.add_child(l)
    return l

static func btn(parent: Node, text: String, cb: Callable, h: float = 72.0, kind: String = "blue") -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, h)
    style_btn(b, kind)
    b.pressed.connect(cb)
    parent.add_child(b)
    return b

static func btn_icon(parent: Node, icon: String, text: String, cb: Callable, h: float = 72.0, kind: String = "blue") -> Button:
    var b := Button.new()
    b.custom_minimum_size = Vector2(0, h)
    style_btn(b, kind)
    b.pressed.connect(cb)
    parent.add_child(b)
    var hb := HBoxContainer.new()
    hb.set_anchors_preset(Control.PRESET_FULL_RECT)
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    hb.add_theme_constant_override("separation", 14)
    hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_child(hb)
    var ic := UIIcon.new(icon, TEXT_DARK if kind == "yellow" else Color.WHITE, h * 0.55)
    hb.add_child(ic)
    if text != "":
        var l := Label.new()
        l.text = text
        l.add_theme_font_size_override("font_size", int(clampf(h * 0.4, 24, 44)))
        if kind == "yellow":
            l.add_theme_color_override("font_color", TEXT_DARK)
        else:
            l.add_theme_color_override("font_outline_color", OUTLINE)
            l.add_theme_constant_override("outline_size", 6)
        l.mouse_filter = Control.MOUSE_FILTER_IGNORE
        hb.add_child(l)
    return b

static func icon_square(parent: Node, icon: String, cb: Callable, s: float = 76.0, kind: String = "dark") -> Button:
    var b := btn_icon(parent, icon, "", cb, s, kind)
    b.custom_minimum_size = Vector2(s, s)
    return b

static func banner(parent: Node, text: String, size: int = 52) -> PanelContainer:
    var pn := PanelContainer.new()
    pn.add_theme_stylebox_override("panel", box(Color(0.1, 0.22, 0.55), Color(0.04, 0.1, 0.3), 10, 4, 4))
    parent.add_child(pn)
    outlined(pn, text, size, Color.WHITE, OUTLINE, 8)
    return pn

static func logo(parent: Node, sc: float = 1.0) -> VBoxContainer:
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", int(-24 * sc))
    parent.add_child(vb)
    outlined(vb, "DUMPLINCH", int(96 * sc), Color.WHITE, Color(0.05, 0.1, 0.35), int(18 * sc))
    outlined(vb, "SHOOTERS", int(100 * sc), Color(1.0, 0.78, 0.1), Color(0.35, 0.18, 0.0), int(18 * sc))
    return vb

static func coin_pill(parent: Node, amount: int, cb: Callable) -> PanelContainer:
    var pn := PanelContainer.new()
    var st := box(Color(0.06, 0.12, 0.3, 0.95), Color(0.2, 0.3, 0.6), 26, 3, 3)
    st.content_margin_top = 4
    st.content_margin_bottom = 4
    pn.add_theme_stylebox_override("panel", st)
    parent.add_child(pn)
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 14)
    pn.add_child(hb)
    hb.add_child(UIIcon.new("coin", Color.WHITE, 52))
    var l := Label.new()
    l.text = str(amount)
    l.add_theme_font_size_override("font_size", 36)
    l.custom_minimum_size.x = 90
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hb.add_child(l)
    var plus := icon_square(hb, "plus", cb, 56.0, "green")
    plus.custom_minimum_size = Vector2(56, 56)
    return pn

static func choice_row(parent: Node, text: String, items: Array, cur: int, cb: Callable) -> void:
    var box_ := VBoxContainer.new()
    parent.add_child(box_)
    label(box_, text, 28)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 10)
    box_.add_child(row)
    var group := ButtonGroup.new()
    for i in items.size():
        var b := Button.new()
        b.text = str(items[i])
        b.toggle_mode = true
        b.button_group = group
        b.button_pressed = (i == cur)
        b.custom_minimum_size = Vector2(0, 66)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        style_choice(b)
        b.pressed.connect(cb.bind(i))
        row.add_child(b)

static func slider(parent: Node, text: String, key: String, mn: float, mx: float, step: float, as_pct: bool = false) -> HSlider:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 14)
    parent.add_child(row)
    var l := Label.new()
    l.text = text
    l.custom_minimum_size.x = 520
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    row.add_child(l)
    var s := HSlider.new()
    s.min_value = mn
    s.max_value = mx
    s.step = step
    s.value = float(Settings.data[key])
    s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    s.custom_minimum_size = Vector2(300, 56)
    row.add_child(s)
    var v := Label.new()
    v.custom_minimum_size.x = 110
    v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    row.add_child(v)
    var fmt := func(x: float) -> String:
        return ("%d%%" % int(x * 100.0)) if as_pct else ("%.2f" % x)
    v.text = fmt.call(s.value)
    s.value_changed.connect(func(x: float):
        Settings.set_value(key, x)
        v.text = fmt.call(x))
    return s

static func toggle(parent: Node, text: String, key: String) -> Button:
    var row := HBoxContainer.new()
    parent.add_child(row)
    var l := Label.new()
    l.text = text
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(l)
    var b := Button.new()
    b.toggle_mode = true
    b.custom_minimum_size = Vector2(170, 60)
    b.button_pressed = bool(Settings.data[key])
    var upd := func():
        b.text = "Вкл" if b.button_pressed else "Выкл"
        style_btn(b, "green" if b.button_pressed else "dark")
    upd.call()
    b.toggled.connect(func(on: bool):
        Settings.set_value(key, on)
        upd.call())
    row.add_child(b)
    return b

static func reward_popup(parent: Node, big: String, sub: String, color: Color, on_ok: Callable, agent: bool = false) -> void:
    var ov := Control.new()
    ov.set_anchors_preset(Control.PRESET_FULL_RECT)
    parent.add_child(ov)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.75)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    ov.add_child(dim)
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    ov.add_child(cc)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 12)
    vb.custom_minimum_size = Vector2(760, 0)
    cc.add_child(vb)
    var rb := PanelContainer.new()
    rb.add_theme_stylebox_override("panel", box(Color(0.95, 0.65, 0.1), Color(0.55, 0.3, 0.0), 12, 4, 4))
    vb.add_child(rb)
    outlined(rb, "Награда получена!", 56, Color.WHITE, Color(0.45, 0.22, 0.0), 10)
    if agent:
        var t := TileIcon.new("agent", "", color)
        t.custom_minimum_size = Vector2(0, 220)
        vb.add_child(t)
    else:
        var ic := UIIcon.new("coin", Color.WHITE, 200)
        ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
        vb.add_child(ic)
    outlined(vb, big, 80, Color(1.0, 0.8, 0.15), Color(0.35, 0.18, 0.0), 14)
    if sub != "":
        outlined(vb, sub, 30, Color.WHITE, OUTLINE, 6)
    var done := func():
        ov.queue_free()
        on_ok.call()
    var ok := btn(vb, "OK", done, 92.0, "green")
    ok.custom_minimum_size.x = 420
    ok.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
