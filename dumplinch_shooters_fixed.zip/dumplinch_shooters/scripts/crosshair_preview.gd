extends Control

func _ready() -> void:
    custom_minimum_size = Vector2(160, 120)
    Settings.changed.connect(queue_redraw)

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.1, 0.12, 0.18), true)
    Hud.draw_crosshair(self, size * 0.5)
