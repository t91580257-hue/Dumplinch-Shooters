extends Control
# Главное меню в стиле референсов: 3D-сцена пустынной базы + Дамплинч, кнопки слева,
# карточки режимов, инвентарь+магазин с кейсом, профиль, статистика.
const CAM_POS := Vector3(-27.0, 1.5, 16.5)
const CAM_TARGET := Vector3(-25.5, 1.3, 8.0)

var viewport: SubViewport
var scene_root: Node3D
var char_node: Node3D
var legs: Array = []
var ui_root: Control
var screen: Control
var tt := 0.0
var timer_label: Label
var char_base := Vector3.ZERO
var char_yaw := 0.0

func _ready() -> void:
    theme = UI.make_theme()
    Sfx.play_music()
    _build_scene()
    ui_root = Control.new()
    ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
    ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(ui_root)
    _build_main_ui()
    _rebuild_character()

func _build_scene() -> void:
    var svc := SubViewportContainer.new()
    svc.stretch = true
    svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
    svc.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(svc)
    viewport = SubViewport.new()
    viewport.own_world_3d = true
    viewport.msaa_3d = Viewport.MSAA_2X
    svc.add_child(viewport)
    scene_root = Node3D.new()
    viewport.add_child(scene_root)
    MapBuilder.new().build("desert", scene_root)
    var cam := Camera3D.new()
    cam.fov = 45.0
    scene_root.add_child(cam)
    cam.look_at_from_position(CAM_POS, CAM_TARGET)

func _rebuild_character() -> void:
    if char_node != null:
        char_node.queue_free()
    var t: String = Settings.data.team
    var v := Fighter.make_visual(t, int(Settings.data.agent))
    char_node = v.root
    legs = v.legs
    var gun := Weapons.model(Settings.data.primary)
    gun.scale = Vector3.ONE * 1.6
    v.weapon_slot.add_child(gun)
    char_node.scale = Vector3.ONE * 1.2
    scene_root.add_child(char_node)
    var fwd := (CAM_TARGET - CAM_POS).normalized()
    var right := fwd.cross(Vector3.UP).normalized()
    var p := CAM_POS + fwd * 3.4 + right * 0.95
    p.y = 0.0
    char_base = p
    char_node.position = p
    char_yaw = atan2(fwd.x, fwd.z) + 0.45

func _process(delta: float) -> void:
    tt += delta
    if char_node != null:
        char_node.rotation.y = char_yaw + sin(tt * 0.7) * 0.12
        char_node.position.y = char_base.y + absf(sin(tt * 1.8)) * 0.02
        if legs.size() == 2:
            legs[0].rotation.x = sin(tt * 1.8) * 0.04
            legs[1].rotation.x = -sin(tt * 1.8) * 0.04
    if timer_label != null:
        _update_case_timer()

# ---------- главный экран ----------
func _refresh_main() -> void:
    for c in ui_root.get_children():
        c.queue_free()
    _build_main_ui()

func _build_main_ui() -> void:
    var logo := UI.logo(ui_root, 1.0)
    logo.position = Vector2(50, 20)
    _top_bar(ui_root)
    var col := VBoxContainer.new()
    col.position = Vector2(50, 400)
    col.custom_minimum_size = Vector2(560, 0)
    col.add_theme_constant_override("separation", 12)
    ui_root.add_child(col)
    UI.btn_icon(col, "play", "Играть", _show_modes, 112.0, "yellow")
    UI.btn_icon(col, "bag", "Инвентарь", _show_inventory.bind(0), 76.0)
    UI.btn_icon(col, "cart", "Магазин", _show_inventory.bind(1), 76.0)
    UI.btn_icon(col, "bars", "Статистика", _show_stats, 76.0)
    UI.btn_icon(col, "gear", "Настройки", _to_settings, 76.0)
    UI.btn_icon(col, "door", "Выход", _quit, 76.0)
    var card := Button.new()
    UI.style_btn(card, "dark")
    card.anchor_left = 1.0
    card.anchor_right = 1.0
    card.anchor_top = 1.0
    card.anchor_bottom = 1.0
    card.offset_left = -640
    card.offset_right = -40
    card.offset_top = -190
    card.offset_bottom = -40
    card.pressed.connect(_show_modes)
    ui_root.add_child(card)
    var hb := HBoxContainer.new()
    hb.set_anchors_preset(Control.PRESET_FULL_RECT)
    hb.offset_left = 20
    hb.offset_right = -20
    hb.add_theme_constant_override("separation", 20)
    hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    card.add_child(hb)
    var th := ColorRect.new()
    th.color = _map_color(Game.map)
    th.custom_minimum_size = Vector2(130, 100)
    th.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hb.add_child(th)
    var vb := VBoxContainer.new()
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    vb.alignment = BoxContainer.ALIGNMENT_CENTER
    vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hb.add_child(vb)
    var l1 := UI.label(vb, Game.MODES[Game.mode], 34)
    l1.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var l2 := UI.label(vb, "%s  |  5v5" % Game.MAPS[Game.map], 24)
    l2.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hb.add_child(UIIcon.new("play", Color.WHITE, 60))

func _map_color(m: String) -> Color:
    return {"city": Color(0.5, 0.6, 0.8), "desert": Color(0.9, 0.75, 0.5), "snow": Color(0.85, 0.93, 1.0)}.get(m, Color.GRAY)

func _top_bar(parent: Control) -> void:
    var hb := HBoxContainer.new()
    hb.anchor_left = 1.0
    hb.anchor_right = 1.0
    hb.offset_left = -760
    hb.offset_right = -30
    hb.offset_top = 22
    hb.add_theme_constant_override("separation", 14)
    hb.alignment = BoxContainer.ALIGNMENT_END
    parent.add_child(hb)
    var lv := PanelContainer.new()
    var st := UI.box(Color(0.06, 0.12, 0.3, 0.95), Color(0.2, 0.3, 0.6), 26, 3, 3)
    st.content_margin_top = 6
    st.content_margin_bottom = 6
    lv.add_theme_stylebox_override("panel", st)
    hb.add_child(lv)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 2)
    lv.add_child(vb)
    var pr := Progress.level_progress()
    UI.label(vb, "Уровень %d" % Progress.level(), 26)
    var bar := ProgressBar.new()
    bar.custom_minimum_size = Vector2(200, 16)
    bar.max_value = pr.y
    bar.value = pr.x
    bar.show_percentage = false
    vb.add_child(bar)
    UI.coin_pill(hb, Progress.coins, _show_inventory.bind(1))
    UI.icon_square(hb, "gear", _to_settings, 76.0)

func _quit() -> void:
    get_tree().quit()

func _to_settings() -> void:
    Game.go("res://scenes/settings.tscn")

# ---------- экраны ----------
func _new_screen(dim: float = 0.0) -> Control:
    _close_screen(false)
    screen = Control.new()
    screen.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(screen)
    if dim > 0.0:
        var d := ColorRect.new()
        d.color = Color(0.02, 0.05, 0.15, dim)
        d.set_anchors_preset(Control.PRESET_FULL_RECT)
        screen.add_child(d)
    ui_root.visible = false
    return screen

func _close_screen(show_main: bool = true) -> void:
    if screen != null:
        screen.queue_free()
        screen = null
    timer_label = null
    if show_main:
        ui_root.visible = true
        _refresh_main()
        _rebuild_character()

func _header(s: Control, with_logo: bool = true) -> void:
    var back := UI.btn_icon(s, "back", "Назад", _close_screen, 76.0)
    back.position = Vector2(24, 22)
    back.size = Vector2(200, 76)
    if with_logo:
        var lg := UI.logo(s, 0.6)
        lg.position = Vector2(270, 8)
    _top_bar(s)

# ----- выбор режима -----
func _show_modes() -> void:
    var s := _new_screen()
    _header(s)
    var bn := UI.banner(s, "ВЫБОР РЕЖИМА")
    bn.position = Vector2(780, 170)
    var infos := {
        "bomb": ["bomb", "ЗАКЛАДКА БОМБЫ", "Террористы ставят бомбу, спецназ мешает!", "5v5  |  раунды"],
        "tdm": ["skull", "КОМАНДНЫЙ БОЙ", "Уничтожьте команду противника!", "5v5  |  до 20"],
    }
    var row := HBoxContainer.new()
    row.position = Vector2(640, 280)
    row.add_theme_constant_override("separation", 40)
    s.add_child(row)
    var group := ButtonGroup.new()
    for key in ["bomb", "tdm"]:
        var inf: Array = infos[key]
        var card := Button.new()
        card.toggle_mode = true
        card.button_group = group
        card.button_pressed = (Game.mode == key)
        card.custom_minimum_size = Vector2(420, 560)
        var on := UI.box(Color(0.15, 0.3, 0.7), Color(1, 1, 1), 22, 6, 6)
        var off := UI.box(Color(0.12, 0.22, 0.5), Color(0.04, 0.08, 0.25), 22, 4, 4)
        card.add_theme_stylebox_override("normal", off)
        card.add_theme_stylebox_override("hover", off)
        card.add_theme_stylebox_override("pressed", on)
        card.add_theme_stylebox_override("hover_pressed", on)
        card.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
        card.pressed.connect(func(): Settings.set_value("mode", key))
        row.add_child(card)
        var vb := VBoxContainer.new()
        vb.set_anchors_preset(Control.PRESET_FULL_RECT)
        vb.offset_left = 14
        vb.offset_right = -14
        vb.offset_top = 14
        vb.offset_bottom = -14
        vb.add_theme_constant_override("separation", 8)
        vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
        card.add_child(vb)
        var ic := UIIcon.new(inf[0], Color.WHITE, 100)
        ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
        vb.add_child(ic)
        var t1 := UI.outlined(vb, inf[1], 40, Color.WHITE, UI.OUTLINE, 8)
        t1.mouse_filter = Control.MOUSE_FILTER_IGNORE
        var t2 := UI.label(vb, inf[2], 26)
        t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        t2.mouse_filter = Control.MOUSE_FILTER_IGNORE
        var prev := ColorRect.new()
        prev.color = Color(0.3, 0.5, 0.85)
        prev.size_flags_vertical = Control.SIZE_EXPAND_FILL
        prev.mouse_filter = Control.MOUSE_FILTER_IGNORE
        vb.add_child(prev)
        var hb := HBoxContainer.new()
        hb.set_anchors_preset(Control.PRESET_FULL_RECT)
        hb.alignment = BoxContainer.ALIGNMENT_CENTER
        hb.add_theme_constant_override("separation", 40)
        hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
        prev.add_child(hb)
        var b1 := ColorRect.new()
        b1.color = Game.TEAM_COLORS["spec"]
        b1.custom_minimum_size = Vector2(110, 130)
        b1.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        b1.mouse_filter = Control.MOUSE_FILTER_IGNORE
        hb.add_child(b1)
        var b2 := ColorRect.new()
        b2.color = Game.TEAM_COLORS["terror"]
        b2.custom_minimum_size = Vector2(110, 130)
        b2.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        b2.mouse_filter = Control.MOUSE_FILTER_IGNORE
        hb.add_child(b2)
        var t3 := UI.outlined(vb, inf[3], 32, Color.WHITE, UI.OUTLINE, 6)
        t3.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var st := UI.btn_icon(s, "trophy", "СТАТИСТИКА", _show_stats, 90.0, "dark")
    st.anchor_top = 1.0
    st.anchor_bottom = 1.0
    st.offset_left = 24
    st.offset_right = 440
    st.offset_top = -120
    st.offset_bottom = -30
    var go := UI.btn_icon(s, "play", "ВЫБРАТЬ", _show_prep, 100.0, "yellow")
    go.anchor_left = 1.0
    go.anchor_right = 1.0
    go.anchor_top = 1.0
    go.anchor_bottom = 1.0
    go.offset_left = -460
    go.offset_right = -30
    go.offset_top = -140
    go.offset_bottom = -30

# ----- подготовка матча -----
func _show_prep() -> void:
    var s := _new_screen(0.35)
    _header(s)
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    cc.offset_top = 120
    s.add_child(cc)
    var pn := PanelContainer.new()
    pn.custom_minimum_size = Vector2(1300, 0)
    cc.add_child(pn)
    var c := VBoxContainer.new()
    c.add_theme_constant_override("separation", 14)
    pn.add_child(c)
    UI.outlined(c, "ПОДГОТОВКА МАТЧА: " + Game.MODES[Game.mode], 44, Color.WHITE)
    UI.choice_row(c, "Карта", Game.MAPS.values(), Game.MAPS.keys().find(Game.map), func(i): Settings.set_value("map", Game.MAPS.keys()[i]))
    UI.choice_row(c, "Команда", [Settings.t("spec"), Settings.t("terror")], 0 if Settings.data.team == "spec" else 1, _pick_team)
    var items := ["Авто (по уровню)"]
    items.append_array(Game.DIFFS)
    UI.choice_row(c, "Сложность ботов", items, Game.difficulty + 1, func(i): Settings.set_value("diff", i - 1))
    UI.para(c, "Авто-сложность даёт опыт и рейтинг. Ручной выбор — развлекательный матч без опыта и рейтинга.", 24, 1200)
    UI.btn_icon(c, "play", "НАЧАТЬ МАТЧ", _start_match, 96.0, "yellow")

func _pick_team(i: int) -> void:
    Settings.set_value("team", "spec" if i == 0 else "terror")

func _start_match() -> void:
    Game.go("res://scenes/match.tscn")

# ----- инвентарь + магазин -----
func _show_inventory(tab: int = 0) -> void:
    var s := _new_screen(0.3)
    _header(s)
    var root := HBoxContainer.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.offset_left = 24
    root.offset_right = -24
    root.offset_top = 170
    root.offset_bottom = -170
    root.add_theme_constant_override("separation", 24)
    s.add_child(root)
    var side := VBoxContainer.new()
    side.custom_minimum_size = Vector2(250, 0)
    side.add_theme_constant_override("separation", 10)
    root.add_child(side)
    UI.btn_icon(side, "bag", "Инвентарь", _show_inventory.bind(0), 96.0, "yellow" if tab == 0 else "dark")
    UI.btn_icon(side, "cart", "Магазин", _show_inventory.bind(1), 96.0, "yellow" if tab == 1 else "dark")
    UI.btn_icon(side, "bars", "Статистика", _show_stats, 96.0, "dark")
    UI.btn_icon(side, "gear", "Настройки", _to_settings, 96.0, "dark")
    # инвентарь
    var inv := PanelContainer.new()
    inv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    root.add_child(inv)
    var iv := VBoxContainer.new()
    iv.add_theme_constant_override("separation", 12)
    inv.add_child(iv)
    var th := HBoxContainer.new()
    th.add_theme_constant_override("separation", 12)
    iv.add_child(th)
    th.add_child(UIIcon.new("bag", Color.WHITE, 60))
    UI.outlined(th, "Инвентарь" if tab == 0 else "Скины", 46, Color.WHITE, UI.OUTLINE, 8)
    var tabs := HBoxContainer.new()
    tabs.add_theme_constant_override("separation", 10)
    iv.add_child(tabs)
    UI.btn_icon(tabs, "crosshair", "Оружие", _show_inventory.bind(0), 70.0, "yellow" if tab == 0 else "dark").size_flags_horizontal = Control.SIZE_EXPAND_FILL
    UI.btn_icon(tabs, "person", "Скины", _show_inventory.bind(1), 70.0, "yellow" if tab == 1 else "dark").size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var sc := ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    iv.add_child(sc)
    var grid := GridContainer.new()
    grid.columns = 3
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 12)
    grid.add_theme_constant_override("v_separation", 12)
    sc.add_child(grid)
    if tab == 0:
        for id in Weapons.D.keys():
            var d: Dictionary = Weapons.D[id]
            var sel: bool = Settings.data.primary == id
            var can: bool = Weapons.PRIMARY.has(id)
            _tile(grid, d.name, sel, "weapon", id, Color.WHITE, _pick_weapon.bind(id) if can else Callable(), "" if can else "всегда с вами")
    else:
        for i in Game.AGENTS.size():
            var a: Dictionary = Game.AGENTS[i]
            var owned: bool = Settings.data.unlocked.has(i)
            var sel2: bool = int(Settings.data.agent) == i
            var sub := "" if owned else "закрыто"
            _tile(grid, a.name, sel2, "agent", "", a.color, _pick_agent.bind(i) if owned else Callable(), sub)
    # магазин
    var shop := PanelContainer.new()
    shop.custom_minimum_size = Vector2(620, 0)
    root.add_child(shop)
    var sv := VBoxContainer.new()
    sv.add_theme_constant_override("separation", 10)
    shop.add_child(sv)
    var sh := HBoxContainer.new()
    sh.add_theme_constant_override("separation", 12)
    sv.add_child(sh)
    sh.add_child(UIIcon.new("cart", Color(1, 0.8, 0.2), 60))
    UI.outlined(sh, "Магазин", 46, Color.WHITE, UI.OUTLINE, 8)
    var cs := TileIcon.new("case")
    cs.custom_minimum_size = Vector2(0, 300)
    sv.add_child(cs)
    UI.outlined(sv, "Кейс со скином", 44, Color.WHITE, UI.OUTLINE, 8)
    UI.outlined(sv, "Открой кейс и получи случайный скин!", 26, Color(0.85, 0.9, 1.0), UI.OUTLINE, 4)
    var buy := UI.btn_icon(sv, "coin", "50", _buy_case, 96.0, "green")
    buy.disabled = Progress.coins < 50
    # нижние панели
    var info := PanelContainer.new()
    info.anchor_top = 1.0
    info.anchor_bottom = 1.0
    info.offset_left = 24
    info.offset_right = 1150
    info.offset_top = -150
    info.offset_bottom = -30
    s.add_child(info)
    var ih := HBoxContainer.new()
    ih.add_theme_constant_override("separation", 16)
    info.add_child(ih)
    ih.add_child(UIIcon.new("info", Color.WHITE, 64))
    UI.label(ih, "Собирай монеты в матчах, открывай кейсы и становись сильнее!", 30)
    var fr := Button.new()
    UI.style_btn(fr, "dark")
    fr.anchor_left = 1.0
    fr.anchor_right = 1.0
    fr.anchor_top = 1.0
    fr.anchor_bottom = 1.0
    fr.offset_left = -640
    fr.offset_right = -24
    fr.offset_top = -150
    fr.offset_bottom = -30
    fr.pressed.connect(_claim_free_case)
    s.add_child(fr)
    var fh := HBoxContainer.new()
    fh.set_anchors_preset(Control.PRESET_FULL_RECT)
    fh.offset_left = 20
    fh.add_theme_constant_override("separation", 16)
    fh.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fr.add_child(fh)
    fh.add_child(UIIcon.new("gift", Color(0.9, 0.2, 0.2), 80))
    timer_label = UI.label(fh, "", 30)
    timer_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _update_case_timer()

func _tile(parent: Node, title: String, selected: bool, kind: String, id: String, col: Color, cb: Callable, sub: String) -> void:
    var b := Button.new()
    b.custom_minimum_size = Vector2(0, 220)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var bg := Color(0.35, 0.2, 0.75) if kind == "weapon" and id in ["smg", "sniper", "ak"] else Color(0.15, 0.35, 0.85)
    var bd := Color(1.0, 0.85, 0.2) if selected else Color(0.45, 0.6, 1.0)
    var st := UI.box(bg, bd, 16, 6 if selected else 3, 6 if selected else 3)
    b.add_theme_stylebox_override("normal", st)
    b.add_theme_stylebox_override("hover", st)
    b.add_theme_stylebox_override("pressed", st)
    b.add_theme_stylebox_override("disabled", st)
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.disabled = not cb.is_valid()
    if cb.is_valid():
        b.pressed.connect(cb)
    parent.add_child(b)
    var vb := VBoxContainer.new()
    vb.set_anchors_preset(Control.PRESET_FULL_RECT)
    vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_child(vb)
    var ic := TileIcon.new(kind, id, col)
    vb.add_child(ic)
    var nm := UI.outlined(vb, title if sub == "" else "%s (%s)" % [title, sub], 26, Color.WHITE, UI.OUTLINE, 5)
    nm.mouse_filter = Control.MOUSE_FILTER_IGNORE
    if selected:
        var ck := UIIcon.new("check", Color.WHITE, 40)
        ck.position = Vector2(8, 8)
        b.add_child(ck)

func _pick_weapon(id: String) -> void:
    Settings.set_value("primary", id)
    _show_inventory(0)

func _pick_agent(i: int) -> void:
    Settings.set_value("agent", i)
    _show_inventory(1)

func _case_reward(free: bool) -> void:
    var locked: Array = []
    for i in Game.AGENTS.size():
        if not Settings.data.unlocked.has(i):
            locked.append(i)
    if locked.is_empty():
        Progress.coins += 25
        Progress.save_all()
        UI.reward_popup(screen, "+25", "Все скины открыты — вы получили монеты", Color.WHITE, _show_inventory.bind(1))
        return
    var pick: int = locked.pick_random()
    var u: Array = Settings.data.unlocked.duplicate()
    u.append(pick)
    Settings.set_value("unlocked", u)
    var a: Dictionary = Game.AGENTS[pick]
    UI.reward_popup(screen, a.name, "Новый скин открыт! Выберите его в инвентаре.", a.color, _show_inventory.bind(1), true)

func _buy_case() -> void:
    if Progress.coins < 50:
        return
    Progress.coins -= 50
    Progress.save_all()
    _case_reward(false)

func _case_left() -> float:
    return float(Settings.data.free_case_at) - Time.get_unix_time_from_system()

func _claim_free_case() -> void:
    if _case_left() > 0.0:
        return
    Settings.set_value("free_case_at", Time.get_unix_time_from_system() + 86400.0)
    _case_reward(true)

func _update_case_timer() -> void:
    var left := _case_left()
    if left <= 0.0:
        timer_label.text = "Бесплатный кейс готов!\nНажмите, чтобы забрать"
    else:
        var t := int(left)
        timer_label.text = "Бесплатный кейс через:\n%02d:%02d:%02d" % [t / 3600, (t % 3600) / 60, t % 60]

# ----- профиль / статистика -----
func _show_stats() -> void:
    var s := _new_screen(0.45)
    _header(s)
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    cc.offset_top = 110
    s.add_child(cc)
    var pn := PanelContainer.new()
    pn.custom_minimum_size = Vector2(1400, 0)
    cc.add_child(pn)
    var c := VBoxContainer.new()
    c.add_theme_constant_override("separation", 12)
    pn.add_child(c)
    var top := HBoxContainer.new()
    top.add_theme_constant_override("separation", 20)
    c.add_child(top)
    var av := TileIcon.new("agent", "", Game.AGENTS[int(Settings.data.agent)].color)
    av.custom_minimum_size = Vector2(190, 190)
    top.add_child(av)
    var mid := VBoxContainer.new()
    mid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(mid)
    var le := LineEdit.new()
    le.text = Settings.data.name
    le.custom_minimum_size = Vector2(0, 70)
    le.add_theme_font_size_override("font_size", 40)
    le.text_changed.connect(func(t: String): Settings.set_value("name", t.substr(0, 16)))
    mid.add_child(le)
    var pr := Progress.level_progress()
    UI.label(mid, "Уровень: %d" % Progress.level(), 38)
    var bar := ProgressBar.new()
    bar.custom_minimum_size = Vector2(0, 34)
    bar.max_value = pr.y
    bar.value = pr.x
    bar.show_percentage = false
    mid.add_child(bar)
    UI.label(mid, "%d / %d опыта" % [pr.x, pr.y], 24)
    var total := Progress.wins + Progress.losses
    var kd := float(Progress.kills) / maxf(1.0, float(Progress.deaths))
    var tiles := HBoxContainer.new()
    tiles.add_theme_constant_override("separation", 14)
    c.add_child(tiles)
    _stat_tile(tiles, "trophy", "Побед", str(Progress.wins))
    _stat_tile(tiles, "skull", "Убийств", str(Progress.kills))
    _stat_tile(tiles, "star", "У/С", "%.1f" % kd)
    _stat_tile(tiles, "bars", "Поражений", str(Progress.losses))
    UI.label(c, "Побед: %d из %d   Лучший матч: %d устранений   Смертей: %d" % [Progress.wins, total, Progress.best_kills, Progress.deaths], 26)
    UI.label(c, "История матчей", 34)
    var sc := ScrollContainer.new()
    sc.custom_minimum_size = Vector2(0, 260)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    c.add_child(sc)
    var hv := VBoxContainer.new()
    hv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.add_child(hv)
    if Progress.history.is_empty():
        UI.label(hv, "Пока пусто — сыграйте матч.", 26)
    for h in Progress.history:
        var res := "Ничья" if h.draw else ("Победа" if h.won else "Поражение")
        var tag := ("+%d XP" % h.xp) if h.rated else "развлекательный"
        UI.label(hv, "%s | %s | %s | У/С/П: %d/%d/%d | %s" % [res, Game.MODES[h.mode], Game.MAPS[h.map], h.k, h.d, h.a, tag], 24)

func _stat_tile(parent: Node, icon: String, title: String, value: String) -> void:
    var pn := PanelContainer.new()
    pn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    pn.add_theme_stylebox_override("panel", UI.box(Color(0.06, 0.12, 0.3), Color(0.25, 0.4, 0.8), 14, 3, 3))
    parent.add_child(pn)
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 12)
    pn.add_child(hb)
    hb.add_child(UIIcon.new(icon, Color(1, 0.8, 0.2), 56))
    var vb := VBoxContainer.new()
    hb.add_child(vb)
    UI.label(vb, title, 24)
    UI.outlined(vb, value, 44, Color(1, 0.85, 0.3), UI.OUTLINE, 6)
