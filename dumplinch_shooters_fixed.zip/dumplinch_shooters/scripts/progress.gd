extends Node
# Локальный прогресс: уровень 1..500+, опыт, статистика, история.
const PATH := "user://progress.cfg"
var xp := 0
var coins := 0
var wins := 0
var losses := 0
var kills := 0
var deaths := 0
var best_kills := 0
var history: Array = []

func _ready() -> void:
    load_all()

func need(l: int) -> int:
    return 300 + 10 * l

func level() -> int:
    var l := 1
    var x := xp
    while x >= need(l):
        x -= need(l)
        l += 1
    return l

func level_progress() -> Vector2:
    var l := 1
    var x := xp
    while x >= need(l):
        x -= need(l)
        l += 1
    return Vector2(x, need(l))

# rated=false: развлекательный матч (ручная сложность) — без опыта и рейтинга.
func record(mode: String, map: String, won: bool, draw: bool, k: int, d: int, a: int, objective: int, rated: bool, diff_name: String) -> Dictionary:
    var gain := 0
    var coin := 0
    if rated:
        gain = 50 + k * 25 + a * 10 + objective * 40
        coin = 20 + k * 5 + a * 2 + objective * 10
        if won:
            gain += 150
            coin += 60
        xp += gain
        coins += coin
        kills += k
        deaths += d
        best_kills = maxi(best_kills, k)
        if won:
            wins += 1
        elif not draw:
            losses += 1
    history.push_front({"mode": mode, "map": map, "won": won, "draw": draw, "k": k, "d": d, "a": a, "rated": rated, "diff": diff_name, "xp": gain})
    if history.size() > 30:
        history.resize(30)
    save_all()
    return {"xp": gain, "coins": coin}

func save_all() -> void:
    var c := ConfigFile.new()
    for k in ["xp", "coins", "wins", "losses", "kills", "deaths", "best_kills", "history"]:
        c.set_value("p", k, get(k))
    c.save(PATH)

func load_all() -> void:
    var c := ConfigFile.new()
    if c.load(PATH) != OK:
        return
    for k in ["xp", "coins", "wins", "losses", "kills", "deaths", "best_kills", "history"]:
        set(k, c.get_value("p", k, get(k)))
