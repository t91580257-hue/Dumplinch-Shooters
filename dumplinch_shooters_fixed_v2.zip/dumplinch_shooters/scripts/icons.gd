class_name Icons
extends RefCounted
# Иконки интерфейса, нарисованные кодом (без картинок).
const DARK := Color(0.1, 0.16, 0.35)

static func draw_icon(ci: CanvasItem, kind: String, c: Vector2, s: float, col: Color) -> void:
    var h := s * 0.5
    var w := maxf(2.0, s * 0.14)
    match kind:
        "gear":
            for i in 8:
                var d := Vector2(cos(i * TAU / 8.0), sin(i * TAU / 8.0))
                ci.draw_line(c + d * h * 0.55, c + d * h * 0.98, col, w * 1.4)
            ci.draw_circle(c, h * 0.62, col)
            ci.draw_circle(c, h * 0.26, DARK)
        "back":
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-h, 0), c + Vector2(-h * 0.1, -h * 0.9), c + Vector2(-h * 0.1, -h * 0.4), c + Vector2(h, -h * 0.4), c + Vector2(h, h * 0.4), c + Vector2(-h * 0.1, h * 0.4), c + Vector2(-h * 0.1, h * 0.9)]), col)
        "close":
            ci.draw_line(c + Vector2(-h * 0.7, -h * 0.7), c + Vector2(h * 0.7, h * 0.7), col, w * 1.5)
            ci.draw_line(c + Vector2(h * 0.7, -h * 0.7), c + Vector2(-h * 0.7, h * 0.7), col, w * 1.5)
        "plus":
            ci.draw_line(c + Vector2(-h * 0.8, 0), c + Vector2(h * 0.8, 0), col, w * 1.6)
            ci.draw_line(c + Vector2(0, -h * 0.8), c + Vector2(0, h * 0.8), col, w * 1.6)
        "play":
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-h * 0.6, -h), c + Vector2(-h * 0.6, h), c + Vector2(h, 0)]), col)
        "bars":
            ci.draw_rect(Rect2(c + Vector2(-h, h * 0.1), Vector2(h * 0.55, h * 0.9)), col)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.27, -h * 0.4), Vector2(h * 0.55, h * 1.4)), col)
            ci.draw_rect(Rect2(c + Vector2(h * 0.45, -h), Vector2(h * 0.55, h * 2.0)), col)
        "cart":
            ci.draw_polyline(PackedVector2Array([c + Vector2(-h, -h * 0.8), c + Vector2(-h * 0.6, -h * 0.8), c + Vector2(-h * 0.3, h * 0.3), c + Vector2(h * 0.8, h * 0.3)]), col, w)
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-h * 0.55, -h * 0.4), c + Vector2(h, -h * 0.4), c + Vector2(h * 0.8, h * 0.2), c + Vector2(-h * 0.35, h * 0.2)]), col)
            ci.draw_circle(c + Vector2(-h * 0.2, h * 0.72), h * 0.2, col)
            ci.draw_circle(c + Vector2(h * 0.6, h * 0.72), h * 0.2, col)
        "bag":
            ci.draw_rect(Rect2(c + Vector2(-h * 0.7, -h * 0.4), Vector2(h * 1.4, h * 1.3)), col)
            ci.draw_arc(c + Vector2(0, -h * 0.4), h * 0.4, PI, TAU, 12, col, w)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.4, h * 0.2), Vector2(h * 0.8, h * 0.3)), DARK)
        "door":
            ci.draw_rect(Rect2(c + Vector2(-h * 0.7, -h), Vector2(h * 1.0, h * 2.0)), col, false, w)
            ci.draw_line(c + Vector2(-h * 0.1, 0), c + Vector2(h, 0), col, w)
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(h, 0), c + Vector2(h * 0.5, -h * 0.4), c + Vector2(h * 0.5, h * 0.4)]), col)
        "home":
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-h, 0), c + Vector2(0, -h), c + Vector2(h, 0)]), col)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.65, 0), Vector2(h * 1.3, h * 0.95)), col)
        "skull":
            ci.draw_circle(c + Vector2(0, -h * 0.15), h * 0.8, col)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.4, h * 0.3), Vector2(h * 0.8, h * 0.6)), col)
            ci.draw_circle(c + Vector2(-h * 0.3, -h * 0.1), h * 0.22, DARK)
            ci.draw_circle(c + Vector2(h * 0.3, -h * 0.1), h * 0.22, DARK)
        "trophy":
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-h * 0.6, -h), c + Vector2(h * 0.6, -h), c + Vector2(h * 0.45, h * 0.1), c + Vector2(-h * 0.45, h * 0.1)]), col)
            ci.draw_arc(c + Vector2(-h * 0.6, -h * 0.5), h * 0.35, HALF_PI, PI * 1.5, 10, col, w)
            ci.draw_arc(c + Vector2(h * 0.6, -h * 0.5), h * 0.35, -HALF_PI, HALF_PI, 10, col, w)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.12, h * 0.1), Vector2(h * 0.24, h * 0.5)), col)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.5, h * 0.6), Vector2(h, h * 0.35)), col)
        "crown":
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-h, h * 0.7), c + Vector2(-h, -h * 0.5), c + Vector2(-h * 0.5, 0), c + Vector2(0, -h * 0.8), c + Vector2(h * 0.5, 0), c + Vector2(h, -h * 0.5), c + Vector2(h, h * 0.7)]), col)
        "star":
            var pts := PackedVector2Array()
            for i in 10:
                var r := h if i % 2 == 0 else h * 0.45
                var a := -HALF_PI + i * TAU / 10.0
                pts.append(c + Vector2(cos(a), sin(a)) * r)
            ci.draw_colored_polygon(pts, col)
        "check":
            ci.draw_polyline(PackedVector2Array([c + Vector2(-h * 0.7, 0), c + Vector2(-h * 0.2, h * 0.5), c + Vector2(h * 0.8, -h * 0.5)]), col, w * 1.6)
        "crosshair":
            ci.draw_arc(c, h * 0.7, 0.0, TAU, 28, col, w * 0.8)
            ci.draw_circle(c, h * 0.12, col)
            for d in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
                ci.draw_line(c + d * h * 0.5, c + d * h, col, w * 0.8)
        "up":
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -h), c + Vector2(h * 0.9, 0), c + Vector2(h * 0.35, 0), c + Vector2(h * 0.35, h * 0.9), c + Vector2(-h * 0.35, h * 0.9), c + Vector2(-h * 0.35, 0), c + Vector2(-h * 0.9, 0)]), col)
        "person":
            ci.draw_circle(c + Vector2(-h * 0.1, -h * 0.65), h * 0.28, col)
            ci.draw_line(c + Vector2(-h * 0.1, -h * 0.35), c + Vector2(-h * 0.2, h * 0.25), col, w * 1.4)
            ci.draw_line(c + Vector2(-h * 0.15, -h * 0.2), c + Vector2(h * 0.6, 0), col, w)
            ci.draw_polyline(PackedVector2Array([c + Vector2(-h * 0.2, h * 0.25), c + Vector2(h * 0.4, h * 0.45), c + Vector2(h * 0.1, h * 0.95)]), col, w * 1.2)
        "reload":
            ci.draw_arc(c, h * 0.7, 0.6, TAU - 0.3, 24, col, w * 1.2)
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(h * 0.75, -h * 0.5), c + Vector2(h * 1.0, h * 0.1), c + Vector2(h * 0.3, -h * 0.1)]), col)
        "swap":
            ci.draw_line(c + Vector2(-h, -h * 0.35), c + Vector2(h * 0.7, -h * 0.35), col, w)
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(h, -h * 0.35), c + Vector2(h * 0.5, -h * 0.8), c + Vector2(h * 0.5, h * 0.1)]), col)
            ci.draw_line(c + Vector2(h, h * 0.35), c + Vector2(-h * 0.7, h * 0.35), col, w)
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-h, h * 0.35), c + Vector2(-h * 0.5, -h * 0.1), c + Vector2(-h * 0.5, h * 0.8)]), col)
        "bomb":
            ci.draw_circle(c + Vector2(0, h * 0.2), h * 0.7, col)
            ci.draw_line(c + Vector2(h * 0.3, -h * 0.35), c + Vector2(h * 0.6, -h * 0.75), col, w)
            ci.draw_circle(c + Vector2(h * 0.7, -h * 0.85), h * 0.15, Color(1, 0.8, 0.2))
        "grenade":
            ci.draw_circle(c + Vector2(0, h * 0.2), h * 0.65, col)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.2, -h * 0.65), Vector2(h * 0.4, h * 0.3)), col)
            ci.draw_line(c + Vector2(0, -h * 0.55), c + Vector2(h * 0.7, -h * 0.75), col, w)
        "bullet":
            ci.draw_rect(Rect2(c + Vector2(-h * 0.3, -h * 0.1), Vector2(h * 0.6, h * 1.0)), col)
            ci.draw_circle(c + Vector2(0, -h * 0.1), h * 0.3, col)
        "pause":
            ci.draw_rect(Rect2(c + Vector2(-h * 0.6, -h * 0.7), Vector2(h * 0.4, h * 1.4)), col)
            ci.draw_rect(Rect2(c + Vector2(h * 0.2, -h * 0.7), Vector2(h * 0.4, h * 1.4)), col)
        "coin":
            ci.draw_circle(c, h, Color(0.85, 0.5, 0.05))
            ci.draw_circle(c, h * 0.85, Color(1.0, 0.8, 0.15))
            ci.draw_circle(c, h * 0.55, Color(1.0, 0.9, 0.4))
        "gem":
            ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-h * 0.7, -h * 0.4), c + Vector2(0, -h), c + Vector2(h * 0.7, -h * 0.4), c + Vector2(0, h)]), col)
        "gift":
            ci.draw_rect(Rect2(c + Vector2(-h * 0.8, -h * 0.1), Vector2(h * 1.6, h * 1.0)), col)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.9, -h * 0.5), Vector2(h * 1.8, h * 0.4)), col.lightened(0.2))
            ci.draw_rect(Rect2(c + Vector2(-h * 0.12, -h * 0.5), Vector2(h * 0.24, h * 1.4)), Color(1, 0.85, 0.2))
        "info":
            ci.draw_circle(c, h, Color(1, 0.8, 0.15))
            ci.draw_circle(c + Vector2(0, -h * 0.5), h * 0.14, DARK)
            ci.draw_rect(Rect2(c + Vector2(-h * 0.1, -h * 0.2), Vector2(h * 0.2, h * 0.8)), DARK)
        "pencil":
            ci.draw_line(c + Vector2(-h * 0.7, h * 0.7), c + Vector2(h * 0.6, -h * 0.6), col, w * 1.8)
