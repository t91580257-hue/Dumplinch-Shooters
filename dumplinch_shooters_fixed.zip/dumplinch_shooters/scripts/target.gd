class_name Target
extends StaticBody3D
# Манекен тренировочной площадки: стоит или движется, после "смерти" возвращается.
signal got_hit(head: bool)
var hp := 100.0
var alive := true
var moving := false
var speed := 1.5
var range_x := 8.0
var base := Vector3.ZERO
var tt := 0.0
var vis: Node3D

func _ready() -> void:
    add_to_group("targets")
    collision_layer = 2
    collision_mask = 0
    base = position
    vis = Node3D.new()
    add_child(vis)
    var body := MeshInstance3D.new()
    var cm := CapsuleMesh.new()
    cm.radius = 0.42
    cm.height = 1.7
    body.mesh = cm
    body.position.y = 0.85
    body.material_override = Mat.col(Color(1.0, 0.55, 0.1))
    vis.add_child(body)
    var ring := MeshInstance3D.new()
    var cy := CylinderMesh.new()
    cy.top_radius = 0.44
    cy.bottom_radius = 0.44
    cy.height = 0.2
    ring.mesh = cy
    ring.position.y = 0.9
    ring.material_override = Mat.col(Color(1, 1, 1))
    vis.add_child(ring)
    var head := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 0.3
    sm.height = 0.6
    head.mesh = sm
    head.position.y = 1.62
    head.material_override = Mat.col(Color(1.0, 0.9, 0.8))
    vis.add_child(head)
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.42
    cap.height = 1.9
    cs.shape = cap
    cs.position.y = 0.95
    add_child(cs)

func head_threshold() -> float:
    return 1.3

func _physics_process(delta: float) -> void:
    if moving and alive:
        tt += delta * speed
        position.x = base.x + sin(tt) * range_x

func take_damage(amount: float, attacker, head: bool = false) -> void:
    if not alive:
        return
    hp -= amount
    got_hit.emit(head)
    Sfx.play("headshot" if head else "hit")
    var l := Label3D.new()
    l.text = str(int(amount))
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.font_size = 64
    l.pixel_size = 0.006
    l.modulate = Color(1, 0.2, 0.2) if head else Color(1, 1, 1)
    get_tree().current_scene.add_child(l)
    l.global_position = global_position + Vector3(randf_range(-0.3, 0.3), 2.1, 0)
    var tw := l.create_tween()
    tw.tween_property(l, "position:y", l.position.y + 0.8, 0.6)
    tw.tween_callback(l.queue_free)
    if hp <= 0.0:
        alive = false
        var t2 := create_tween()
        t2.tween_property(vis, "rotation:x", -1.5, 0.3)
        t2.tween_interval(1.5)
        t2.tween_callback(_reset)

func _reset() -> void:
    hp = 100.0
    alive = true
    vis.rotation.x = 0.0
