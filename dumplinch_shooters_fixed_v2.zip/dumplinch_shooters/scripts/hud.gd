class_name Hud
extends Control
# Сенсорный HUD: джойстик, кнопки, поворот камеры, прицел, счёт, лента, режим редактирования.
signal pause_pressed
signal selection_changed(id: String)

const IDS := ["joystick", "fire", "ads", "jump", "crouch", "reload", "switch", "interact", "grenade"]
var edit_mode := false
var elements := {}
var move := Vector2.ZERO
var held := {}
var just := {}
var look := TouchLook.new()
var touches := {}
var player = null
var top := {"l": "", "r": "", "t": "", "sub": ""}
var center_text := ""
var center_t := 0.0
var feed: Array = []
var progress := -1.0
var progress_label := ""
var interact_label := ""
var show_pause := true
var hit_t := 0.0
var hit_head := false
var hurt_t := 0.0
var selected := ""
var ignore_rects: Array = []
var joy_center := Vector2.ZERO

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    reload_layout()
    Settings.changed.connect(reload_layout)

func reload_layout() -> void:
    elements = Settings.hud_layout()

func pressed(id: String) -> bool:
    return held.get(id, false)

func take(id: String) -> bool:
    if just.has(id) and Time.get_ticks_msec() - just[id] < 200:
        just.erase(id)
        return true
    return false

func screen_pos(id: String) -> Vector2:
    var p: Vector2 = elements[id].pos
    var h: Dictionary = Settings.data.hud
    if h.swap:
        p.x = 1.0 - p.x
    var anchor := Vector2(0.0 if p.x < 0.5 else 1.0, 1.0)
    p = anchor + (p - anchor) * float(h.gap)
    return p * size

func radius(id: String) -> float:
    return float(elements[id].sz) * 0.5 * (size.y / 1080.0)

func _hit(pos: Vector2) -> String:
    for i in range(IDS.size() - 1, -1, -1):
        var id: String = IDS[i]
        var r := radius(id) * (1.5 if id == "joystick" else 1.15)
        if pos.distance_to(screen_pos(id)) <= r:
            return id
    return ""

func _input(e: InputEvent) -> void:
    if e is InputEventScreenTouch:
        if e.pressed:
            _down(e.index, e.position)
        else:
            _up(e.index)
    elif e is InputEventScreenDrag:
        _drag(e.index, e.position, e.relative)

func _down(i: int, pos: Vector2) -> void:
    for r in ignore_rects:
        if r.has_point(pos):
            return
    var id := _hit(pos)
    if edit_mode:
        selected = id
        touches[i] = {"kind": "edit", "id": id}
        selection_changed.emit(id)
        return
    if show_pause and pos.distance_to(Vector2(70, 70) * (size.y / 1080.0)) < 50.0:
        pause_pressed.emit()
        return
    if id == "joystick":
        touches[i] = {"kind": "joy"}
        joy_center = screen_pos("joystick")
        _update_joy(pos)
    elif id != "":
        held[id] = true
        just[id] = Time.get_ticks_msec()
        touches[i] = {"kind": "btn", "id": id}
    else:
        touches[i] = {"kind": "look"}

func _up(i: int) -> void:
    if not touches.has(i):
        return
    var t: Dictionary = touches[i]
    if t.kind == "btn":
        held[t.id] = false
    elif t.kind == "joy":
        move = Vector2.ZERO
    elif t.kind == "edit":
        Settings.save_all()
    touches.erase(i)

func _drag(i: int, pos: Vector2, rel: Vector2) -> void:
    if not touches.has(i):
        return
    var t: Dictionary = touches[i]
    match t.kind:
        "joy":
            _update_joy(pos)
        "look":
            look.add_drag(rel)
        "btn":
            if t.id == "fire":
                look.add_drag(rel)
        "edit":
            if t.id != "":
                _move_element(t.id, rel)

func _update_joy(pos: Vector2) -> void:
    var r := radius("joystick")
    var v := (pos - joy_center) / r
    if v.length() > 1.0:
        v = v.normalized()
    if v.length() < 0.12:
        v = Vector2.ZERO
    move = Vector2(v.x, -v.y)

func _move_element(id: String, rel: Vector2) -> void:
    var e: Dictionary = elements[id]
    var old: Vector2 = e.pos
    var d := rel / size
    if Settings.data.hud.swap:
        d.x = -d.x
    d /= maxf(float(Settings.data.hud.gap), 0.2)
    e.pos = old + d
    var sp := screen_pos(id)
    var m := 0.04 * size.y
    if sp.x < m or sp.y < m or sp.x > size.x - m or sp.y > size.y - m:
        e.pos = old
    else:
        Settings.set_hud_element(id, e.pos, e.sz, e.alpha, false)

func set_selected_size(v: float) -> void:
    if selected != "" and elements.has(selected):
        elements[selected].sz = v
        Settings.set_hud_element(selected, elements[selected].pos, v, elements[selected].alpha)

func set_selected_alpha(v: float) -> void:
    if selected != "" and elements.has(selected):
        elements[selected].alpha = v
        Settings.set_hud_element(selected, elements[selected].pos, elements[selected].sz, v)

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_PAUSED:
        touches.clear()
        held.clear()
        move = Vector2.ZERO

func _process(delta: float) -> void:
    hit_t = maxf(0.0, hit_t - delta)
    hurt_t = maxf(0.0, hurt_t - delta)
    center_t = maxf(0.0, center_t - delta)
    for f in feed:
        f[1] -= delta
    feed = feed.filter(func(x): return x[1] > 0.0)
    queue_redraw()

static func draw_crosshair(ci: CanvasItem, c: Vector2, extra: float = 0.0) -> void:
    var col: Color = Settings.CH_COLORS[int(Settings.data.ch_color)]
    var sz: float = Settings.data.ch_size
    var gap := 5.0 + extra
    match int(Settings.data.ch_shape):
        0:
            ci.draw_line(c + Vector2(gap, 0), c + Vector2(gap + sz, 0), col, 3.0)
            ci.draw_line(c - Vector2(gap, 0), c - Vector2(gap + sz, 0), col, 3.0)
            ci.draw_line(c + Vector2(0, gap), c + Vector2(0, gap + sz), col, 3.0)
            ci.draw_line(c - Vector2(0, gap), c - Vector2(0, gap + sz), col, 3.0)
        1:
            ci.draw_circle(c, maxf(sz * 0.25, 2.0), col)
        _:
            ci.draw_arc(c, sz * 0.8 + extra, 0.0, TAU, 40, col, 3.0)

func _draw() -> void:
    var f := ThemeDB.fallback_font
    var S := size
    var sc := S.y / 1080.0
    if edit_mode:
        _draw_edit_bg(S)
    elif player != null:
        _draw_game(S, sc, f)
    for id in IDS:
        _draw_button(id, f, sc)

func _draw_edit_bg(S: Vector2) -> void:
    for i in range(1, 20):
        draw_line(Vector2(S.x * i / 20.0, 0), Vector2(S.x * i / 20.0, S.y), Color(1, 1, 1, 0.08), 1.0)
    for i in range(1, 12):
        draw_line(Vector2(0, S.y * i / 12.0), Vector2(S.x, S.y * i / 12.0), Color(1, 1, 1, 0.08), 1.0)
    var m := 0.04 * S.y
    draw_rect(Rect2(m, m, S.x - 2 * m, S.y - 2 * m), Color(1, 0.9, 0.2, 0.6), false, 3.0)

func _draw_game(S: Vector2, sc: float, f: Font) -> void:
    var c := S * 0.5
    if player.scoped():
        draw_arc(c, S.y * 0.5 + S.x * 0.5, 0.0, TAU, 96, Color.BLACK, S.x)
        draw_line(Vector2(0, c.y), Vector2(S.x, c.y), Color(0, 0, 0, 0.8), 2.0)
        draw_line(Vector2(c.x, 0), Vector2(c.x, S.y), Color(0, 0, 0, 0.8), 2.0)
    elif player.alive:
        draw_crosshair(self, c, clampf(player.spread_now * 3.0, 0.0, 24.0))
    if hit_t > 0.0:
        var hc := Color(1, 0.2, 0.2) if hit_head else Color.WHITE
        for dv in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
            draw_line(c + dv * 10.0, c + dv * 22.0, hc, 3.0)
    if hurt_t > 0.0:
        draw_rect(Rect2(Vector2.ZERO, S), Color(1, 0, 0, 0.3 * hurt_t / 0.4))
    # верхняя панель
    draw_rect(Rect2(S.x * 0.5 - 330, 10, 660, 74), Color(0, 0, 0, 0.45))
    draw_string(f, Vector2(S.x * 0.5 - 320, 58), top.l, HORIZONTAL_ALIGNMENT_LEFT, 280, 28, Game.TEAM_COLORS["spec"])
    draw_string(f, Vector2(S.x * 0.5 + 40, 58), top.r, HORIZONTAL_ALIGNMENT_RIGHT, 280, 28, Game.TEAM_COLORS["terror"])
    draw_string(f, Vector2(S.x * 0.5 - 60, 62), top.t, HORIZONTAL_ALIGNMENT_CENTER, 120, 38, Color.WHITE)
    draw_string(f, Vector2(S.x * 0.5 - 330, 112), top.sub, HORIZONTAL_ALIGNMENT_CENTER, 660, 24, Color(1, 0.85, 0.4))
    if show_pause:
        draw_circle(Vector2(70, 70) * sc, 40.0 * sc, Color(0, 0, 0, 0.5))
        draw_string(f, Vector2(40, 82) * sc, "II", HORIZONTAL_ALIGNMENT_CENTER, 60 * sc, 34, Color.WHITE)
    var y := 110.0
    for e in feed:
        draw_string(f, Vector2(S.x - 620, y), e[0], HORIZONTAL_ALIGNMENT_RIGHT, 600, 24, e[2])
        y += 32.0
    if center_t > 0.0:
        draw_string(f, Vector2(0, S.y * 0.3), center_text, HORIZONTAL_ALIGNMENT_CENTER, S.x, 54, Color(1, 1, 1, minf(1.0, center_t)))
    if progress >= 0.0:
        var r := Rect2(S.x * 0.5 - 200, S.y * 0.62, 400, 26)
        draw_rect(r, Color(0, 0, 0, 0.6))
        draw_rect(Rect2(r.position, Vector2(r.size.x * progress, r.size.y)), Color(1, 0.8, 0.2))
        draw_string(f, Vector2(r.position.x, r.position.y - 8), progress_label, HORIZONTAL_ALIGNMENT_CENTER, 400, 26, Color.WHITE)
    if player.alive:
        var d: Dictionary = player.wd()
        var ammo_t: String = str(d.get("name", ""))
        if not d.get("melee", false):
            var a: Array = player.ammo[player.wid()]
            ammo_t = "%s  %d / %s" % [d.name, a[0], "inf" if player.infinite else str(a[1])]
        draw_string(f, Vector2(S.x * 0.5 - 300, S.y - 30), "HP %d" % int(player.hp), HORIZONTAL_ALIGNMENT_LEFT, 200, 34, Color(0.4, 1, 0.5))
        draw_string(f, Vector2(S.x * 0.5 - 100, S.y - 30), ammo_t, HORIZONTAL_ALIGNMENT_LEFT, 400, 30, Color.WHITE)
        draw_string(f, Vector2(S.x * 0.5 - 100, S.y - 66), "Гранат: %d" % player.grenades, HORIZONTAL_ALIGNMENT_LEFT, 300, 22, Color(0.8, 0.9, 0.7))
        if player.reload_t > 0.0:
            draw_string(f, Vector2(0, S.y * 0.55), "ПЕРЕЗАРЯДКА", HORIZONTAL_ALIGNMENT_CENTER, S.x, 28, Color(1, 0.9, 0.4))

func _draw_button(id: String, f: Font, sc: float) -> void:
    var e: Dictionary = elements[id]
    var p := screen_pos(id)
    var r := radius(id)
    var a: float = e.alpha
    var on: bool = bool(held.get(id, false))
    if id == "joystick":
        draw_circle(p, r, Color(1, 1, 1, 0.12 * a))
        draw_arc(p, r, 0.0, TAU, 48, Color(1, 1, 1, 0.6 * a), 4.0)
        draw_circle(p + Vector2(move.x, -move.y) * r * 0.55, r * 0.38, Color(1, 1, 1, 0.45 * a))
    else:
        var dim := 1.0
        var txt := Settings.t(id)
        if id == "interact" and not edit_mode:
            if interact_label == "":
                dim = 0.35
            else:
                txt = interact_label
        draw_circle(p, r, Color(1, 0.6, 0.1, 0.55 * a * dim) if on else Color(1, 1, 1, 0.2 * a * dim))
        draw_arc(p, r, 0.0, TAU, 40, Color(1, 1, 1, 0.7 * a * dim), 4.0)
        var fs := int(clampf(r * 0.3, 14, 30))
        draw_string(f, p + Vector2(-r, fs * 0.35), txt, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color(1, 1, 1, a * dim + 0.1))
    if edit_mode and selected == id:
        draw_arc(p, r + 10, 0.0, TAU, 48, Color(1, 0.9, 0.2), 5.0)
    elif edit_mode:
        draw_arc(p, r + 6, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 2.0)
