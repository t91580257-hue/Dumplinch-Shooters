class_name UIIcon
extends Control
var kind := "gear"
var col := Color.WHITE

func _init(k: String = "gear", c: Color = Color.WHITE, s: float = 40.0) -> void:
    kind = k
    col = c
    custom_minimum_size = Vector2(s, s)
    mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
    Icons.draw_icon(self, kind, size * 0.5, minf(size.x, size.y) * 0.8, col)
