extends Control
# Настройки с вкладками (Игра / Управление / Графика / Звук). Все изменения применяются сразу.
var content: VBoxContainer
var tab_btns: Array = []
var cur_tab := 0

func _ready() -> void:
    theme = UI.make_theme()
    var bg := ColorRect.new()
    bg.color = Color(0.1, 0.22, 0.55)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    var cc := MarginContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    cc.add_theme_constant_override("margin_left", 60)
    cc.add_theme_constant_override("margin_right", 60)
    cc.add_theme_constant_override("margin_top", 40)
    cc.add_theme_constant_override("margin_bottom", 40)
    add_child(cc)
    var pn := PanelContainer.new()
    cc.add_child(pn)
    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 14)
    pn.add_child(root)
    var hd := HBoxContainer.new()
    hd.add_theme_constant_override("separation", 14)
    root.add_child(hd)
    hd.add_child(UIIcon.new("gear", Color.WHITE, 64))
    var t := UI.outlined(hd, "Настройки", 52, Color.WHITE, UI.OUTLINE, 8)
    t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    UI.icon_square(hd, "close", _close, 76.0, "blue")
    var body := HBoxContainer.new()
    body.size_flags_vertical = Control.SIZE_EXPAND_FILL
    body.add_theme_constant_override("separation", 20)
    root.add_child(body)
    var side := VBoxContainer.new()
    side.custom_minimum_size = Vector2(300, 0)
    side.add_theme_constant_override("separation", 10)
    body.add_child(side)
    var names := ["Игра", "Управление", "Графика", "Звук"]
    var icons := ["play", "crosshair", "bars", "info"]
    for i in 4:
        var b := UI.btn_icon(side, icons[i], names[i], _tab.bind(i), 86.0, "yellow" if i == 0 else "dark")
        tab_btns.append(b)
    var sc := ScrollContainer.new()
    sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    body.add_child(sc)
    content = VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 12)
    sc.add_child(content)
    var ft := HBoxContainer.new()
    ft.alignment = BoxContainer.ALIGNMENT_END
    ft.add_theme_constant_override("separation", 16)
    root.add_child(ft)
    var rs := UI.btn_icon(ft, "reload", "Сбросить", _reset_tab, 80.0, "blue")
    rs.custom_minimum_size.x = 300
    var ap := UI.btn_icon(ft, "check", "Применить", _close, 80.0, "green")
    ap.custom_minimum_size.x = 320
    _fill()

func _tab(i: int) -> void:
    cur_tab = i
    for k in tab_btns.size():
        UI.style_btn(tab_btns[k], "yellow" if k == i else "dark")
        # цвет иконки/текста внутри кнопки
        for ch in tab_btns[k].get_children():
            for g in ch.get_children():
                if g is UIIcon:
                    g.col = UI.TEXT_DARK if k == i else Color.WHITE
                    g.queue_redraw()
                elif g is Label:
                    if k == i:
                        g.add_theme_color_override("font_color", UI.TEXT_DARK)
                        g.add_theme_constant_override("outline_size", 0)
                    else:
                        g.remove_theme_color_override("font_color")
                        g.add_theme_constant_override("outline_size", 6)
    _fill()

func _clear() -> void:
    for c in content.get_children():
        c.queue_free()

func _fill() -> void:
    _clear()
    match cur_tab:
        0:
            UI.slider(content, "Чувствительность", "sens_general", 0.2, 3.0, 0.05)
            UI.slider(content, "Чувствительность в прицеле (ADS)", "sens_ads", 0.1, 3.0, 0.05)
            UI.slider(content, "Снайперский прицел", "sens_scope", 0.1, 3.0, 0.05)
            UI.slider(content, "По горизонтали", "sens_x", 0.2, 3.0, 0.05)
            UI.slider(content, "По вертикали", "sens_y", 0.2, 3.0, 0.05)
            UI.toggle(content, "Сглаживание прицела", "smooth_on")
            UI.slider(content, "Сила сглаживания (0% — мгновенно)", "smooth_amount", 0.0, 1.0, 0.01, true)
            UI.toggle(content, "Ускорение прицела", "accel_on")
            UI.slider(content, "Сила ускорения", "accel_power", 0.0, 1.0, 0.01, true)
            UI.toggle(content, "Ускорение в прицеливании", "accel_ads_on")
            UI.slider(content, "Сила ускорения в прицеле", "accel_ads_power", 0.0, 1.0, 0.01, true)
        1:
            UI.btn_icon(content, "gear", "НАСТРОИТЬ УПРАВЛЕНИЕ", _open_editor, 84.0, "yellow")
            UI.btn_icon(content, "crosshair", "ТЕСТ ПРИЦЕЛА", _open_aim_test, 84.0)
            UI.btn_icon(content, "play", "ТРЕНИРОВОЧНАЯ ПЛОЩАДКА", _open_training, 84.0)
            UI.choice_row(content, "Цвет прицела", Settings.CH_COLOR_NAMES, int(Settings.data.ch_color), func(i): Settings.set_value("ch_color", i))
            UI.choice_row(content, "Форма прицела", Settings.CH_SHAPES, int(Settings.data.ch_shape), func(i): Settings.set_value("ch_shape", i))
            UI.slider(content, "Размер прицела", "ch_size", 4.0, 40.0, 1.0)
            content.add_child(preload("res://scripts/crosshair_preview.gd").new())
        2:
            UI.choice_row(content, "Качество графики", ["Низкое", "Среднее", "Высокое"], int(Settings.data.gfx), func(i): Settings.set_value("gfx", i))
            UI.choice_row(content, "Качество эффектов", ["Низкое", "Среднее", "Высокое"], int(Settings.data.fx), func(i): Settings.set_value("fx", i))
            UI.choice_row(content, "Язык интерфейса (меню)", ["Русский", "English"], 0 if Settings.data.lang == "ru" else 1, func(i): Settings.set_value("lang", "ru" if i == 0 else "en"))
        _:
            UI.slider(content, "Общая громкость", "master_vol", 0.0, 1.0, 0.01, true)
            UI.slider(content, "Музыка", "music_vol", 0.0, 1.0, 0.01, true)
            UI.slider(content, "Звуки", "sfx_vol", 0.0, 1.0, 0.01, true)
            UI.toggle(content, "Голосовые уведомления", "voice")

func _reset_tab() -> void:
    match cur_tab:
        0:
            Settings.reset_sens()
            Settings.data.smooth_on = false
            Settings.data.smooth_amount = 0.5
            Settings.data.accel_on = false
            Settings.data.accel_power = 0.5
            Settings.data.accel_ads_on = false
            Settings.data.accel_ads_power = 0.3
        1:
            Settings.data.ch_color = 1
            Settings.data.ch_shape = 0
            Settings.data.ch_size = 12.0
        2:
            Settings.data.gfx = 1
            Settings.data.fx = 2
        _:
            Settings.data.master_vol = 1.0
            Settings.data.music_vol = 0.6
            Settings.data.sfx_vol = 1.0
            Settings.data.voice = true
    Settings.save_all()
    Settings.changed.emit()
    _fill()

func _open_editor() -> void:
    Game.return_scene = "res://scenes/settings.tscn"
    Game.go("res://scenes/hud_editor.tscn")

func _open_aim_test() -> void:
    Game.aim_test = true
    Game.return_scene = "res://scenes/settings.tscn"
    Game.go("res://scenes/training.tscn")

func _open_training() -> void:
    Game.aim_test = false
    Game.return_scene = "res://scenes/settings.tscn"
    Game.go("res://scenes/training.tscn")

func _close() -> void:
    Game.go(Game.MENU)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        _close()
